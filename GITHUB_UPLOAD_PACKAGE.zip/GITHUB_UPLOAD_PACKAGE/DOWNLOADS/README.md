# Downloads

Ready-to-download packages, installers, and user manuals for all educational software projects.

## 📦 Available Downloads

### Anbu Library Management System
- **Manual:** `Anbu_Library_Management_Manual_FINAL.docx`
  - Complete user manual and installation guide
  - Step-by-step instructions
  - Troubleshooting tips

## 📥 How to Download

1. Click on the file name above
2. GitHub will automatically download the file
3. For DOCX files, you can open them with Microsoft Word or compatible applications

## 📋 Future Additions

More downloadable packages will be added as new educational software projects are completed.

---

*Part of the Educational Software Collection*