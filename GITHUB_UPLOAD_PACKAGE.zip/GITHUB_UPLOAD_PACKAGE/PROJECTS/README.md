# Educational Software Projects

Welcome to our comprehensive collection of educational software designed for schools, students, and teachers.

## 📚 Available Projects

### [Anbu Library Management System](anbu-library-system/)
A complete library management solution for schools and educational institutions.

**Features:**
- Member management
- Book cataloging and tracking
- ID card generation
- Automated reports
- User-friendly interface

**Download:** Available in DOCX format in the DOWNLOADS folder

### [Spellapp - Spelling Game](spellapp/)
An interactive spelling game designed for children to improve their spelling skills.

**Features:**
- Interactive gameplay
- Multiple difficulty levels
- Progress tracking
- Educational content

## 🚀 How to Use

1. **Browse Projects:** Click on any project above to view details
2. **Download:** Check the DOWNLOADS folder for ready-to-use packages
3. **Documentation:** Each project includes comprehensive guides and manuals

## 📞 Support

For questions or support, please refer to the documentation included with each project.

---

*This collection is designed to enhance educational experiences for students and teachers worldwide.*