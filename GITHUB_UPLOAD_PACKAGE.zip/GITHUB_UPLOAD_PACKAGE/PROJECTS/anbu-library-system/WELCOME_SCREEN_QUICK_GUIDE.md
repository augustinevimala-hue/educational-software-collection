# WELCOME SCREEN QUICK GUIDE
## Anbu Academic Centre Library Management System

---

## 🚀 QUICK START

### **First Time Setup:**
1. **Copy Required Files:** Ensure all database files and executables are in the same folder
2. **Start Application:** Click `anbu library.exe` to begin
3. **Configure System:** Go to System Configuration and set up your school details
4. **Add Content:** Begin by adding books and registering members

### **Essential Files Checklist:**
- ✅ `Master.dbf` - Books database
- ✅ `Staff.dbf` - Staff members
- ✅ `Students.dbf` - Student members  
- ✅ `Transact.dbf` - Transaction records
- ✅ `library_config.txt` - Configuration
- ✅ `anbu library.exe` - Main program

---

## ⚡ KEY OPERATIONS

### **Adding Books:**
1. Search Books tab → Add New Book
2. Fill details → Save
3. Accession number auto-generated

### **Registering Members:**
1. Add Member tab
2. Students: IDs 1-4999 (new academic year reset)
3. Staff: IDs 5001+
4. Member ID auto-assigned

### **Book Transactions:**
- **Issue:** Issue Book tab → Enter member + book details
- **Return:** Return Book tab → Enter book accession number
- **Search:** Find books by title, author, or subject

---

## 🔧 COMMON SOLUTIONS

### **Program Won't Start:**
- Run as administrator
- Check all files are present
- Verify Windows firewall settings

### **Database Errors:**
- Use `dbfmanager.exe` to inspect files
- Restore from backup
- Check file permissions

### **Configuration Issues:**
- Copy `library_config_template.txt` to `library_config.txt`
- Update through System Configuration menu

### **Performance Problems:**
- Close unnecessary programs
- Check disk space (500MB minimum)
- Restart system if needed

---

## 📞 GETTING HELP

- **Check documentation first**
- **Backup data before changes**
- **Contact system administrator for technical issues**
- **Document error messages for support**

---

## 🎯 SYSTEM FEATURES

• **Complete Library Management** - Books, Members, Transactions  
• **MNO Member System** - Automatic ID assignment  
• **Issue/Return Tracking** - Automatic due date calculation  
• **Report Generation** - Print-ready reports  
• **Database Backup** - Automatic data protection  
• **User-Friendly Interface** - Tab-based navigation  

**Welcome to your new Library Management System!**