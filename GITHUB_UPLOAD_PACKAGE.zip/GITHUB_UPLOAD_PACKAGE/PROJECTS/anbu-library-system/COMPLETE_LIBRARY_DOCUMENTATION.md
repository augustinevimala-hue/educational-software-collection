# COMPLETE LIBRARY MANAGEMENT SYSTEM DOCUMENTATION
## Anbu Academic Centre Library Management System v3.0

---

## 📚 TABLE OF CONTENTS

1. [System Overview](#system-overview)
2. [Getting Started](#getting-started)
3. [User Instructions](#user-instructions)
4. [Troubleshooting Guide](#troubleshooting-guide)
5. [Technical Requirements](#technical-requirements)
6. [System Features](#system-features)

---

## 🎯 SYSTEM OVERVIEW

### Welcome to the Anbu Academic Centre Library Management System!

This comprehensive software solution is designed specifically for educational institutions and libraries. It provides complete management of library operations including book tracking, member management, and reporting systems.

### **Key Features:**
• Complete Book & Member Management  
• Issue & Return Tracking System  
• Comprehensive Reports & Analytics  
• Print Reports & Analytics externally from files created  
• User-friendly Interface  
• Multi-user Support  
• Data Backup & Recovery  

---

## 🚀 GETTING STARTED

### Step 1: System Setup
Ensure you have the required system files copied into your installation directory:

**Essential Files:**
- `Master.dbf` - Main book database
- `Staff.dbf` - Staff member database  
- `Students.dbf` - Student member database
- `Transact.dbf` - Transaction records
- `library_config.txt` - System configuration

**Executable Files:**
- `anbulib.exe` - Main library system
- `anbulbr.exe` - Alternative launcher
- `anbu library.exe` - Direct access launcher

**Supporting Tools:**
- `dbfmanager.exe` (47,322 KB) - Database viewer and manager

### Step 2: First Launch
1. Start with the **Welcome Screen** for system overview
2. Click `anbu library.exe` to start the main application
3. Configure system settings in System Configuration tab
4. Begin by adding books and registering members

### Step 3: System Navigation
The main system uses a tabbed interface with the following key sections:
- **Add/Search Books** - Manage book inventory
- **Add Member** - Register new members
- **Issue Book** - Process book lending
- **Return Book** - Process book returns
- **System Configuration** - Settings and preferences

---

## 👤 USER INSTRUCTIONS

### **Adding Books to the System**

1. Navigate to **Search Books** tab
2. Click **'Add New Book'** button
3. Fill in all required information:
   - Book Title
   - Author Name
   - Subject/Category
   - Publication Details
   - Physical location details
4. Click **Save** to add to system
5. **Book Accession Number** is generated automatically

### **Registering New Members**

#### Students (1-4999)
- Student numbers range from 1 to 4999
- Every academic year, old member records are deleted and new students are added
- Registration includes:
  - Student Name
  - Class and Section
  - Roll Number
  - Contact Information

#### Staff (5001+)
- Staff member numbers start from 5001
- Registration includes:
  - Staff Name
  - Department
  - Designation
  - Contact Information

**Steps to Register:**
1. Go to **Add Member** tab
2. Select Student or Staff category
3. Fill in member details completely
4. **Member ID is assigned automatically**
5. Save member information

### **Issuing Books to Members**

1. Navigate to **Issue Book** tab
2. Enter member ID (Student: 1-4999, Staff: 5001+)
3. Enter book access number or search for book
4. System automatically calculates:
   - Issue date
   - Due date (typically 14 days)
   - Maximum issue limits
5. Confirm issue to complete transaction

### **Processing Book Returns**

1. Navigate to **Return Book** tab
2. Enter book access number
3. System will display:
   - Member information
   - Issue date
   - Due date
   - Any overdue charges
4. Confirm return to complete transaction

### **Searching and Managing Books**

1. Use **Search Books** tab
2. Search options available:
   - By Title
   - By Author
   - By Subject
   - By Accession Number
3. View detailed book information
4. Update or modify book records as needed

---

## 🔧 TROUBLESHOOTING GUIDE

### **1. PROGRAM WON'T START**

**Symptoms:** Application fails to launch or crashes on startup

**Solutions:**
- ✅ Verify all files are in the correct directory
- ✅ Ensure you have necessary system permissions
- ✅ Try running as administrator
- ✅ Check Windows firewall/antivirus settings
- ✅ Ensure `library_config.txt` exists or create from template

### **2. DATABASE ERRORS**

**Symptoms:** "Database not found" or "Cannot access database" messages

**Solutions:**
- ✅ Verify essential database files are present
- ✅ Ensure database files are not corrupted
- ✅ Check if database files are not in use by another program
- ✅ Restore from backup if needed
- ✅ Verify file permissions
- ✅ Use `dbfmanager.exe` to inspect database structure

### **3. CONFIGURATION ERRORS**

**Symptoms:** "Control: Text_SchoolName Of Form_Config Not defined" error

**Solutions:**
- ✅ Ensure `library_config.txt` exists before first run
- ✅ Copy `library_config_template.txt` to `library_config.txt`
- ✅ Update configuration through System Configuration menu
- ✅ Avoid calling config functions during application startup

### **4. SLOW PERFORMANCE**

**Symptoms:** Application responds slowly, screens load slowly

**Solutions:**
- ✅ Close unnecessary programs
- ✅ Check available disk space (minimum 500MB)
- ✅ Ensure adequate RAM (minimum 2GB)
- ✅ Restart the system if needed
- ✅ Run disk cleanup and defragmentation

### **5. PRINTING ISSUES**

**Symptoms:** Reports won't print or print incorrectly

**Solutions:**
- ✅ Check printer connection and power
- ✅ Ensure printer drivers are installed correctly
- ✅ Try printing a test page from Windows
- ✅ Check paper and ink levels
- ✅ Verify printer is set as default

### **6. MEMBER REGISTRATION ERRORS**

**Symptoms:** Cannot register new members or get ID conflicts

**Solutions:**
- ✅ Ensure all required fields are filled completely
- ✅ Check for duplicate member IDs
- ✅ Verify database connectivity
- ✅ Try with a different member ID format
- ✅ Check student range (1-4999) vs staff range (5001+)

### **7. BOOK SEARCH NOT WORKING**

**Symptoms:** Search returns no results or errors

**Solutions:**
- ✅ Check search criteria format
- ✅ Ensure books are properly entered in system
- ✅ Try different search parameters
- ✅ Check for special characters in search terms
- ✅ Verify database contains book records

### **8. ISSUE/RETURN TRANSACTION ERRORS**

**Symptoms:** Cannot issue books or process returns

**Solutions:**
- ✅ Verify member exists in system
- ✅ Check if book is available (not already issued)
- ✅ Ensure transaction dates are valid
- ✅ Check database permissions
- ✅ Restart application if needed

---

## ⚙️ TECHNICAL REQUIREMENTS

### **System Requirements:**
- **Operating System:** Windows XP or later
- **RAM:** Minimum 2GB, Recommended 4GB
- **Disk Space:** 500MB available space
- **Database:** DBF format compatibility
- **Printer:** Optional, for report printing

### **File Structure:**
```
Library System Directory/
├── anbu library.exe          # Main application
├── anbulib.exe              # Alternative launcher
├── anbulbr.exe              # Secondary launcher
├── Master.dbf               # Book database
├── Staff.dbf                # Staff database
├── Students.dbf             # Students database
├── Transact.dbf             # Transaction database
├── library_config.txt       # System configuration
├── dbfmanager.exe           # Database manager
└── Reports/                 # Generated reports
```

---

## 🆘 GETTING HELP

### **Before Contacting Support:**

1. ✅ Check this troubleshooting guide first
2. ✅ Verify all checklist items are completed
3. ✅ Document any error messages for support
4. ✅ Backup your data before making changes

### **Support Resources:**
- **System Administrator:** Contact your IT support person
- **User Documentation:** This guide
- **Database Manager:** Use `dbfmanager.exe` for data inspection

### **Emergency Recovery:**
- Always maintain regular backups of all database files
- Keep a backup copy of `library_config.txt`
- Store backups in a separate location from the main system

---

## 📝 VERSION HISTORY

**Current Version:** 3.0  
**Last Updated:** December 5, 2025  
**Author:** MiniMax Agent (Enhanced Documentation)

### **Recent Improvements:**
- ✅ Fixed configuration startup crash
- ✅ Enhanced error handling
- ✅ Improved user interface
- ✅ Better documentation structure
- ✅ Automated config file creation

---

*For the latest updates and advanced features, please contact your system administrator.*