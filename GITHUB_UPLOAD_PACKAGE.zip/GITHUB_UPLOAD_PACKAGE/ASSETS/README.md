# Assets & Media

Visual resources, logos, icons, and media files for the educational software collection.

## 📁 Contents

- **Logos:** Project logos and branding
- **Icons:** UI icons and symbols
- **Images:** Screenshots and promotional images
- **Templates:** Design templates

## 🎨 Usage

Use these assets to maintain consistent branding across projects and presentations.

---

*Part of the Educational Software Collection*