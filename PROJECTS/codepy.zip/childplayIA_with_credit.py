import tkinter as tk
from tkinter import messagebox, ttk
import random
import dbf
import os
import sys

def add_credit_line(window):
    """Add credit line to the bottom of any Tkinter window"""
    credit = tk.Label(
        window,
        text="Software Developer - I Augustine Anbananthan",
        font=("Arial", 10, "italic"),
        fg="#555",
        bg=window["bg"]
    )
    credit.pack(side="bottom", pady=10)


# Function to get resource path for PyInstaller
def get_resource_path(relative_path):
    """Get absolute path to resource, works for dev and for PyInstaller"""
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# DBF files
WORDS_DBF = get_resource_path('words.dbf')
USERS_DBF = get_resource_path('users.dbf')

# Ensure DBF files exist
if not os.path.exists(WORDS_DBF):
    table = dbf.Table(WORDS_DBF, field_specs='word C(20)')
    table.open(dbf.READ_WRITE)
    table.close()

if not os.path.exists(USERS_DBF):
    table = dbf.Table(USERS_DBF, field_specs='name C(50); class N(2,0)')
    table.open(dbf.READ_WRITE)
    table.close()


# Global variables
child_name = ""
child_class = 1

# Function to get user data and show startup window
def get_user_data(root):
    def select_user():
        selected_name = name_var.get()
        print(f"Selected name: {selected_name}")
        start_window.destroy()
        
        if selected_name == "Add New Child":
            new_child_window = tk.Toplevel(root)
            new_child_window.title("Add New Child")
            new_child_window.geometry("500x400")
            new_child_window.configure(bg="#FFF9B1")
            add_credit_line(new_child_window)
            
            tk.Label(new_child_window, text="Enter new child's name:", 
                    font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=20)
            name_entry = tk.Entry(new_child_window, font=("Arial", 14), width=20)
            name_entry.pack(pady=10)
            name_entry.focus_set()
            
            tk.Label(new_child_window, text="Enter class (1-8):", 
                    font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=20)
            class_entry = tk.Entry(new_child_window, font=("Arial", 14), width=5)
            class_entry.pack(pady=10)
            
            def submit_new_child():
                new_name = name_entry.get().strip()
                new_class_str = class_entry.get().strip()
                
                if not new_name:
                    new_name = "Student"
                
                try:
                    new_class = int(new_class_str)
                    if not 1 <= new_class <= 8:
                        messagebox.showerror("Error", "Class must be between 1 and 8.", parent=new_child_window)
                        return
                except ValueError:
                    new_class = 1
                
                table = dbf.Table(USERS_DBF)
                table.open(dbf.READ_WRITE)
                table.append({'name': new_name.upper(), 'class': new_class})
                table.close()
                
                new_child_window.destroy()
                root.deiconify()
                root.set_user(new_name, new_class)
            
            tk.Button(new_child_window, text="Submit", font=("Arial", 14, "bold"), 
                     bg="#4CAF50", fg="white", width=15, height=2, 
                     command=submit_new_child).pack(pady=20)
            
            new_child_window.grab_set()
            root.wait_window(new_child_window)
        else:
            table = dbf.Table(USERS_DBF)
            table.open()
            for user in table:
                if user['name'].strip().upper() == selected_name.upper():
                    class_level = user['class']
                    table.close()
                    root.deiconify()
                    root.set_user(selected_name, class_level)
                    return
            table.close()
            root.deiconify()
            root.set_user(selected_name, 1)

    # Get list of users
    table = dbf.Table(USERS_DBF)
    table.open()
    users = [rec['name'].strip() for rec in table]
    table.close()
    
    if not users:
        # First time setup - create first user
        new_child_window = tk.Toplevel(root)
        new_child_window.title("Welcome to Fun Learning!")
        new_child_window.geometry("500x400")
        new_child_window.configure(bg="#FFF9B1")
        add_credit_line(new_child_window)
        
        tk.Label(new_child_window, text="Enter your name:", 
                font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=20)
        name_entry = tk.Entry(new_child_window, font=("Arial", 14), width=20)
        name_entry.pack(pady=10)
        name_entry.focus_set()
        
        tk.Label(new_child_window, text="Enter your class (1-8):", 
                font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=20)
        class_entry = tk.Entry(new_child_window, font=("Arial", 14), width=5)
        class_entry.pack(pady=10)
        
        def submit_first_child():
            new_name = name_entry.get().strip()
            new_class_str = class_entry.get().strip()
            
            if not new_name:
                new_name = "Student"
            
            try:
                new_class = int(new_class_str)
                if not 1 <= new_class <= 8:
                    messagebox.showerror("Error", "Class must be between 1 and 8.", parent=new_child_window)
                    return
            except ValueError:
                new_class = 1
            
            table = dbf.Table(USERS_DBF)
            table.open(dbf.READ_WRITE)
            table.append({'name': new_name.upper(), 'class': new_class})
            table.close()
            
            new_child_window.destroy()
            root.deiconify()
            root.set_user(new_name, new_class)
        
        tk.Button(new_child_window, text="Submit", font=("Arial", 14, "bold"), 
                 bg="#4CAF50", fg="white", width=15, height=2, 
                 command=submit_first_child).pack(pady=20)
        
        new_child_window.grab_set()
        root.wait_window(new_child_window)
        return "Student", 1
    else:
        # Show startup window with user selection
        start_window = tk.Toplevel(root)
        start_window.title("Welcome to Fun Learning!")
        start_window.geometry("500x400")
        start_window.configure(bg="#FFF9B1")
        add_credit_line(start_window)
        
        tk.Label(start_window, text="Choose your name:", 
                font=("Arial", 18, "bold"), bg="#FFF9B1", fg="#333").pack(pady=30)
        
        name_var = tk.StringVar(start_window)
        name_var.set(users[0])
        users.append("Add New Child")
        
        dropdown = ttk.OptionMenu(start_window, name_var, *users)
        dropdown.config(width=20)
        dropdown["menu"].config(font=("Arial", 14))
        dropdown.pack(pady=20)
        
        tk.Button(start_window, text="Start", font=("Arial", 14, "bold"), 
                 bg="#4CAF50", fg="white", width=15, height=2, 
                 command=select_user).pack(pady=20)
        
        start_window.grab_set()
        root.wait_window(start_window)
        return users[0], 1

# Simple word validation - no spell check
def is_valid_word(word):
    """Check if word meets basic criteria"""
    return len(word) >= 3 and len(word) <= 8 and word.isalpha()

# Add word module - simplified without spell check
def add_word():
    def submit_word():
        word = entry.get().strip()
        
        if not word:
            messagebox.showerror("Error", "Please enter a word.", parent=add_window)
            return
        
        # Basic validation
        if not is_valid_word(word):
            messagebox.showerror("Error", "Word must be 3-8 letters and contain only alphabets.", parent=add_window)
            entry.delete(0, tk.END)
            entry.focus()
            return
        
        # Save the word to DBF
        try:
            table = dbf.Table(WORDS_DBF)
            table.open(dbf.READ_WRITE)
            
            # Check if word already exists
            existing_words = [rec['word'].strip().lower() for rec in table]
            if word.lower() in existing_words:
                messagebox.showinfo("Info", f"Word '{word}' already exists!", parent=add_window)
            else:
                table.append({'word': word.upper()})
                messagebox.showinfo("Success", f"Word '{word}' saved successfully!", parent=add_window)
                entry.delete(0, tk.END)
            
            table.close()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save word: {str(e)}", parent=add_window)
        
        entry.focus()

    def close_add_window():
        add_window.destroy()

    add_window = tk.Toplevel(root)
    add_window.title("Add Word")
    add_window.geometry("500x400")
    add_window.configure(bg="#FFF9B1")
    add_credit_line(add_window)
    
    tk.Label(
        add_window, 
        text=f"{child_name}, enter a 3-8 letter word:", 
        font=("Arial", 18, "bold"), 
        bg="#FFF9B1", 
        fg="#333"
    ).pack(pady=30)
    
    entry = tk.Entry(add_window, font=("Arial", 16), width=25)
    entry.pack(pady=20)
    entry.focus()
    
    # Bind Enter key to submit
    entry.bind('<Return>', lambda event: submit_word())
    
    button_frame = tk.Frame(add_window, bg="#FFF9B1")
    button_frame.pack(pady=20)
    
    tk.Button(
        button_frame, 
        text="Submit", 
        font=("Arial", 14, "bold"), 
        bg="#4CAF50", 
        fg="white", 
        width=12, 
        height=2, 
        command=submit_word
    ).pack(side=tk.LEFT, padx=10)
    
    tk.Button(
        button_frame, 
        text="Close", 
        font=("Arial", 14, "bold"), 
        bg="#F44336", 
        fg="white", 
        width=12, 
        height=2, 
        command=close_add_window
    ).pack(side=tk.LEFT, padx=10)

# Get saved words
def get_saved_words():
    try:
        table = dbf.Table(WORDS_DBF)
        table.open()
        words = [rec['word'].strip().lower() for rec in table if rec['word'].strip()]
        table.close()
        valid_words = [w for w in words if 3 <= len(w) <= 8]
        return valid_words
    except Exception as e:
        print(f"Error reading words: {e}")
        return []

# Generate word with blank
def generate_blank_word(word):
    if len(word) == 0:
        return "_", "?"
    pos = random.randint(0, len(word) - 1)
    blanked = word[:pos] + '_' + word[pos+1:]
    return blanked, word[pos]

# Custom dialog for results
def show_result_dialog(title, message, continue_cmd, back_cmd, parent):
    dialog = tk.Toplevel(parent)
    dialog.title(title)
    dialog.geometry("500x400")
    dialog.configure(bg="#FFF9B1")
    add_credit_line(dialog)
    dialog.transient(parent)
    dialog.grab_set()
    
    tk.Label(dialog, text=message, font=("Arial", 16), bg="#FFF9B1", fg="#333", wraplength=400).pack(pady=30)
    
    button_frame = tk.Frame(dialog, bg="#FFF9B1")
    button_frame.pack(pady=20)
    
    if continue_cmd:
        tk.Button(
            button_frame, 
            text="Continue", 
            font=("Arial", 12, "bold"), 
            bg="#4CAF50", 
            fg="white", 
            width=15, 
            height=2, 
            command=lambda: [dialog.destroy(), continue_cmd()]
        ).pack(side=tk.LEFT, padx=10)
    
    if back_cmd:
        tk.Button(
            button_frame, 
            text="Back to Main", 
            font=("Arial", 12, "bold"), 
            bg="#F44336", 
            fg="white", 
            width=15, 
            height=2, 
            command=lambda: [dialog.destroy(), back_cmd()]
        ).pack(side=tk.LEFT, padx=10)

# Word exercise module
def word_exercise():
    words = get_saved_words()
    if not words:
        show_result_dialog("Error", "No words saved yet. Add some words first!", None, None, root)
        return
    
    score = 0
    total = min(5, len(words))
    current = 0
    attempts = [0] * total
    used_words = random.sample(words, total)

    def next_word():
        nonlocal current, score
        if current >= total:
            show_result_dialog(
                "Score", 
                f"{child_name}, you got {score}/{total} correct!", 
                None, 
                None, 
                root
            )
            return
        
        word = used_words[current]
        blanked, correct_letter = generate_blank_word(word)
        
        dialog = tk.Toplevel(root)
        dialog.title("Word Exercise")
        dialog.geometry("500x400")
        dialog.configure(bg="#FFF9B1")
        add_credit_line(dialog)
        dialog.transient(root)
        dialog.grab_set()
        
        tk.Label(
            dialog, 
            text=f"Word {current + 1}/{total}: Fill in the blank", 
            font=("Arial", 16, "bold"), 
            bg="#FFF9B1", 
            fg="#333"
        ).pack(pady=10)
        
        tk.Label(
            dialog, 
            text=blanked, 
            font=("Arial", 24, "bold"), 
            bg="#FFF9B1", 
            fg="#2196F3"
        ).pack(pady=20)
        
        entry = tk.Entry(dialog, font=("Arial", 18), width=5, justify='center')
        entry.pack(pady=20)
        entry.focus()
        
        def check_answer():
            nonlocal score, current
            guess = entry.get().strip().lower()
            
            if len(guess) == 1 and guess == correct_letter.lower():
                score += 1
                dialog.destroy()
                current += 1
                show_result_dialog("Correct", "Well done! ??", next_word, None, root)
            else:
                attempts[current] += 1
                if attempts[current] < 3:
                    dialog.destroy()
                    show_result_dialog(
                        "Try Again", 
                        f"Not quite right. Attempt {attempts[current]}/3.", 
                        next_word,
                        None, 
                        root
                    )
                else:
                    dialog.destroy()
                    show_result_dialog(
                        "Solution", 
                        f"The correct letter was '{correct_letter}'. The word is '{word}'.",
                        next_word, 
                        None, 
                        root
                    )
                    current += 1
        
        entry.bind('<Return>', lambda event: check_answer())
        
        tk.Button(
            dialog, 
            text="Submit", 
            font=("Arial", 14, "bold"), 
            bg="#4CAF50", 
            fg="white", 
            width=15, 
            height=2, 
            command=check_answer
        ).pack(pady=20)
    
    next_word()

# Generate math problem based on class level
def generate_math_problem(level):
    ops = ['+', '-', '*', '/']
    op = random.choice(ops)
    max_num = 10 ** (level // 2 + 1)
    
    if op in ['+', '-']:
        a = random.randint(1, max_num)
        b = random.randint(1, max_num // 2)
        if op == '+':
            ans = a + b
        else:
            ans = a - b if a > b else b - a
    elif op == '*':
        a = random.randint(1, max_num // 10)
        b = random.randint(1, 10 + level)
        ans = a * b
    else:
        b = random.randint(1, 10 + level)
        ans = random.randint(1, max_num // b)
        a = ans * b
    
    ans_str = str(ans)
    pos = random.randint(0, len(ans_str) - 1)
    blanked = ans_str[:pos] + '_' + ans_str[pos+1:]
    problem = f"{a} {op} {b} = {blanked}"
    return problem, ans_str[pos]

# Math exercise module
def math_exercise():
    score = 0
    total = 10
    current = 0

    def next_problem():
        nonlocal current, score
        if current >= total:
            show_result_dialog("Score", f"{child_name}, you got {score}/{total} correct!", lambda: math_exercise(), lambda: None, root)
            return
        
        problem, correct_digit = generate_math_problem(child_class)
        dialog = tk.Toplevel(root)
        dialog.title("Math Exercise")
        dialog.geometry("600x450")
        dialog.configure(bg="#FFF9B1")
        add_credit_line(dialog)
        tk.Label(dialog, text=f"Solve: {problem}", font=("Arial", 24, "bold"), bg="#FFF9B1", fg="#333").pack(pady=40)
        entry = tk.Entry(dialog, font=("Arial", 18), width=10)
        entry.pack(pady=20)
        
        def submit_guess():
            nonlocal score, current
            guess = entry.get().strip()
            dialog.destroy()
            if len(guess) == 1 and guess.isdigit() and guess == correct_digit:
                score += 1
                show_result_dialog("Correct", "Good job!", next_problem, lambda: None, root)
            else:
                attempts[current] += 1
                if attempts[current] < 3:
                    show_result_dialog("Wrong", f"Try again. Attempt {attempts[current]}/3.", lambda: try_again(problem, correct_digit), lambda: None, root)
                else:
                    show_result_dialog("Suggestion", f"Correct digit is '{correct_digit}'.", next_problem, lambda: None, root)
        
        def try_again(problem, correct_digit):
            dialog = tk.Toplevel(root)
            dialog.title("Math Exercise")
            dialog.geometry("600x450")
            dialog.configure(bg="#FFF9B1")
            add_credit_line(dialog)
            tk.Label(dialog, text=f"Solve: {problem}", font=("Arial", 24, "bold"), bg="#FFF9B1", fg="#333").pack(pady=40)
            entry = tk.Entry(dialog, font=("Arial", 18), width=10)
            entry.pack(pady=20)
            tk.Button(dialog, text="Submit", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=submit_guess).pack(pady=20)
        
        tk.Button(dialog, text="Submit", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=submit_guess).pack(pady=20)
    
    attempts = [0] * total
    next_problem()

# Main GUI
root = tk.Tk()
root.title("Child Learning App")
root.geometry("800x600")
root.configure(bg="#FFF9B1")
add_credit_line(root)
root.iconify()



# Function to set user after selection
def set_user(name, class_level):
    global child_name, child_class
    child_name, child_class = name, class_level
    # Clear any existing widgets
    for widget in root.winfo_children():
        widget.destroy()
        
    tk.Label(root, text=f"Welcome, {child_name}!", font=("Arial", 24, "bold"), bg="#FFF9B1", fg="#333").pack(pady=30)
    tk.Button(root, text="Add Words", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=20, height=2, command=add_word).pack(pady=20)
    tk.Button(root, text="Word Exercises", font=("Arial", 14, "bold"), bg="#2196F3", fg="white", width=20, height=2, command=word_exercise).pack(pady=20)
    tk.Button(root, text="Math Exercises", font=("Arial", 14, "bold"), bg="#FF9800", fg="white", width=20, height=2, command=math_exercise).pack(pady=20)
    tk.Button(root, text="Quit", font=("Arial", 14, "bold"), bg="#F44336", fg="white", width=20, height=2, command=root.quit).pack(pady=20)

    add_credit_line(root)

root.set_user = set_user

# Get user data
get_user_data(root)

root.mainloop()