import tkinter as tk
from tkinter import messagebox, simpledialog
from dbfread import DBF
import os

STAFFFILE = "STAFF.DBF"

def liststaff():
    if not os.path.exists(STAFFFILE):
        messagebox.showerror("Error", "STAFF.DBF not found")
        return []
    table = DBF(STAFFFILE, load=True)
    staff_list = []
    for rec in table:
        staff_list.append((rec.get('STAFFID'), rec.get('NAME'), rec.get('DESIGNATION'), rec.get('DEPARTMENT')))
    return staff_list

def issuetostaff(staff_id, staff_name):
    # Placeholder for issuing logic - not implemented in original
    messagebox.showinfo("Issue to Staff", f"Issued to {staff_name} (ID: {staff_id})\nNote: Actual transaction writing not implemented yet.")

def on_liststaff_click():
    staff = liststaff()
    staff_str = "\n".join(f"{sid} - {name} ({desig}, {dept})" for sid, name, desig, dept in staff)
    if staff_str:
        messagebox.showinfo("Staff Records", staff_str)
    else:
        messagebox.showinfo("Staff Records", "No staff found or file missing.")

def on_selectstaff_click():
    staff = liststaff()
    if not staff:
        return
    select_win = tk.Toplevel(root)
    select_win.title("Select Staff")

    tk.Label(select_win, text="Select Staff to Issue:").pack()

    listbox = tk.Listbox(select_win)
    for idx, (sid, name, desig, dept) in enumerate(staff):
        listbox.insert(idx, f"{sid} - {name} ({desig})")
    listbox.pack()

    def on_issue():
        sel = listbox.curselection()
        if not sel:
            messagebox.showwarning("Selection Error", "Please select a staff member")
            return
        idx = sel[0]
        staff_id, staff_name, _, _ = staff[idx]
        issuetostaff(staff_id, staff_name)
        select_win.destroy()

    issue_btn = tk.Button(select_win, text="Issue to Selected Staff", command=on_issue)
    issue_btn.pack()

root = tk.Tk()
root.title("Staff Management")

tk.Button(root, text="List Staff", command=on_liststaff_click).pack(pady=5)
tk.Button(root, text="Select Staff and Issue", command=on_selectstaff_click).pack(pady=5)
tk.Button(root, text="Exit", command=root.quit).pack(pady=5)

root.mainloop()
