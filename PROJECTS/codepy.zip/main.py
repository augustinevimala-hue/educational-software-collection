import tkinter as tk
from tkinter import ttk
import sqlite3
import random
from auth.login import LoginScreen

class MainApp(tk.Tk):
    def __init__(self):
        super().__init__()
        
        self.title("Kids Learning App")
        self.geometry("800x600")
        self.configure(bg="#f0f0f0")
        
        # Initialize database
        self.init_database()
        
        # Start with login screen
        self.show_login()
        
    def init_database(self):
        conn = sqlite3.connect('learning.db')
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT NOT NULL,
                level TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS words (
                id INTEGER PRIMARY KEY,
                word TEXT NOT NULL,
                user_id INTEGER,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        conn.commit()
        conn.close()
    
    def show_login(self):
        LoginScreen(self)

    def start_session(self, username):
        """Called by LoginScreen; clear UI and start TypingExercise."""
        # remove any existing widgets/frames
        for w in self.winfo_children():
            w.destroy()
        TypingExercise(self, username=username)

# ...existing code...


class TypingExercise(tk.Frame):
    DEFAULT_WORDS = [
        "cat","dog","mom","dad","ball","apple","book","sun","tree","milk",
        "cup","car","house","pen","bird","fish","hat","shoe","door","bed"
    ]

    def __init__(self, parent, username="Guest", words=None, num_words=5):
        super().__init__(parent)
        self.parent = parent
        self.username = username or "Guest"
        self.pack(fill=tk.BOTH, expand=True)
        self.words = words[:] if words else random.sample(self.DEFAULT_WORDS, min(len(self.DEFAULT_WORDS), num_words))
        self.num_words = num_words
        self.index = 0
        self.letter_index = 0
        self.key_buttons = {}
        self.current_user_id = self.get_or_create_user(self.username)
        self.create_widgets()
        self.show_word()
        self.bind_all("<Key>", self.on_key_press)

    def create_widgets(self):
        top = ttk.Label(self, text="Type words given above for typing exercise", font=("Arial", 16))
        top.pack(pady=8)

        self.word_label = ttk.Label(self, text="", font=("Arial", 28, "bold"))
        self.word_label.pack(pady=10)

        entry_frame = ttk.Frame(self)
        entry_frame.pack(pady=6)
        self.entry_var = tk.StringVar()
        self.entry = ttk.Entry(entry_frame, textvariable=self.entry_var, font=("Arial", 20), width=20)
        self.entry.pack()
        self.entry.focus_set()

        kb_frame = ttk.Frame(self)
        kb_frame.pack(pady=12)
        rows = ["qwertyuiop", "asdfghjkl", "zxcvbnm"]
        for r, row in enumerate(rows):
            row_frame = ttk.Frame(kb_frame)
            row_frame.pack(pady=3)
            for ch in row:
                # make on-screen keyboard visual-only: clicking does nothing
                b = tk.Button(row_frame, text=ch.upper(), width=4, height=2,
                              command=lambda: None)
                b.pack(side=tk.LEFT, padx=2)
                self.key_buttons[ch] = b

        control_frame = ttk.Frame(self)
        control_frame.pack(pady=10)
        self.enter_btn = tk.Button(control_frame, text="Enter", width=8, command=self.on_enter_pressed)
        self.enter_btn.pack(side=tk.LEFT, padx=6)
        back_btn = tk.Button(control_frame, text="Back", width=8, command=self.on_back)
        back_btn.pack(side=tk.LEFT, padx=6)
        quit_btn = tk.Button(control_frame, text="Quit", width=8, command=self.on_quit)
        quit_btn.pack(side=tk.LEFT, padx=6)

        self.feedback = ttk.Label(self, text="", font=("Arial", 12))
        self.feedback.pack(pady=6)

    def show_word(self):
        if self.index >= len(self.words):
            self.word_label.config(text="All done!")
            self.entry_var.set("")
            self.highlight_none()
            self.feedback.config(text=f"Finished {len(self.words)} words. Well done!")
            return
        self.current_word = self.words[self.index].lower()
        self.word_label.config(text=self.current_word.upper())
        self.letter_index = 0
        self.entry_var.set("")
        self.update_highlight()

    def update_highlight(self):
        self.highlight_none()
        if self.letter_index < len(self.current_word):
            next_ch = self.current_word[self.letter_index]
            btn = self.key_buttons.get(next_ch)
            if btn:
                btn.config(bg="#ffd54f")
        else:
            self.enter_btn.config(bg="#a5d6a7")

    def highlight_none(self):
        for b in self.key_buttons.values():
            try:
                b.config(bg="SystemButtonFace")
            except:
                b.config(bg="#f0f0f0")
        self.enter_btn.config(bg="SystemButtonFace")

    def on_virtual_key(self, ch):
        self.process_char(ch)

    def on_key_press(self, event):
        ch = event.char.lower()
        if not ch:
            if event.keysym == "Return":
                self.on_enter_pressed()
            elif event.keysym == "Escape":
                self.on_back()
            return
        if ch.isalpha():
            self.process_char(ch)

    def process_char(self, ch):
        expected = self.current_word[self.letter_index] if self.letter_index < len(self.current_word) else None
        if expected and ch == expected:
            current = self.entry_var.get() + ch
            self.entry_var.set(current)
            self.letter_index += 1
            self.feedback.config(text="")
            if self.letter_index >= len(self.current_word):
                self.save_word(self.current_word)
                self.index += 1
                self.parent.after(400, self.show_word)
            else:
                self.update_highlight()
        else:
            self.feedback.config(text="Try again", foreground="red")
            if expected:
                btn = self.key_buttons.get(expected)
                if btn:
                    original = btn.cget("bg")
                    btn.config(bg="#ff8a80")
                    self.parent.after(200, lambda b=btn, c=original: b.config(bg=c))

    def on_enter_pressed(self):
        if self.entry_var.get().lower() == self.current_word:
            self.save_word(self.current_word)
            self.index += 1
            self.show_word()
        else:
            self.feedback.config(text="Not complete yet", foreground="red")

    def get_or_create_user(self, username):
        conn = sqlite3.connect('learning.db')
        cur = conn.cursor()
        cur.execute("SELECT id FROM users WHERE username = ?", (username,))
        row = cur.fetchone()
        if row:
            user_id = row[0]
        else:
            cur.execute("INSERT INTO users (username, level) VALUES (?, ?)", (username, "KG"))
            user_id = cur.lastrowid
            conn.commit()
        conn.close()
        return user_id

    def save_word(self, word):
        conn = sqlite3.connect('learning.db')
        cur = conn.cursor()
        cur.execute("INSERT INTO words (word, user_id) VALUES (?, ?)", (word, self.current_user_id))
        conn.commit()
        conn.close()

    def on_back(self):
        self.unbind_all("<Key>")
        self.destroy()
        self.parent.show_login()

    def on_quit(self):
        self.unbind_all("<Key>")
        self.parent.destroy()
# ...existing code...
if __name__ == "__main__":
    app = MainApp()
    app.mainloop()