import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import random
import pyttsx3
from ctypes import windll
import pygame

class KidsLearningApp(tk.Tk):
    def __init__(self):
        super().__init__()
        windll.shcore.SetProcessDpiAwareness(1)  # Fix for high-DPI displays
        self.title("Kids Typing Adventure")
        self.geometry("800x600")
        self.configure(bg="#e6f3ff")  # Light blue background
        self.engine = pyttsx3.init()  # Initialize text-to-speech
        self.engine.setProperty('rate', 120)  # Slower for kids
        pygame.mixer.init()  # Initialize sound
        self.current_user_id = None
        self.current_username = "Guest"
        self.init_database()
        self.show_login()
        self.style = ttk.Style()
        self.style.configure("TButton", font=("Arial", 20, "bold"), padding=10)
        self.style.configure("TRadiobutton", font=("Arial", 24))
        self.style.configure("TEntry", font=("Arial", 24))
        self.style.configure("TLabel", font=("Arial", 30, "bold"))

    def play_sound(self, sound_file):
        try:
            pygame.mixer.music.load(sound_file)
            pygame.mixer.music.play()
        except pygame.error:
            pass  # Silent if no file or error

    def init_database(self):
        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            level TEXT DEFAULT 'KG'
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS words (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            word TEXT NOT NULL,
            user_id INTEGER,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            exercise TEXT,
            score INTEGER,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )''')
        conn.commit()
        conn.close()

    def show_login(self):
        for widget in self.winfo_children():
            widget.destroy()
        LoginScreen(self)

    def start_session(self, username, user_id):
        self.current_username = username
        self.current_user_id = user_id
        for widget in self.winfo_children():
            widget.destroy()
        MainMenu(self, username, user_id)

    def exit_app(self):
        for widget in self.winfo_children():
            widget.destroy()
        tk.Label(self, text="Thanks for using this spellcheck software. Get back whenever you want. Bye for now!",
                 font=("Arial", 30, "bold"), bg="#e6f3ff", fg="#ff4081").pack(expand=True)
        self.engine.say("Goodbye for now!")
        self.engine.runAndWait()
        self.after(2000, self.destroy)

class LoginScreen(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.pack(fill=tk.BOTH, expand=True)
        self.create_widgets()

    def create_widgets(self):
        tk.Label(self, text="Welcome to Kids Typing Adventure!", font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=20)
        tk.Label(self, text="Select or Enter Username", font=("Arial", 24), bg="#e6f3ff").pack(pady=10)

        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        c.execute("SELECT id, username FROM users")
        users = c.fetchall()
        conn.close()
        usernames = ["Guest"] + [u[1] for u in users]
        self.user_var = tk.StringVar(value="Guest")
        ttk.Combobox(self, textvariable=self.user_var, values=usernames, state="normal", font=("Arial", 20)).pack(pady=10)
        
        tk.Label(self, text="New Username (optional)", font=("Arial", 20), bg="#e6f3ff").pack()
        self.new_user_entry = ttk.Entry(self, font=("Arial", 20))
        self.new_user_entry.pack(pady=5)
        self.new_user_entry.bind("<Return>", lambda e: self.login())

        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=20)
        ttk.Button(btn_frame, text="Login", command=self.login).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)
        tk.Label(self, text="Created by Augustine Anbananthan\nDeveloper Note: This is a fun learning tool for kids!", font=("Arial", 12), bg="#e6f3ff").pack(side=tk.BOTTOM, pady=10)

    def login(self):
        username = self.user_var.get()
        new_username = self.new_user_entry.get().strip()
        user_id = None

        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        if new_username:
            try:
                c.execute("INSERT INTO users (username) VALUES (?)", (new_username,))
                conn.commit()
                user_id = c.lastrowid
                username = new_username
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "Username already exists!")
                conn.close()
                return
        elif username != "Guest":
            c.execute("SELECT id FROM users WHERE username = ?", (username,))
            row = c.fetchone()
            user_id = row[0] if row else None
        conn.close()
        self.parent.start_session(username, user_id)

class MainMenu(tk.Frame):
    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.pack(fill=tk.BOTH, expand=True)
        self.create_widgets()

    def create_widgets(self):
        tk.Label(self, text=f"Hello, {self.username}!", font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=20)
        tk.Label(self, text="Choose an activity!", font=("Arial", 24), bg="#e6f3ff", fg="#ff4081").pack(pady=10)  # Instruction
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=20)
        buttons = [
            ("Typing Exercise", self.open_typing),
            ("Spell Check Quiz", self.open_spellcheck),
            ("Math Practice", self.open_math),
            ("View Scores", self.view_scores),
            ("Read Words", self.read_words),
            ("Switch User", self.switch_user),
            ("Admin", self.open_admin),
            ("Quit", self.parent.exit_app)
        ]
        for i, (text, cmd) in enumerate(buttons):
            ttk.Button(btn_frame, text=text, command=cmd).grid(row=i//2, column=i%2, padx=15, pady=15)
        tk.Label(self, text="Created by Augustine Anbananthan\nDeveloper Note: Have fun learning!", font=("Arial", 12), bg="#e6f3ff").pack(side=tk.BOTTOM, pady=10)

    def open_typing(self): self.destroy(); TypingExercise(self.parent, self.username, self.user_id)
    def open_spellcheck(self): self.destroy(); SpellCheckQuiz(self.parent, self.username, self.user_id)
    def open_math(self): self.destroy(); MathExercise(self.parent, self.username, self.user_id)
    def view_scores(self):
        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        c.execute("SELECT exercise, score FROM scores WHERE user_id = ? ORDER BY id DESC", (self.user_id,))
        scores = c.fetchall()
        conn.close()
        text = "\n".join([f"{ex}: {sc}/10" for ex, sc in scores]) if scores else "No scores yet."
        messagebox.showinfo("Scores", text, parent=self.parent)
    def read_words(self): self.destroy(); ReadWords(self.parent, self.username, self.user_id)
    def switch_user(self): self.destroy(); self.parent.show_login()
    def open_admin(self): self.destroy(); AdminPanel(self.parent, self.username, self.user_id)

class TypingExercise(tk.Frame):
    DEFAULT_WORDS = ["cat", "dog", "mom", "dad", "ball", "apple", "book", "sun", "tree", "milk", "cup", "car", "house", "pen", "bird", "fish", "hat", "shoe", "door", "bed"]

    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.words = random.sample(self.DEFAULT_WORDS, 5)
        self.current_word_index = 0
        self.current_letter_index = 0
        self.pack(fill=tk.BOTH, expand=True)
        self.key_buttons = {}
        self.create_widgets()
        self.show_word()

    def create_widgets(self):
        tk.Label(self, text="Type the word shown below", font=("Arial", 24), bg="#e6f3ff").pack(pady=10)
        tk.Label(self, text="Press the highlighted key!", font=("Arial", 20), bg="#e6f3ff", fg="#ff4081").pack(pady=5)  # Instruction
        self.word_label = tk.Label(self, text="", font=("Arial", 36, "bold"), bg="#e6f3ff", fg="#d81b60")
        self.word_label.pack(pady=10)
        self.entry_var = tk.StringVar()
        self.entry = ttk.Entry(self, textvariable=self.entry_var, font=("Arial", 28), width=20)
        self.entry.pack(pady=10)
        self.entry.bind("<Key>", self.on_key_press)
        self.entry.focus_set()

        kb_frame = ttk.Frame(self)
        kb_frame.pack(pady=10)
        rows = ["qwertyuiop", "asdfghjkl", "zxcvbnm"]
        for row in rows:
            row_frame = ttk.Frame(kb_frame)
            row_frame.pack()
            for ch in row:
                btn = tk.Button(row_frame, text=ch.upper(), width=5, height=2, bg="#bbdefb", font=("Arial", 20, "bold"))
                btn.pack(side=tk.LEFT, padx=3)
                self.key_buttons[ch] = btn

        self.enter_btn = tk.Button(self, text="Enter", width=12, bg="#a5d6a7", command=self.check_word, font=("Arial", 20, "bold"))
        self.entry.bind("<Key>", self.on_key_press) # Existing binding
        self.entry.bind("<Escape>", self.back)      # NEW: Bind Escape key to go back
        self.entry.bind("<F1>", self.back)          # NEW: Optional function key binding for back
        self.entry.bind("<Return>", self.check_word) # Ensures Return key works for submit
        self.enter_btn.pack(pady=5)
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)
        self.feedback = tk.Label(self, text="", font=("Arial", 24), bg="#e6f3ff")
        self.feedback.pack(pady=5)

    def show_word(self):
        if self.current_word_index >= len(self.words):
            self.word_label.config(text="All done!", fg="#4caf50")
            self.entry.config(state="disabled")
            self.enter_btn.config(state="disabled")
            self.feedback.config(text="Great job!", fg="green")
            ttk.Button(self, text="Back to Menu", command=self.back).pack(pady=20)
            self.parent.play_sound("correct.wav")
            return
        self.current_word = self.words[self.current_word_index].lower()
        self.word_label.config(text=self.current_word.upper(), fg="#d81b60")
        self.letter_index = 0
        self.entry_var.set("")
        self.update_keyboard()
        self.speak(f"Type the word {self.current_word}")
        self.speak_letter()

    def update_keyboard(self):
        for btn in self.key_buttons.values():
            btn.config(bg="#bbdefb")
        self.enter_btn.config(bg="#a5d6a7")
        if self.current_letter_index < len(self.current_word):
            ch = self.current_word[self.current_letter_index]
            if ch in self.key_buttons:
                self.key_buttons[ch].config(bg="#ffd54f")
        else:
            self.enter_btn.config(bg="#4caf50")

    def speak(self, text):
        self.parent.engine.say(text)
        
    def speak_letter(self):
        if self.current_letter_index < len(self.current_word):
            self.speak(self.current_word[self.current_letter_index])

    def on_key_press(self, event):
        if event.keysym == "Return":
            self.check_word()
            return "break"
        if event.keysym == "Escape":
            self.back()
            return "break"
        ch = event.char.lower()
        if ch.isalpha():
            expected = self.current_word[self.current_letter_index] if self.current_letter_index < len(self.current_word) else None
            if expected and ch == expected:
                self.entry_var.set(self.entry_var.get() + ch)
                self.current_letter_index += 1
                self.feedback.config(text="")
                self.update_keyboard()
                self.speak_letter()
                self.parent.play_sound("correct.wav")
            else:
                self.feedback.config(text="Try again!", fg="red")
                self.speak_letter()
                self.parent.play_sound("wrong.wav")
            return "break"  # Prevent default insertion

    def check_word(self):
        if self.entry_var.get().lower() == self.current_word:
            self.save_word()
            self.current_word_index += 1
            self.show_word()
            self.parent.play_sound("correct.wav")
        else:
            self.feedback.config(text="Not complete yet!", fg="red")
            self.parent.play_sound("wrong.wav")
            self.entry_var.set("")  # Reset on wrong
            self.current_letter_index = 0
            self.update_keyboard()

    def save_word(self):
        if self.user_id:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            c.execute("INSERT INTO words (word, user_id) VALUES (?, ?)", (self.current_word, self.user_id))
            conn.commit()
            conn.close()

    def back(self):
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

class SpellCheckQuiz(tk.Frame):
    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.words = random.sample(TypingExercise.DEFAULT_WORDS, 10)
        self.current_question = 0
        self.attempts = 0
        self.score = 0
        self.pack(fill=tk.BOTH, expand=True)
        self.choice_var = tk.StringVar()
        self.create_widgets()
        self.show_question()
        self.speak_instruction()
        self.parent.engine.runAndWait()
    def speak_instruction(self):
        instruction = "You can choose with tab or mouse, select with space bar and press enter or click mouse to submit your answer"
        self.parent.engine.say(instruction)
        self.parent.engine.runAndWait()

    def create_widgets(self):
        tk.Label(self, text="Spell Check Quiz", font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=10)
        tk.Label(self, text="Choose the correct spelling!", font=("Arial", 24), bg="#e6f3ff", fg="#ff4081").pack(pady=5)  # Instruction
        self.word_label = tk.Label(self, text="", font=("Arial", 32, "bold"), bg="#e6f3ff")
        self.word_label.pack(pady=10)
        self.choices_frame = ttk.Frame(self)
        self.choices_frame.pack(pady=10)
        self.feedback = tk.Label(self, text="", font=("Arial", 24), bg="#e6f3ff")
        self.feedback.pack(pady=5)
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Submit", command=self.check_answer).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)

    def show_question(self):
        if self.current_question >= len(self.words):
            self.save_score()
            self.word_label.config(text=f"Quiz Done! Score: {self.score}/10", fg="#4caf50")
            self.choices_frame.destroy()
            self.feedback.config(text="")
            ttk.Button(self, text="Continue", command=self.restart_quiz).pack(pady=20)
            ttk.Button(self, text="Back to Menu", command=self.back).pack(pady=10)
            self.parent.play_sound("correct.wav")
            return
        self.attempts = 0
        self.choice_var.set("")
        current_word = self.words[self.current_question]
        self.word_label.config(text=f"Question {self.current_question + 1}: Choose the correct spelling", fg="#d81b60")
        choices = [current_word] + [self.scramble_word(current_word) for _ in range(3)]
        random.shuffle(choices)
        for widget in self.choices_frame.winfo_children():
            widget.destroy()
        self.radio_buttons = []
        for choice in choices:
            rb = ttk.Radiobutton(self.choices_frame, text=choice, value=choice, variable=self.choice_var, style="TRadiobutton")
            rb.pack(anchor="w", pady=5)
            self.radio_buttons.append(rb)
        self.feedback.config(text=f"Attempts left: 3", fg="#3f51b5")
        self.choices_frame.focus_set()
        self.bind_keys()
        self.speak_instruction()
    
    def bind_keys(self):
        self.parent.bind("<Tab>", self.tab_nav)
        self.parent.bind("<Up>", self.tab_nav)
        self.parent.bind("<Down>", self.tab_nav_down)
        self.parent.bind("<space>", self.select_radio)
        self.parent.bind("<Return>", self.check_answer)

    def tab_nav(self, event):
        current = self.parent.focus_get()
        index = self.radio_buttons.index(current) if current in self.radio_buttons else -1
        next_index = (index + 1) % len(self.radio_buttons)
        self.radio_buttons[next_index].focus_set()
        return "break"

    def tab_nav_down(self, event):
        current = self.parent.focus_get()
        index = self.radio_buttons.index(current) if current in self.radio_buttons else -1
        next_index = (index - 1) % len(self.radio_buttons)
        self.radio_buttons[next_index].focus_set()
        return "break"

    def select_radio(self, event):
        current = self.parent.focus_get()
        if current in self.radio_buttons:
            self.choice_var.set(current.cget("value"))
        return "break"

    def scramble_word(self, word):
        chars = list(word)
        random.shuffle(chars)
        new_word = "".join(chars)
        return new_word if new_word != word else self.scramble_word(word)

    def check_answer(self, event=None):
        selected = self.choice_var.get()
        if not selected:
            self.feedback.config(text="Select an option!", fg="red")
            self.parent.play_sound("wrong.wav")
            return
        correct = self.words[self.current_question]
        if selected == correct:
            self.score += 1
            self.feedback.config(text="Correct!", fg="green")
            self.current_question += 1
            self.after(1000, self.show_question)
            self.parent.play_sound("correct.wav")
        else:
            self.attempts += 1
            if self.attempts >= 3:
                self.feedback.config(text=f"Correct spelling: {correct}", fg="red", font=("Arial", 32, "bold"))
                self.current_question += 1
                self.after(1500, self.show_question)
                self.parent.play_sound("wrong.wav")
            else:
                self.feedback.config(text=f"Wrong! Attempts left: {3 - self.attempts}", fg="red")
                self.choice_var.set("")  # Reset selection
                self.parent.play_sound("wrong.wav")

    def save_score(self):
        if self.user_id:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            c.execute("INSERT INTO scores (user_id, exercise, score) VALUES (?, ?, ?)", (self.user_id, "SpellCheck", self.score))
            conn.commit()
            conn.close()

    def restart_quiz(self):
        self.destroy()
        SpellCheckQuiz(self.parent, self.username, self.user_id)

    def back(self):
        self.parent.unbind("<Tab>")
        self.parent.unbind("<Up>")
        self.parent.unbind("<Down>")
        self.parent.unbind("<space>")
        self.parent.unbind("<Return>")
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

class MathExercise(tk.Frame):
    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.questions = [(random.randint(1, 10), random.randint(1, 10)) for _ in range(10)]
        self.current_question = 0
        self.score = 0
        self.pack(fill=tk.BOTH, expand=True)
        self.create_widgets()
        self.show_question()

    def create_widgets(self):
        tk.Label(self, text="Math Practice", font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=10)
        tk.Label(self, text="Type the number answer!", font=("Arial", 24), bg="#e6f3ff", fg="#ff4081").pack(pady=5)  # Instruction
        self.question_label = tk.Label(self, text="", font=("Arial", 36, "bold"), bg="#e6f3ff", fg="#d81b60")
        self.question_label.pack(pady=10)
        self.answer_var = tk.StringVar()
        self.answer_entry = ttk.Entry(self, textvariable=self.answer_var, font=("Arial", 28), width=10)
        self.answer_entry.pack(pady=10)
        self.answer_entry.bind("<Return>", self.check_answer)
        self.feedback = tk.Label(self, text="", font=("Arial", 24), bg="#e6f3ff")
        self.feedback.pack(pady=5)
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Submit", command=self.check_answer).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)

    def show_question(self):
        if self.current_question >= len(self.questions):
            self.save_score()
            self.question_label.config(text=f"Math Done! Score: {self.score}/10", fg="#4caf50")
            self.answer_entry.config(state="disabled")
            self.feedback.config(text="")
            ttk.Button(self, text="Continue", command=self.restart).pack(pady=20)
            ttk.Button(self, text="Back to Menu", command=self.back).pack(pady=10)
            self.parent.play_sound("correct.wav")
            return
        a, b = self.questions[self.current_question]
        self.question_label.config(text=f"{a} + {b} = ?", fg="#d81b60")
        self.answer_var.set("")
        self.answer_entry.focus()
        self.parent.engine.say(f"What is {a} plus {b}?")
        self.parent.engine.runAndWait()

    def check_answer(self, event=None):
        try:
            answer = int(self.answer_var.get())
            a, b = self.questions[self.current_question]
            if answer == a + b:
                self.score += 1
                self.feedback.config(text="Correct!", fg="green")
                self.current_question += 1
                self.after(1000, self.show_question)
                self.parent.play_sound("correct.wav")
            else:
                self.feedback.config(text="Try again!", fg="red")
                self.answer_var.set("")  # Reset on wrong
                self.parent.play_sound("wrong.wav")
        except ValueError:
            self.feedback.config(text="Enter a number!", fg="red")
            self.parent.play_sound("wrong.wav")

    def save_score(self):
        if self.user_id:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            c.execute("INSERT INTO scores (user_id, exercise, score) VALUES (?, ?, ?)", (self.user_id, "Math", self.score))
            conn.commit()
            conn.close()

    def restart(self):
        self.destroy()
        MathExercise(self.parent, self.username, self.user_id)

    def back(self):
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

class ReadWords(tk.Frame):
    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.pack(fill=tk.BOTH, expand=True)
        self.words = self.get_words()
        self.current_word = 0
        self.create_widgets()
        if self.words:
            self.show_word()

    def create_widgets(self):
        tk.Label(self, text="Read Your Words", font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=10)
        tk.Label(self, text="Listen and repeat!", font=("Arial", 24), bg="#e6f3ff", fg="#ff4081").pack(pady=5)  # Instruction
        self.word_label = tk.Label(self, text="No words yet.", font=("Arial", 36, "bold"), bg="#e6f3ff", fg="#d81b60")
        self.word_label.pack(pady=20)
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Next", command=self.next_word).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Repeat Aloud", command=self.read_aloud).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)

    def get_words(self):
        if not self.user_id:
            return []
        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        c.execute("SELECT word FROM words WHERE user_id = ? ORDER BY id", (self.user_id,))
        words = [row[0] for row in c.fetchall()]
        conn.close()
        return words

    def show_word(self):
        if self.current_word < len(self.words):
            self.word_label.config(text=self.words[self.current_word].upper(), fg="#d81b60")
            self.read_aloud()

    def next_word(self):
        self.current_word = (self.current_word + 1) % len(self.words) if self.words else 0
        if self.words:
            self.show_word()

    def read_aloud(self):
        if self.current_word < len(self.words):
            self.parent.engine.say(self.words[self.current_word])
            self.parent.engine.runAndWait()
            self.parent.after(2000, self.read_aloud)  # Repeat once after pause

    def back(self):
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

class AdminPanel(tk.Frame):
    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.pack(fill=tk.BOTH, expand=True)
        self.create_widgets()

    def create_widgets(self):
        tk.Label(self, text="Admin Panel", font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=10)
        tk.Label(self, text="Add or delete words", font=("Arial", 24), bg="#e6f3ff", fg="#ff4081").pack(pady=5)  # Instruction
        self.word_listbox = tk.Listbox(self, font=("Arial", 24), height=10)
        self.word_listbox.pack(pady=10, padx=20, fill=tk.BOTH)
        self.word_entry = ttk.Entry(self, font=("Arial", 24))
        self.word_entry.pack(pady=5)
        self.word_entry.bind("<Return>", lambda e: self.add_word())
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Add Word", command=self.add_word).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Delete Word", command=self.delete_word).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)
        self.load_words()

    def load_words(self):
        self.word_listbox.delete(0, tk.END)
        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        c.execute("SELECT word FROM words WHERE user_id = ? ORDER BY word", (self.user_id,))
        for row in c.fetchall():
            self.word_listbox.insert(tk.END, row[0])
        conn.close()

    def add_word(self):
        word = self.word_entry.get().strip().lower()
        if word:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            c.execute("INSERT INTO words (word, user_id) VALUES (?, ?)", (word, self.user_id))
            conn.commit()
            conn.close()
            self.word_entry.delete(0, tk.END)
            self.load_words()

    def delete_word(self):
        try:
            word = self.word_listbox.get(self.word_listbox.curselection())
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            c.execute("DELETE FROM words WHERE word = ? AND user_id = ?", (word, self.user_id))
            conn.commit()
            conn.close()
            self.load_words()
        except tk.TclError:
            messagebox.showerror("Error", "Select a word to delete!")

    def back(self):
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

if __name__ == "__main__":
    app = KidsLearningApp()
    app.mainloop()