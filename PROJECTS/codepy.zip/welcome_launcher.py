"""
Anbu Academic Centre Library System - Welcome Launcher
Python-based welcome screen with modern interface
"""

import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys
from pathlib import Path

class WelcomeLauncher:
    def __init__(self, root):
        self.root = root
        self.root.title("Anbu Academic Centre - Library Management System")
        self.root.geometry("900x700")
        self.root.configure(bg='#F0F0F0')
        
        # Center window on screen
        self.center_window()
        self.root.state('zoomed')
        
        # Create welcome interface
        self.create_welcome_interface()
        
    def center_window(self):
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() // 2) - (900 // 2)
        y = (self.root.winfo_screenheight() // 2) - (700 // 2)
        self.root.geometry(f'900x700+{x}+{y}')
    
    def create_welcome_interface(self):
        # Header Frame
        header_frame = tk.Frame(self.root, bg='#4A90E2', height=120)
        header_frame.pack(fill='x', padx=20, pady=20)
        header_frame.pack_propagate(False)
        
        # Welcome text
        welcome_label = tk.Label(header_frame, 
                               text="Welcome to Anbu Academic Centre",
                               font=('Arial', 20, 'bold'),
                               bg='#4A90E2', 
                               fg='white')
        welcome_label.pack(pady=20)
        
        # Logo placeholder (you can add your actual logo)
        logo_frame = tk.Frame(header_frame, bg='#4A90E2')
        logo_frame.pack()
        logo_image = tk.PhotoImage(file="logocol.png")
        
        logo_label = tk.Label(logo_frame,
                            text="🎓",
                            font=('Arial', 48),
                            bg='#4A90E2',
                            fg='white')
        logo_label.pack()
        
        # Main content frame
        main_frame = tk.Frame(self.root, bg='#F0F0F0')
        main_frame.pack(fill='both', expand=True, padx=40, pady=20)
        
        # Left side - Quick Actions
        left_frame = tk.Frame(main_frame, bg='#F0F0F0')
        left_frame.pack(side='left', fill='both', expand=True, padx=(0, 20))
        
        # Quick Start Section
        quick_frame = tk.LabelFrame(left_frame, 
                                  text="🚀 Quick Start", 
                                  font=('Arial', 14, 'bold'),
                                  bg='#F0F0F0',
                                  fg='#2C3E50')
        quick_frame.pack(fill='x', pady=(0, 20))
        
        # Main Program Button
        main_btn = tk.Button(quick_frame,
                           text="📚 Open Library Management System",
                           font=('Arial', 14, 'bold'),
                           bg='#27AE60',
                           fg='white',
                           height=2,
                           width=40,
                           relief='flat',
                           command=self.launch_main_program)
        main_btn.pack(pady=15, padx=20)
        
        # Quick options
        tk.Label(quick_frame, 
                text="For experienced users - Direct access to main system",
                font=('Arial', 10),
                bg='#F0F0F0',
                fg='#7F8C8D').pack()
        
        # Documentation Section
        doc_frame = tk.LabelFrame(left_frame, 
                                text="📖 Documentation", 
                                font=('Arial', 14, 'bold'),
                                bg='#F0F0F0',
                                fg='#2C3E50')
        doc_frame.pack(fill='x', pady=(0, 20))
        
        # Documentation buttons
        doc_buttons = [
            ("📋 Readme", self.show_readme),
            ("📝 User Instructions", self.show_instructions),
            ("✅ System Checklist", self.show_checklist),
            ("🔧 Troubleshooting", self.show_troubleshooting)
        ]
        
        for text, command in doc_buttons:
            btn = tk.Button(doc_frame,
                          text=text,
                          font=('Arial', 11),
                          bg='#3498DB',
                          fg='white',
                          relief='flat',
                          command=command)
            btn.pack(fill='x', padx=10, pady=5)
        
        # Right side - System Info
        right_frame = tk.Frame(main_frame, bg='#F0F0F0')
        right_frame.pack(side='right', fill='y')
        
        info_frame = tk.LabelFrame(right_frame, 
                                 text="ℹ️ System Information", 
                                 font=('Arial', 14, 'bold'),
                                 bg='#F0F0F0',
                                 fg='#2C3E50')
        info_frame.pack(fill='x', pady=(0, 20))
        
        info_text = """Version: 1.0
Developer: Anbu Academic Centre
Last Updated: December 2025

Features:
• Complete Library Management
• Member Registration & Tracking
• Book Issue & Return System
• Advanced Reporting
• User-friendly Interface"""
        
        info_label = tk.Label(info_frame,
                            text=info_text,
                            font=('Arial', 10),
                            bg='#F0F0F0',
                            fg='#2C3E50',
                            justify='left')
        info_label.pack(pady=10, padx=15)
        
        # Footer
        footer_frame = tk.Frame(self.root, bg='#34495E', height=50)
        footer_frame.pack(fill='x', side='bottom')
        footer_frame.pack_propagate(False)
        
        footer_label = tk.Label(footer_frame,
                              text="© 2025 Anbu Academic Centre - Empowering Education Through Technology",
                              font=('Arial', 10),
                              bg='#34495E',
                              fg='white')
        footer_label.pack(expand=True)
    
    def launch_main_program(self):
        # This will launch your Harbour main program
        main_exe_path = "library_mnmx.exe"  # Adjust path as needed
        
        if os.path.exists(main_exe_path):
            try:
                os.startfile(main_exe_path)
                self.root.quit()  # Close welcome screen
            except Exception as e:
                messagebox.showerror("Error", f"Could not launch main program: {str(e)}")
        else:
            messagebox.showerror("Error", "Main program not found. Please check the path.")
    
    def show_readme(self):
        readme_window = tk.Toplevel(self.root)
        readme_window.title("Readme - Anbu Academic Centre Library System")
        readme_window.geometry("600x500")
        readme_window.configure(bg='#F0F0F0')
        
        text_widget = tk.Text(readme_window, 
                            font=('Arial', 11),
                            wrap='word',
                            bg='white',
                            relief='flat')
        scrollbar = tk.Scrollbar(readme_window, command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        
        text_widget.pack(side='left', fill='both', expand=True, padx=10, pady=10)
        scrollbar.pack(side='right', fill='y', pady=10)
        
        # Sample readme content
        readme_content = """ANBU ACADEMIC CENTRE
LIBRARY MANAGEMENT SYSTEM
=========================

Welcome to the Anbu Academic Centre Library Management System!

This comprehensive software solution is designed specifically for educational institutions and libraries. It provides complete management of library operations including book tracking, member management, and reporting systems.

GETTING STARTED:
1. Ensure you have the required system files
2. Run this welcome screen first for instructions
3. Click 'Open Library Management System' to start
4. For detailed instructions, check the User Instructions section

KEY FEATURES:
• Complete Book & Member Management
• Issue & Return Tracking System  
• Comprehensive Reports & Analytics
• User-friendly Interface
• Multi-user Support
• Data Backup & Recovery

TECHNICAL REQUIREMENTS:
• Windows Operating System
• Minimum 2GB RAM
• 500MB available disk space

For more information, please refer to the User Instructions section.
        """
        
        text_widget.insert('1.0', readme_content)
        text_widget.config(state='disabled')
    
    def show_instructions(self):
        instructions_window = tk.Toplevel(self.root)
        instructions_window.title("User Instructions - Anbu Academic Centre Library System")
        instructions_window.geometry("700x600")
        instructions_window.configure(bg='#F0F0F0')
        
        # Instructions content
        instructions_text = """USER INSTRUCTIONS
================

GETTING STARTED:
1. Welcome Screen:
   - This screen provides quick access to all system features
   - Click 'Open Library Management System' to start the main application
   - Use the Documentation section for detailed guides

2. Main System Navigation:
   - The main system has tabbed interface with different functions
   - Use the Issue Book tab for lending books
   - Use the Return Book tab for processing returns
   - Use Search Books to find specific books
   - Use System Configuration for settings

3. Adding Books:
   - Go to Search Books tab
   - Click 'Add New Book' button
   - Fill in all required information
   - Click Save to add to system

4. Registering Members:
   - Go to Add Member tab
   - Fill in member details
   - Assign member ID automatically
   - Save member information

5. Issuing Books:
   - Select 'Issue Book' tab
   - Enter member ID and book details
   - System will automatically calculate due dates
   - Confirm issue to complete transaction

6. Returning Books:
   - Use 'Return Book' tab
   - Enter book access number
   - System will calculate any overdue charges
   - Confirm return to complete

TROUBLESHOOTING:
- If you encounter errors, check the Troubleshooting section
- Always backup your data regularly
- Contact system administrator for technical support

For video tutorials and advanced features, please contact your system administrator.
        """
        
        # Create text widget with scrollbar
        text_frame = tk.Frame(instructions_window, bg='#F0F0F0')
        text_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        text_widget = tk.Text(text_frame, 
                            font=('Arial', 10),
                            wrap='word',
                            bg='white',
                            relief='flat')
        scrollbar = tk.Scrollbar(text_frame, command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        
        text_widget.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        
        text_widget.insert('1.0', instructions_text)
        text_widget.config(state='disabled')
    
    def show_checklist(self):
        checklist_window = tk.Toplevel(self.root)
        checklist_window.title("System Checklist - Anbu Academic Centre Library System")
        checklist_window.geometry("500x400")
        checklist_window.configure(bg='#F0F0F0')
        
        checklist_frame = tk.Frame(checklist_window, bg='#F0F0F0')
        checklist_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        title_label = tk.Label(checklist_frame,
                             text="📋 System Setup Checklist",
                             font=('Arial', 16, 'bold'),
                             bg='#F0F0F0',
                             fg='#2C3E50')
        title_label.pack(pady=(0, 20))
        
        checklist_items = [
            "✓ System files installed correctly",
            "✓ Database files created and accessible", 
            "✓ User permissions configured",
            "✓ Initial library data loaded",
            "✓ Backup procedures established",
            "✓ Staff training completed",
            "✓ Hardware requirements met",
            "✓ Network connectivity tested (if applicable)",
            "✓ Security measures implemented",
            "✓ System tested with sample data"
        ]
        
        for item in checklist_items:
            item_label = tk.Label(checklist_frame,
                                text=item,
                                font=('Arial', 11),
                                bg='#F0F0F0',
                                fg='#27AE60' if item.startswith('✓') else '#E74C3C',
                                anchor='w')
            item_label.pack(fill='x', pady=2)
        
        close_btn = tk.Button(checklist_frame,
                            text="Close",
                            font=('Arial', 11),
                            bg='#95A5A6',
                            fg='white',
                            relief='flat',
                            command=checklist_window.destroy)
        close_btn.pack(pady=20)
    
    def show_troubleshooting(self):
        troubleshoot_window = tk.Toplevel(self.root)
        troubleshoot_window.title("Troubleshooting - Anbu Academic Centre Library System")
        troubleshoot_window.geometry("600x500")
        troubleshoot_window.configure(bg='#F0F0F0')
        
        troubleshoot_content = """TROUBLESHOOTING GUIDE
==================

COMMON ISSUES AND SOLUTIONS:

1. PROGRAM WON'T START:
   • Check if all files are in the correct directory
   • Ensure you have necessary system permissions
   • Try running as administrator
   • Check Windows firewall/antivirus settings

2. DATABASE ERRORS:
   • Ensure database files are not corrupted
   • Check if database files are not in use by another program
   • Restore from backup if needed
   • Verify file permissions

3. SLOW PERFORMANCE:
   • Close unnecessary programs
   • Check available disk space
   • Ensure adequate RAM
   • Restart the system if needed

4. PRINTING ISSUES:
   • Check printer connection and power
   • Ensure printer drivers are installed
   • Try printing a test page from Windows
   • Check paper and ink levels

5. MEMBER REGISTRATION ERRORS:
   • Ensure all required fields are filled
   • Check for duplicate member IDs
   • Verify database connectivity
   • Try with a different member ID format

6. BOOK SEARCH NOT WORKING:
   • Check search criteria format
   • Ensure books are properly entered in system
   • Try different search parameters
   • Check for special characters in search terms

GETTING HELP:
• Check this troubleshooting guide first
• Verify all checklist items are completed
• Contact system administrator for technical issues
• Document any error messages for support

Remember to always backup your data before making changes!
        """
        
        text_widget = tk.Text(troubleshoot_window, 
                            font=('Arial', 10),
                            wrap='word',
                            bg='white',
                            relief='flat')
        scrollbar = tk.Scrollbar(troubleshoot_window, command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        
        text_widget.pack(side='left', fill='both', expand=True, padx=10, pady=10)
        scrollbar.pack(side='right', fill='y', pady=10)
        
        text_widget.insert('1.0', troubleshoot_content)
        text_widget.config(state='disabled')

def main():
    root = tk.Tk()
    app = WelcomeLauncher(root)
    root.mainloop()

if __name__ == "__main__":
    main()