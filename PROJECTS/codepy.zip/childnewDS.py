import tkinter as tk
from tkinter import messagebox, simpledialog, ttk
import random
import dbf
import phunspell
import os
from datetime import datetime

# Initialize spell checkers
try:
    pspell_us = phunspell.Phunspell('en_US')
    pspell_gb = phunspell.Phunspell('en_GB')
except:
    # Fallback if phunspell not available
    class FallbackSpellChecker:
        def lookup(self, word):
            return len(word) >= 3  # Simple fallback
        def suggest(self, word):
            return []
    
    pspell_us = FallbackSpellChecker()
    pspell_gb = FallbackSpellChecker()

# DBF files
WORDS_DBF = 'words.dbf'
USERS_DBF = 'users.dbf'
SCORES_DBF = 'scores.dbf'
REWARDS_DBF = 'rewards.dbf'

# Ensure DBF files exist
for db_file, field_specs in [
    (WORDS_DBF, 'word C(8)'),
    (USERS_DBF, 'name C(50); class N(2,0); password C(20)'),
    (SCORES_DBF, 'name C(50); module C(20); score N(3,0); date D'),
    (REWARDS_DBF, 'name C(50); stars N(3,0); badges C(100)')
]:
    if not os.path.exists(db_file):
        try:
            table = dbf.Table(filename=db_file, field_specs=field_specs)
            table.open(dbf.READ_WRITE)
            table.close()
        except Exception as e:
            print(f"Error creating {db_file}: {e}")

# Developer credit
DEVELOPER_CREDIT = "Software Developer: I Augustine Anbananthan"

# Global variables
child_name = ""
child_class = 1

# Custom dialog for results
def show_result_dialog(title, message, continue_cmd=None, back_cmd=None, parent=None):
    dialog = tk.Toplevel(parent or root)
    dialog.title(title)
    dialog.geometry("500x300")
    dialog.configure(bg="#FFF9B1")
    dialog.transient(parent or root)
    dialog.grab_set()
    
    tk.Label(dialog, text=message, font=("Arial", 16), bg="#FFF9B1", fg="#333", wraplength=400).pack(pady=30)
    
    button_frame = tk.Frame(dialog, bg="#FFF9B1")
    button_frame.pack(pady=20)
    
    if continue_cmd:
        tk.Button(button_frame, text="Continue", font=("Arial", 12, "bold"), 
                 bg="#4CAF50", fg="white", width=12, height=1, 
                 command=lambda: [dialog.destroy(), continue_cmd()]).pack(side=tk.LEFT, padx=10)
    
    if back_cmd:
        tk.Button(button_frame, text="Back", font=("Arial", 12, "bold"), 
                 bg="#F44336", fg="white", width=12, height=1, 
                 command=lambda: [dialog.destroy(), back_cmd()]).pack(side=tk.LEFT, padx=10)
    
    if not continue_cmd and not back_cmd:
        tk.Button(button_frame, text="OK", font=("Arial", 12, "bold"), 
                 bg="#4CAF50", fg="white", width=12, height=1, 
                 command=dialog.destroy).pack(side=tk.LEFT, padx=10)

# Function to check spelling
def is_correct_spelling(word):
    return pspell_us.lookup(word) or pspell_gb.lookup(word)

# Function to get suggestions
def get_suggestions(word):
    try:
        suggestions = set(pspell_us.suggest(word) + pspell_gb.suggest(word))
        return list(suggestions)[:5]  # Limit to 5 suggestions
    except:
        return []

# Function to get user data and show startup window
def get_user_data():
    def select_user():
        selected_name = name_var.get()
        if selected_name == "Add New Child":
            add_new_child()
        elif selected_name == "Parent/Teacher Login":
            parent_login()
        else:
            with dbf.Table(USERS_DBF) as table:
                table.open()
                for user in table:
                    if user['name'].strip().upper() == selected_name.upper():
                        class_level = user['class']
                        start_window.destroy()
                        root.set_user(selected_name, class_level)
                        return
            # Fallback if user not found
            start_window.destroy()
            root.set_user(selected_name, 1)
    
    def add_new_child():
        new_name = simpledialog.askstring("New Child", "Enter new child's name:", parent=start_window)
        if not new_name:
            new_name = "Student"
        
        new_class = simpledialog.askinteger("Class Level", "Enter class (1-8):", 
                                           minvalue=1, maxvalue=8, parent=start_window)
        if not new_class:
            new_class = 1
            
        with dbf.Table(USERS_DBF) as table:
            table.open(dbf.READ_WRITE)
            table.append({'name': new_name.upper(), 'class': new_class, 'password': ''})
        
        with dbf.Table(REWARDS_DBF) as table:
            table.open(dbf.READ_WRITE)
            table.append({'name': new_name.upper(), 'stars': 0, 'badges': ''})
            
        start_window.destroy()
        root.set_user(new_name, new_class)
    
    def parent_login():
        password = simpledialog.askstring("Parent/Teacher Login", "Enter password:", 
                                         show='*', parent=start_window)
        if password == "admin":
            start_window.destroy()
            parent_menu()
        else:
            messagebox.showerror("Error", "Incorrect password.", parent=start_window)

    # Get list of users
    with dbf.Table(USERS_DBF) as table:
        table.open()
        users = [rec['name'].strip() for rec in table if rec['name'].strip()]
    
    if not users:
        # No users, prompt for new child
        new_name = simpledialog.askstring("Welcome", "Enter your name:")
        if not new_name:
            new_name = "Student"
            
        new_class = simpledialog.askinteger("Class Level", "Enter your class (1-8):", 
                                           minvalue=1, maxvalue=8)
        if not new_class:
            new_class = 1
            
        with dbf.Table(USERS_DBF) as table:
            table.open(dbf.READ_WRITE)
            table.append({'name': new_name.upper(), 'class': new_class, 'password': ''})
            
        with dbf.Table(REWARDS_DBF) as table:
            table.open(dbf.READ_WRITE)
            table.append({'name': new_name.upper(), 'stars': 0, 'badges': ''})
            
        return new_name, new_class
    else:
        # Show startup window with user selection
        start_window = tk.Toplevel(root)
        start_window.title("Welcome to Fun Learning!")
        start_window.geometry("500x400")
        start_window.configure(bg="#FFF9B1")
        start_window.transient(root)
        start_window.grab_set()
        
        tk.Label(start_window, text="Choose your name:", font=("Arial", 18, "bold"), 
                bg="#FFF9B1", fg="#333").pack(pady=30)
        
        name_var = tk.StringVar(start_window)
        name_var.set(users[0])
        
        options = users + ["Add New Child", "Parent/Teacher Login"]
        dropdown = ttk.OptionMenu(start_window, name_var, *options)
        dropdown.config(width=20)
        dropdown["menu"].config(font=("Arial", 12))
        dropdown.pack(pady=20)
        
        tk.Button(start_window, text="Start", font=("Arial", 14, "bold"), 
                 bg="#4CAF50", fg="white", width=15, height=2, 
                 command=select_user).pack(pady=20)
        
        # Wait for selection
        root.wait_window(start_window)
        return "Student", 1  # Default return

# Parent/Teacher Menu
def parent_menu():
    parent_window = tk.Toplevel(root)
    parent_window.title("Admin Controls")
    parent_window.geometry("400x400")
    parent_window.configure(bg="#FFF9B1")
    parent_window.transient(root)
    parent_window.grab_set()
    
    tk.Label(parent_window, text="Admin Options", font=("Arial", 16, "bold"), 
            bg="#FFF9B1", fg="#333").pack(pady=20)
    
    tk.Button(parent_window, text="Add Word", font=("Arial", 12, "bold"), 
             bg="#4CAF50", fg="white", width=15, height=1, 
             command=parent_add_word).pack(pady=10)
    
    tk.Button(parent_window, text="Edit/View Words", font=("Arial", 12, "bold"), 
             bg="#2196F3", fg="white", width=15, height=1, 
             command=parent_edit_words).pack(pady=10)
    
    tk.Button(parent_window, text="View Scores", font=("Arial", 12, "bold"), 
             bg="#FF9800", fg="white", width=15, height=1, 
             command=parent_view_scores).pack(pady=10)
    
    tk.Button(parent_window, text="Close", font=("Arial", 12, "bold"), 
             bg="#F44336", fg="white", width=15, height=1, 
             command=parent_window.destroy).pack(pady=10)

def parent_add_word():
    add_window = tk.Toplevel(root)
    add_window.title("Add Word")
    add_window.geometry("400x300")
    add_window.configure(bg="#FFF9B1")
    add_window.transient(root)
    add_window.grab_set()
    
    tk.Label(add_window, text="Enter a word to add:", font=("Arial", 16, "bold"), 
            bg="#FFF9B1", fg="#333").pack(pady=20)
    
    entry = tk.Entry(add_window, font=("Arial", 14), width=20)
    entry.pack(pady=10)
    entry.focus_set()
    
    def submit_word():
        word = entry.get().strip().lower()
        if len(word) < 3 or len(word) > 8:
            messagebox.showerror("Error", "Word must be 3-8 letters.", parent=add_window)
            return
        
        with dbf.Table(WORDS_DBF) as table:
            table.open(dbf.READ_WRITE)
            # Check if word already exists
            for rec in table:
                if rec['word'].strip().lower() == word:
                    messagebox.showinfo("Info", "Word already exists.", parent=add_window)
                    return
            table.append({'word': word.upper()})
        
        messagebox.showinfo("Success", "Word added!", parent=add_window)
        add_window.destroy()
    
    tk.Button(add_window, text="Submit", font=("Arial", 12, "bold"), 
             bg="#4CAF50", fg="white", width=12, height=1, 
             command=submit_word).pack(pady=10)
    
    # Bind Enter key to submit
    add_window.bind('<Return>', lambda e: submit_word())

def parent_edit_words():
    with dbf.Table(WORDS_DBF) as table:
        table.open()
        words = [rec['word'].strip().lower() for rec in table]
    
    edit_window = tk.Toplevel(root)
    edit_window.title("Edit/View Words")
    edit_window.geometry("500x400")
    edit_window.configure(bg="#FFF9B1")
    edit_window.transient(root)
    edit_window.grab_set()
    
    tk.Label(edit_window, text="Saved Words:", font=("Arial", 16, "bold"), 
            bg="#FFF9B1", fg="#333").pack(pady=20)
    
    # Create a frame for the listbox and scrollbar
    frame = tk.Frame(edit_window, bg="#FFF9B1")
    frame.pack(pady=10, fill=tk.BOTH, expand=True)
    
    listbox = tk.Listbox(frame, font=("Arial", 12), width=30, height=10)
    scrollbar = tk.Scrollbar(frame, orient=tk.VERTICAL, command=listbox.yview)
    listbox.config(yscrollcommand=scrollbar.set)
    
    for word in words:
        listbox.insert(tk.END, word)
    
    listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    button_frame = tk.Frame(edit_window, bg="#FFF9B1")
    button_frame.pack(pady=10)
    
    def edit_selected():
        selected = listbox.curselection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a word to edit.", parent=edit_window)
            return
        
        idx = selected[0]
        old_word = listbox.get(idx)
        new_word = simpledialog.askstring("Edit Word", "Enter new word:", 
                                         initialvalue=old_word, parent=edit_window)
        if new_word and 3 <= len(new_word) <= 8:
            with dbf.Table(WORDS_DBF) as table:
                table.open(dbf.READ_WRITE)
                table[idx] = {'word': new_word.upper()}
            
            listbox.delete(idx)
            listbox.insert(idx, new_word.lower())
            messagebox.showinfo("Success", "Word updated!", parent=edit_window)
    
    def delete_selected():
        selected = listbox.curselection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a word to delete.", parent=edit_window)
            return
        
        idx = selected[0]
        word = listbox.get(idx)
        if messagebox.askyesno("Confirm", f"Delete '{word}'?", parent=edit_window):
            with dbf.Table(WORDS_DBF) as table:
                table.open(dbf.READ_WRITE)
                table.delete(idx)
            
            listbox.delete(idx)
            messagebox.showinfo("Success", "Word deleted!", parent=edit_window)
    
    tk.Button(button_frame, text="Edit Selected", font=("Arial", 12, "bold"), 
             bg="#FF9800", fg="white", width=12, height=1, 
             command=edit_selected).pack(side=tk.LEFT, padx=10)
    
    tk.Button(button_frame, text="Delete Selected", font=("Arial", 12, "bold"), 
             bg="#F44336", fg="white", width=12, height=1, 
             command=delete_selected).pack(side=tk.LEFT, padx=10)
    
    tk.Button(button_frame, text="Close", font=("Arial", 12, "bold"), 
             bg="#F44336", fg="white", width=12, height=1, 
             command=edit_window.destroy).pack(side=tk.LEFT, padx=10)

def parent_view_scores():
    with dbf.Table(SCORES_DBF) as table:
        table.open()
        scores = []
        for rec in table:
            scores.append({
                'name': rec['name'].strip(),
                'module': rec['module'].strip(),
                'score': rec['score'],
                'date': rec['date']
            })
    
    score_window = tk.Toplevel(root)
    score_window.title("Student Scores")
    score_window.geometry("600x400")
    score_window.configure(bg="#FFF9B1")
    score_window.transient(root)
    score_window.grab_set()
    
    tk.Label(score_window, text="Student Scores", font=("Arial", 16, "bold"), 
            bg="#FFF9B1", fg="#333").pack(pady=20)
    
    # Create a frame for the treeview and scrollbar
    frame = tk.Frame(score_window, bg="#FFF9B1")
    frame.pack(pady=10, fill=tk.BOTH, expand=True)
    
    columns = ("Name", "Module", "Score", "Date")
    tree = ttk.Treeview(frame, columns=columns, show="headings", height=15)
    
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=100)
    
    for score in scores:
        tree.insert("", tk.END, values=(
            score['name'],
            score['module'],
            score['score'],
            score['date'].strftime("%Y-%m-%d") if score['date'] else "N/A"
        ))
    
    scrollbar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=tree.yview)
    tree.configure(yscrollcommand=scrollbar.set)
    
    tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    tk.Button(score_window, text="Close", font=("Arial", 12, "bold"), 
             bg="#F44336", fg="white", width=12, height=1, 
             command=score_window.destroy).pack(pady=10)

# Save score
def save_score(module, score):
    try:
        with dbf.Table(SCORES_DBF) as table:
            table.open(dbf.READ_WRITE)
            table.append({
                'name': child_name.upper(), 
                'module': module, 
                'score': score, 
                'date': datetime.today()
            })
    except Exception as e:
        print(f"Error saving score: {e}")

# Update rewards
def update_rewards(score):
    try:
        with dbf.Table(REWARDS_DBF) as table:
            table.open(dbf.READ_WRITE)
            for rec in table:
                if rec['name'].strip().upper() == child_name.upper():
                    rec['stars'] = rec['stars'] + score
                    # Add badge for high scores
                    if score >= 8:
                        badges = rec['badges'].strip()
                        new_badges = badges + ", High Scorer" if badges else "High Scorer"
                        rec['badges'] = new_badges
                    break
    except Exception as e:
        print(f"Error updating rewards: {e}")

# Show rewards
def show_rewards():
    try:
        with dbf.Table(REWARDS_DBF) as table:
            table.open()
            stars = 0
            badges = ""
            for rec in table:
                if rec['name'].strip().upper() == child_name.upper():
                    stars = rec['stars']
                    badges = rec['badges']
                    break
        
        message = f"Stars: {stars}"
        if badges:
            message += f"\nBadges: {badges}"
        
        messagebox.showinfo("Your Rewards", message)
    except Exception as e:
        messagebox.showerror("Error", f"Failed to load rewards: {e}")

# Add word module
def add_word():
    add_window = tk.Toplevel(root)
    add_window.title("Add Word")
    add_window.geometry("500x400")
    add_window.configure(bg="#FFF9B1")
    add_window.transient(root)
    add_window.grab_set()
    
    tk.Label(add_window, text=f"{child_name}, enter a 3-8 letter word:", 
            font=("Arial", 18, "bold"), bg="#FFF9B1", fg="#333").pack(pady=30)
    
    entry = tk.Entry(add_window, font=("Arial", 16), width=25)
    entry.pack(pady=20)
    entry.focus_set()
    
    def submit_word():
        word = entry.get().strip().lower()
        if len(word) < 3 or len(word) > 8:
            show_result_dialog("Error", "Word must be 3-8 letters.", 
                              continue_add_word, close_add_window, add_window)
            return
        
        attempts = 0
        while attempts < 3:
            if is_correct_spelling(word):
                with dbf.Table(WORDS_DBF) as table:
                    table.open(dbf.READ_WRITE)
                    # Check if word already exists
                    for rec in table:
                        if rec['word'].strip().lower() == word:
                            show_result_dialog("Info", "Word already exists.", 
                                              continue_add_word, close_add_window, add_window)
                            return
                    table.append({'word': word.upper()})
                
                show_result_dialog("Success", "Word saved!", 
                                  continue_add_word, close_add_window, add_window)
                return
            else:
                attempts += 1
                if attempts < 3:
                    word = simpledialog.askstring("Try Again", 
                                                 f"Incorrect spelling. Attempt {attempts}/3. Try again:", 
                                                 parent=add_window)
                    if word is None:
                        close_add_window()
                        return
                else:
                    suggestions = get_suggestions(word)
                    msg = f"Suggestions: {', '.join(suggestions)}\nEnter correct word to save:" if suggestions else "No suggestions found. Enter correct word to save:"
                    corrected = simpledialog.askstring("Correct Word", msg, parent=add_window)
                    if corrected and is_correct_spelling(corrected) and 3 <= len(corrected) <= 8:
                        with dbf.Table(WORDS_DBF) as table:
                            table.open(dbf.READ_WRITE)
                            table.append({'word': corrected.upper()})
                        show_result_dialog("Success", "Corrected word saved!", 
                                          continue_add_word, close_add_window, add_window)
                    else:
                        show_result_dialog("Error", "Invalid correction. Not saved.", 
                                          continue_add_word, close_add_window, add_window)
                    return

    def continue_add_word():
        entry.delete(0, tk.END)
        entry.focus()

    def close_add_window():
        add_window.destroy()

    tk.Button(add_window, text="Submit", font=("Arial", 14, "bold"), 
             bg="#4CAF50", fg="white", width=15, height=2, 
             command=submit_word).pack(pady=20)
    
    # Bind Enter key to submit
    add_window.bind('<Return>', lambda e: submit_word())

# Get saved words with difficulty
def get_saved_words(difficulty="Medium"):
    with dbf.Table(WORDS_DBF) as table:
        table.open()
        words = [rec['word'].strip().lower() for rec in table]
    
    # Filter by difficulty
    if difficulty == "Easy":
        words = [w for w in words if 3 <= len(w) <= 4]
    elif difficulty == "Medium":
        words = [w for w in words if 4 <= len(w) <= 6]
    else:  # Hard
        words = [w for w in words if 6 <= len(w) <= 8]
    
    return words

# Generate word with blank
def generate_blank_word(word):
    pos = random.randint(0, len(word) - 1)
    blanked = word[:pos] + '_' + word[pos+1:]
    return blanked, word[pos]

# Word exercise module
def word_exercise():
    # Get difficulty level
    difficulty = get_user_difficulty_level("Word")
    if not difficulty:
        return
    
    words = get_saved_words(difficulty)
    if not words:
        show_result_dialog("Error", "No words saved yet. Add some first.", 
                          add_word, lambda: None, root)
        return
    
    score = 0
    total = 5  # Reduced for younger children
    current = 0

    def next_word():
        nonlocal current, score
        if current >= total:
            save_score("Word", score)
            update_rewards(score)
            
            # Provide feedback based on score
            if score >= 4:
                feedback = "Excellent! You're a spelling star!"
            elif score >= 3:
                feedback = "Good job! Keep practicing!"
            else:
                feedback = "Nice try! Practice makes perfect!"
                
            show_result_dialog("Word Exercise Complete", 
                              f"{child_name}, you got {score}/{total} correct!\n{feedback}\n(Difficulty: {difficulty})", 
                              lambda: None, lambda: None, root)
            return
        
        word = random.choice(words)
        blanked, correct_letter = generate_blank_word(word)
        
        dialog = tk.Toplevel(root)
        dialog.title("Word Exercise")
        dialog.geometry("500x400")
        dialog.configure(bg="#FFF9B1")
        dialog.transient(root)
        dialog.grab_set()
        
        tk.Label(dialog, text=f"Fill in the blank:", font=("Arial", 16, "bold"), 
                bg="#FFF9B1", fg="#333").pack(pady=10)
        
        tk.Label(dialog, text=blanked, font=("Arial", 24, "bold"), 
                bg="#FFF9B1", fg="#333").pack(pady=20)
        
        tk.Label(dialog, text=f"Difficulty: {difficulty}", font=("Arial", 12), 
                bg="#FFF9B1", fg="#666").pack(pady=5)
        
        entry = tk.Entry(dialog, font=("Arial", 18), width=5, justify='center')
        entry.pack(pady=20)
        entry.focus_set()
        
        def submit_guess():
            nonlocal score, current
            guess = entry.get().strip().lower()
            dialog.destroy()
            
            if len(guess) == 1 and guess == correct_letter.lower():
                score += 1
                show_result_dialog("Correct!", "Good job! ??", next_word, lambda: None, root)
            else:
                current += 1
                show_result_dialog("Incorrect", f"The correct letter was '{correct_letter}'.", 
                                  next_word, lambda: None, root)
        
        tk.Button(dialog, text="Submit", font=("Arial", 14, "bold"), 
                 bg="#4CAF50", fg="white", width=12, height=1, 
                 command=submit_guess).pack(pady=20)
        
        # Bind Enter key to submit
        dialog.bind('<Return>', lambda e: submit_guess())
    
    next_word()

# Generate math problem with child-friendly symbols
def generate_math_problem(level, difficulty="Medium"):
    # Use child-friendly symbols
    ops = ['+', '-', '�', '�']
    op = random.choice(ops)
    
    # Adjust difficulty
    if difficulty == "Easy":
        max_num = 20
        if op == '�':
            max_num = 5
        elif op == '�':
            max_num = 10
    elif difficulty == "Medium":
        max_num = 50
        if op == '�':
            max_num = 10
        elif op == '�':
            max_num = 25
    else:  # Hard
        max_num = 100
        if op == '�':
            max_num = 12
        elif op == '�':
            max_num = 50
    
    if op in ['+', '-']:
        a = random.randint(1, max_num)
        b = random.randint(1, max_num)
        if op == '+':
            ans = a + b
        else:  # -
            # Ensure positive result
            a, b = max(a, b), min(a, b)
            ans = a - b
    elif op == '�':
        a = random.randint(1, max_num)
        b = random.randint(1, 10)
        ans = a * b
    else:  # '�'
        b = random.randint(1, max_num // 2)
        ans = random.randint(1, max_num // b)
        a = ans * b
    
    # Convert to string and create blank
    ans_str = str(ans)
    pos = random.randint(0, len(ans_str) - 1)
    blanked = ans_str[:pos] + '_' + ans_str[pos+1:]
    
    # Format the problem with child-friendly symbols
    problem = f"{a} {op} {b} = {blanked}"
    return problem, ans_str[pos]

# Math exercise module
def math_exercise():
    # Get difficulty level
    difficulty = get_user_difficulty_level("Math")
    if not difficulty:
        return
    
    score = 0
    total = 5  # Reduced for younger children
    current = 0

    def next_problem():
        nonlocal current, score
        if current >= total:
            save_score("Math", score)
            update_rewards(score)
            
            # Provide feedback based on score
            if score >= 4:
                feedback = "Excellent! You're a math whiz!"
            elif score >= 3:
                feedback = "Good job! Keep practicing!"
            else:
                feedback = "Nice try! Practice makes perfect!"
                
            show_result_dialog("Math Exercise Complete", 
                              f"{child_name}, you got {score}/{total} correct!\n{feedback}\n(Difficulty: {difficulty})", 
                              lambda: None, lambda: None, root)
            return
        
        problem, correct_digit = generate_math_problem(child_class, difficulty)
        
        dialog = tk.Toplevel(root)
        dialog.title("Math Exercise")
        dialog.geometry("500x400")
        dialog.configure(bg="#FFF9B1")
        dialog.transient(root)
        dialog.grab_set()
        
        tk.Label(dialog, text="Solve the problem:", font=("Arial", 16, "bold"), 
                bg="#FFF9B1", fg="#333").pack(pady=10)
        
        tk.Label(dialog, text=problem, font=("Arial", 24, "bold"), 
                bg="#FFF9B1", fg="#333").pack(pady=20)
        
        tk.Label(dialog, text=f"Difficulty: {difficulty}", font=("Arial", 12), 
                bg="#FFF9B1", fg="#666").pack(pady=5)
        
        entry = tk.Entry(dialog, font=("Arial", 18), width=5, justify='center')
        entry.pack(pady=20)
        entry.focus_set()
        
        def submit_guess():
            nonlocal score, current
            guess = entry.get().strip()
            dialog.destroy()
            
            if len(guess) == 1 and guess.isdigit() and guess == correct_digit:
                score += 1
                show_result_dialog("Correct!", "Good job! ??", next_problem, lambda: None, root)
            else:
                current += 1
                show_result_dialog("Incorrect", f"The correct digit was '{correct_digit}'.", 
                                  next_problem, lambda: None, root)
        
        tk.Button(dialog, text="Submit", font=("Arial", 14, "bold"), 
                 bg="#4CAF50", fg="white", width=12, height=1, 
                 command=submit_guess).pack(pady=20)
        
        # Bind Enter key to submit
        dialog.bind('<Return>', lambda e: submit_guess())
    
    next_problem()

# Get user difficulty level
def get_user_difficulty_level(module="Exercise"):
    difficulty_window = tk.Toplevel(root)
    difficulty_window.title(f"Select {module} Difficulty")
    difficulty_window.geometry("400x300")
    difficulty_window.configure(bg="#FFF9B1")
    difficulty_window.transient(root)
    difficulty_window.grab_set()
    
    tk.Label(difficulty_window, text=f"Select {module} Difficulty:", 
            font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=20)
    
    difficulty_var = tk.StringVar(difficulty_window)
    difficulty_var.set("Medium")  # Default
    
    # Difficulty descriptions
    descriptions = {
        "Easy": "Simple problems for beginners",
        "Medium": "Moderate challenge",
        "Hard": "Advanced problems"
    }
    
    for level in ["Easy", "Medium", "Hard"]:
        frame = tk.Frame(difficulty_window, bg="#FFF9B1")
        frame.pack(pady=5)
        
        rb = tk.Radiobutton(frame, text=level, variable=difficulty_var, 
                           value=level, font=("Arial", 12), bg="#FFF9B1")
        rb.pack(side=tk.LEFT)
        
        label = tk.Label(frame, text=descriptions[level], font=("Arial", 10), 
                        bg="#FFF9B1", fg="#666")
        label.pack(side=tk.LEFT, padx=10)
    
    selected_difficulty = [None]  # Use list to store result
    
    def submit_difficulty():
        selected_difficulty[0] = difficulty_var.get()
        difficulty_window.destroy()
    
    tk.Button(difficulty_window, text="Start Exercise", font=("Arial", 12, "bold"), 
             bg="#4CAF50", fg="white", width=15, height=1, 
             command=submit_difficulty).pack(pady=20)
    
    # Bind Enter key to submit
    difficulty_window.bind('<Return>', lambda e: submit_difficulty())
    
    root.wait_window(difficulty_window)
    return selected_difficulty[0]

# Main GUI
root = tk.Tk()
root.title("Fun Learning App")
root.geometry("800x600")
root.configure(bg="#FFF9B1")

# Add developer credit
credit_label = tk.Label(root, text=DEVELOPER_CREDIT, font=("Arial", 10), 
                       bg="#FFF9B1", fg="#333")
credit_label.pack(side=tk.BOTTOM, pady=10)

# Function to set user after selection
def set_user(name, class_level):
    global child_name, child_class
    child_name, child_class = name, class_level
    
    # Clear any existing widgets
    for widget in root.winfo_children():
        if widget != credit_label:
            widget.destroy()
    
    # Welcome message
    welcome_label = tk.Label(root, text=f"Welcome, {child_name}!", 
                            font=("Arial", 24, "bold"), bg="#FFF9B1", fg="#333")
    welcome_label.pack(pady=30)
    
    # Class level
    class_label = tk.Label(root, text=f"Class: {child_class}", 
                          font=("Arial", 16), bg="#FFF9B1", fg="#666")
    class_label.pack(pady=10)
    
    # Buttons
    button_frame = tk.Frame(root, bg="#FFF9B1")
    button_frame.pack(pady=20)
    
    tk.Button(button_frame, text="Add Words", font=("Arial", 14, "bold"), 
             bg="#4CAF50", fg="white", width=20, height=2, 
             command=add_word).pack(pady=15)
    
    tk.Button(button_frame, text="Word Exercises", font=("Arial", 14, "bold"), 
             bg="#2196F3", fg="white", width=20, height=2, 
             command=word_exercise).pack(pady=15)
    
    tk.Button(button_frame, text="Math Exercises", font=("Arial", 14, "bold"), 
             bg="#FF9800", fg="white", width=20, height=2, 
             command=math_exercise).pack(pady=15)
    
    tk.Button(button_frame, text="Show Rewards", font=("Arial", 14, "bold"), 
             bg="#9C27B0", fg="white", width=20, height=2, 
             command=