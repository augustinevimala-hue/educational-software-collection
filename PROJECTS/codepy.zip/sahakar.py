﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ChildAI.py - Child learning app (Tkinter + SQLite)

Features:
- Multi-user (add/select child)
- Parent/Teacher (admin) login
- Add words with spell-check & suggestions
- Word fill-in exercises (blank one letter)
- Math exercises (× and ÷ shown)
- Score saving, rewards (stars & badges)
- Difficulty selection and automatic difficulty update
- Developer credit line fixed at bottom

Author credit preserved: Software Developer: I Augustine Anbananthan
"""

import tkinter as tk
from tkinter import messagebox, simpledialog, ttk
import random
import sqlite3
from datetime import date

# Try optional spellchecker
try:
    from spellchecker import SpellChecker
    SPELLER = SpellChecker(language='en')
except Exception:
    SPELLER = None

import sys
import os
if getattr(sys, 'frozen', False):
    base_path = os.path.dirname(sys.executable) # For EXE
else:
    base_path = os.path.dirname(os.path.abspath(__file__)) # For script
DB_FILENAME = os.path.join(base_path, "childnew.db")

DEVELOPER_CREDIT = "Software Developer: I Augustine Anbananthan"

# ---------- Database helper ----------

def init_db():
    """Initialize the database tables if they do not exist."""
    with sqlite3.connect(DB_FILENAME) as conn:
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE,
                class_level INTEGER DEFAULT 1
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS words (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word TEXT UNIQUE
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS scores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                module TEXT,
                score INTEGER,
                date TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS rewards (
                user_id INTEGER PRIMARY KEY,
                stars INTEGER DEFAULT 0,
                badges TEXT DEFAULT '',
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)

def add_user(name, class_level=1):
    """Add a user to the database if not exists."""
    with sqlite3.connect(DB_FILENAME) as conn:
        cur = conn.cursor()
        cur.execute("INSERT OR IGNORE INTO users (name, class_level) VALUES (?, ?)", (name.upper(), class_level))
        cur.execute("SELECT id FROM users WHERE name = ?", (name.upper(),))
        row = cur.fetchone()
        if row:
            user_id = row[0]
            cur.execute("INSERT OR IGNORE INTO rewards (user_id, stars, badges) VALUES (?, 0, '')", (user_id,))

def get_all_users():
    """Return a list of all user names."""
    with sqlite3.connect(DB_FILENAME) as conn:
        cur = conn.cursor()
        cur.execute("SELECT name FROM users ORDER BY name")
        rows = [r[0] for r in cur.fetchall()]
    return rows

def get_user_row(name):
    """Return (id, name, class_level) for given user name."""
    with sqlite3.connect(DB_FILENAME) as conn:
        cur = conn.cursor()
        cur.execute("SELECT id, name, class_level FROM users WHERE name = ?", (name.upper(),))
        row = cur.fetchone()
    return row

def update_user_class(user_id, new_class):
    """Update the class_level of a user."""
    with sqlite3.connect(DB_FILENAME) as conn:
        cur = conn.cursor()
        cur.execute("UPDATE users SET class_level = ? WHERE id = ?", (new_class, user_id))

def add_word_db(word):
    """Add a word to the database if not exists."""
    with sqlite3.connect(DB_FILENAME) as conn:
        cur = conn.cursor()
        cur.execute("INSERT OR IGNORE INTO words (word) VALUES (?)", (word.upper(),))

def get_saved_words_by_length(min_len, max_len):
    """Return list of words between min_len and max_len."""
    with sqlite3.connect(DB_FILENAME) as conn:
        cur = conn.cursor()
        cur.execute("SELECT word FROM words")
        rows = [r[0].strip().lower() for r in cur.fetchall()]
    return [w for w in rows if min_len <= len(w) <= max_len]

def save_score_db(user_id, module, score):
    """Save a score entry for user and module."""
    with sqlite3.connect(DB_FILENAME) as conn:
        cur = conn.cursor()
        cur.execute("INSERT INTO scores (user_id, module, score, date) VALUES (?, ?, ?, ?)",
                    (user_id, module, score, date.today().isoformat()))

def get_rewards(user_id):
    """Get stars and badges for user."""
    with sqlite3.connect(DB_FILENAME) as conn:
        cur = conn.cursor()
        cur.execute("SELECT stars, badges FROM rewards WHERE user_id = ?", (user_id,))
        row = cur.fetchone()
    if row:
        return row[0], row[1]
    return 0, ""

def update_rewards_db(user_id, add_stars, add_badge=False):
    with sqlite3.connect(DB_FILENAME) as conn:
        cur = conn.cursor()
        cur.execute("SELECT stars, badges FROM rewards WHERE user_id = ?", (user_id,))
        row = cur.fetchone()
        if row:
            stars, badges = row
        else:
            stars, badges = 0, ""
            cur.execute("INSERT OR IGNORE INTO rewards (user_id, stars, badges) VALUES (?, 0, '')", (user_id,))
        new_stars = stars + add_stars
        new_badges = badges
        if add_badge:
            if new_badges:
                new_badges += ", Badge"
            else:
                new_badges = "Badge"
        cur.execute("UPDATE rewards SET stars = ?, badges = ? WHERE user_id = ?", (new_stars, new_badges, user_id))

# ---------- Spell check helpers ----------

def is_correct_spelling(word):
    w = word.strip().lower()
    if not w:
        return False
    if SPELLER:
        return w in SPELLER or SPELLER.unknown([w]) == set()
    return len(w) >= 3

def get_suggestions(word, max_suggestions=3):
    if SPELLER:
        suggestions = SPELLER.candidates(word)
        sugg = [s for s in suggestions if s.lower() != word.lower()]
        return sugg[:max_suggestions]
    return []

# ---------- Helpers for exercises ----------

def generate_blank_word(word):
    if not word:
        return word, ''
    pos = random.randint(0, len(word) - 1)
    blanked = word[:pos] + '_' + word[pos+1:]
    return blanked, word[pos]

def generate_math_problem(level, difficulty):
    ops = ['+', '-', '×', '÷']
    op = random.choice(ops)
    if difficulty == "Easy":
        max_base = 10 + level * 2
    elif difficulty == "Medium":
        max_base = 20 + level * 5
    else:
        max_base = 50 + level * 10

    if op in ['+', '-']:
        a = random.randint(1, max_base)
        b = random.randint(1, max_base // 2 or 1)
        ans = a + b if op == '+' else abs(a - b)
    elif op == '×':
        a = random.randint(1, max(2, max_base // 5))
        b = random.randint(1, 10 + level)
        ans = a * b
    else:
        b = random.randint(1, 10 + level)
        ans = random.randint(1, max(1, max_base // (b or 1)))
        a = ans * b

    ans_str = str(ans)
    pos = random.randint(0, max(0, len(ans_str)-1))
    blanked_ans = ans_str[:pos] + '_' + ans_str[pos+1:]
    return f"{a} {op} {b} = {blanked_ans}", ans_str[pos]

# ---------- GUI Application ----------

class ChildApp:
    def __init__(self, master):
        self.root = master
        self.root.title("Child Learning App")
        self.root.geometry("800x700")
        self.root.configure(bg="#FFF9B1")
        self.current_user_id = None
        self.current_user_name = None
        self.current_class = 1

        self.main_frame = tk.Frame(self.root, bg="#FFF9B1")
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        self.credit_label = tk.Label(self.root, text=DEVELOPER_CREDIT, font=("Arial", 10), bg="#FFF9B1", fg="#333")
        self.credit_label.pack(side=tk.BOTTOM, pady=5)

        self.build_startup()

    # ------------ startup / user selection ------------
    def build_startup(self):
        for w in self.main_frame.winfo_children():
            w.destroy()
        tk.Label(self.main_frame, text="Welcome to Fun Learning!", font=("Arial", 24, "bold"),
                 bg="#FFF9B1", fg="#333").pack(pady=20)
        users = get_all_users()
        users_display = users[:]
        users_display.extend(["Add New Child", "Parent/Teacher Login"])

        self.name_var = tk.StringVar(self.root)
        self.name_var.set(users_display[0] if users_display else "Add New Child")
        dropdown = ttk.OptionMenu(self.main_frame, self.name_var, self.name_var.get(), *users_display)
        dropdown.config(width=30)
        dropdown.pack(pady=20)

        start_btn = tk.Button(self.main_frame, text="Start", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white",
                             width=18, height=2, command=self.handle_start_selection)
        start_btn.pack(pady=10)

    def handle_start_selection(self):
        choice = self.name_var.get()
        if choice == "Add New Child":
            self.add_new_child_dialog()
        elif choice == "Parent/Teacher Login":
            self.parent_login_dialog()
        else:
            user_row = get_user_row(choice)
            if user_row:
                self.current_user_id, _, self.current_class = user_row
                self.current_user_name = choice
                self.build_main_menu()
            else:
                messagebox.showerror("Error", "Selected user not found. Try adding a new child.")

    def add_new_child_dialog(self):
        name = simpledialog.askstring("New Child", "Enter child's name:", parent=self.root)
        if not name:
            return
        class_level = simpledialog.askinteger("Class", "Enter class (1-8):", parent=self.root, minvalue=1, maxvalue=8)
        if not class_level:
            class_level = 1
        add_user(name, class_level)
        messagebox.showinfo("Success", f"Child {name} added.")
        self.build_startup()

    def parent_login_dialog(self):
        pwd = simpledialog.askstring("Parent/Teacher Login", "Enter password:", parent=self.root, show="*")
        if pwd == "admin":
            self.open_parent_menu()
        else:
            messagebox.showerror("Access Denied", "Incorrect password.")

    # ------------ parent/admin menu ------------
    def open_parent_menu(self):
        win = tk.Toplevel(self.root)
        win.title("Admin Controls")
        win.geometry("420x320")
        win.configure(bg="#FFF9B1")

        tk.Label(win, text="Admin Options", font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=20)
        tk.Button(win, text="Add Word", font=("Arial", 12, "bold"), bg="#4CAF50", fg="white",
                  width=18, height=1, command=lambda: [win.destroy(), self.add_word_dialog()]).pack(pady=10)
        tk.Button(win, text="Edit/View Words", font=("Arial", 12, "bold"), bg="#2196F3", fg="white",
                  width=18, height=1, command=self.edit_words_window).pack(pady=10)
        tk.Button(win, text="Close", font=("Arial", 12, "bold"), bg="#F44336", fg="white",
                  width=18, height=1, command=win.destroy).pack(pady=10)

    def edit_words_window(self):
        words = get_saved_words_by_length(1, 100)
        win = tk.Toplevel(self.root)
        win.title("Edit/View Words")
        win.geometry("420x420")
        win.configure(bg="#FFF9B1")
        tk.Label(win, text="Saved Words:", font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=10)
        listbox = tk.Listbox(win, font=("Arial", 14), width=30, height=12)
        for w in words:
            listbox.insert(tk.END, w)
        listbox.pack(pady=10)

        def delete_selected():
            sel = listbox.curselection()
            if not sel:
                return
            item = listbox.get(sel[0])
            with sqlite3.connect(DB_FILENAME) as conn:
                cur = conn.cursor()
                cur.execute("DELETE FROM words WHERE word = ?", (item.upper(),))
            listbox.delete(sel[0])
            messagebox.showinfo("Deleted", f"{item} deleted.")

        def edit_selected():
            sel = listbox.curselection()
            if not sel:
                return
            item = listbox.get(sel[0])
            new_word = simpledialog.askstring("Edit Word", "Enter new word:",
                                              initialvalue=item, parent=win)
            if not new_word:
                return
            if not (3 <= len(new_word) <= 20):
                messagebox.showerror("Error", "Word length must be 3-20 letters.")
                return
            with sqlite3.connect(DB_FILENAME) as conn:
                cur = conn.cursor()
                cur.execute("UPDATE words SET word = ? WHERE word = ?", (new_word.upper(), item.upper()))
            listbox.delete(sel[0])
            listbox.insert(sel[0], new_word.lower())
            messagebox.showinfo("Success", "Word updated.")

        tk.Button(win, text="Edit Selected", font=("Arial", 12, "bold"),
                  bg="#FF9800", fg="white", width=15, command=edit_selected).pack(pady=6)
        tk.Button(win, text="Delete Selected", font=("Arial", 12, "bold"),
                  bg="#F44336", fg="white", width=15, command=delete_selected).pack(pady=6)
        tk.Button(win, text="Close", font=("Arial", 12, "bold"),
                  bg="#9E9E9E", fg="white", width=15, command=win.destroy).pack(pady=6)

    # ------------ main menu (after user selected) ------------
    def build_main_menu(self):
        for w in self.main_frame.winfo_children():
            w.destroy()
        welcome_label = tk.Label(self.main_frame, text=f"Welcome, {self.current_user_name}!",
                                font=("Arial", 20, "bold"), bg="#FFF9B1", fg="#333")
        welcome_label.pack(pady=20)
        btn_frame = tk.Frame(self.main_frame, bg="#FFF9B1")
        btn_frame.pack(pady=10)

        instruction_label1 = tk.Label(self.main_frame, text="SAHAKAR VIDYA MANDIR SCHOOL, Buldhana - 443 002, Maharashtra.",
                                  font=("Arial", 12), bg="#FFF9B1", fg="#555")
        instruction_label1.pack(pady=(0, 15))
        instruction_label2 = tk.Label(self.main_frame, text="Switch user is for admin. You can Quit whenever you want.",
                                  font=("Arial", 12), bg="#F44336", fg="white")
        instruction_label2.pack(pady=(0, 15))

        tk.Button(btn_frame, text="Add Words", font=("Arial", 12, "bold"),
                  bg="#4CAF50", fg="white", width=18, height=1, command=self.add_word_dialog).grid(row=0, column=0, padx=10, pady=8)
        tk.Button(btn_frame, text="Word Exercises", font=("Arial", 12, "bold"),
                  bg="#2196F3", fg="white", width=18, height=1, command=self.word_exercise).grid(row=0, column=1, padx=10, pady=8)
        tk.Button(btn_frame, text="Math Exercises", font=("Arial", 12, "bold"),
                  bg="#FF9800", fg="white", width=18, height=1, command=self.math_exercise).grid(row=1, column=0, padx=10, pady=8)
        tk.Button(btn_frame, text="Show Rewards", font=("Arial", 12, "bold"),
                  bg="#9C27B0", fg="white", width=18, height=1, command=self.show_rewards).grid(row=1, column=1, padx=10, pady=8)
        tk.Button(self.main_frame, text="Switch User / Back", font=("Arial", 12, "bold"),
                  bg="#607D8B", fg="white", width=18, height=1, command=self.build_startup).pack(pady=12)
        tk.Button(self.main_frame, text="Quit", font=("Arial", 12, "bold"),
                  bg="#F44336", fg="white", width=18, height=1, command=self.root.quit).pack(pady=6)

    # ------------ Add word dialog ------------
    def add_word_dialog(self):
        if not self.current_user_id:
            messagebox.showerror("No user", "Please select a user first.")
            return
        win = tk.Toplevel(self.root)
        win.title("Add Word")
        win.geometry("420x300")
        win.configure(bg="#FFF9B1")
        tk.Label(win, text=f"{self.current_user_name}, enter a 3-20 letter word:",
                 font=("Arial", 14, "bold"), bg="#FFF9B1", fg="#333").pack(pady=16)
        entry = tk.Entry(win, font=("Arial", 14), width=20)
        entry.pack(pady=8)
        entry.focus_set()

        def submit_word():
            w = entry.get().strip()
            if not (3 <= len(w) <= 20 and w.isalpha()):
                messagebox.showerror("Error", "Word must be 3-20 alphabetic letters.")
                return
            if is_correct_spelling(w):
                add_word_db(w)
                messagebox.showinfo("Saved", "Word saved.")
                win.destroy()
                return
            suggestions = get_suggestions(w)
            if suggestions:
                msg = "Incorrect spelling. Suggestions:\n" + ", ".join(suggestions) + "\nOr enter corrected word."
            else:
                msg = "Incorrect spelling. Enter corrected word."
            corrected = simpledialog.askstring("Correct Word", msg, parent=win)
            if corrected and is_correct_spelling(corrected) and 3 <= len(corrected) <= 20:
                add_word_db(corrected)
                messagebox.showinfo("Saved", "Corrected word saved.")
                win.destroy()
            else:
                messagebox.showerror("Not saved", "Word not saved. Try again or cancel.")

        tk.Button(win, text="Submit", font=("Arial", 12, "bold"),
                  bg="#4CAF50", fg="white", width=14, command=submit_word).pack(pady=12)
        tk.Button(win, text="Back", font=("Arial", 12, "bold"),
                  bg="#9E9E9E", fg="white", width=10, command=win.destroy).pack(pady=6)

    # ------------ Word exercise ------------
    def word_exercise(self):
        if not self.current_user_id:
            messagebox.showerror("No user", "Please select a user first.")
            return
        difficulty = self.get_user_difficulty_level()

        if difficulty == "Easy":
            min_len, max_len = 3, 4
        elif difficulty == "Medium":
            min_len, max_len = 5, 6
        else:
            min_len, max_len = 7, 20

        words = get_saved_words_by_length(min_len, max_len)
        if not words:
            messagebox.showinfo("No words", "No words of selected difficulty. Add some first.")
            return

        total = 10
        score = 0
        asked = 0

        def ask_one():
            nonlocal asked, score
            if asked >= total:
                save_score_db(self.current_user_id, "Word", score)
                update_rewards_db(self.current_user_id, add_stars=score, add_badge=(score == total))
                messagebox.showinfo("Result", f"{self.current_user_name}, you got {score}/{total} correct! (Difficulty: {difficulty})")
                self.show_rewards()
                if score >= 9:
                    row = get_user_row(self.current_user_name)
                    if row:
                        uid, _, cls = row
                        new_cls = min(8, cls + 1)
                        update_user_class(uid, new_cls)
                return

            word = random.choice(words)
            blanked, correct = generate_blank_word(word)
            qwin = tk.Toplevel(self.root)
            qwin.title("Word Exercise")
            qwin.geometry("420x260")
            qwin.configure(bg="#FFF9B1")
            tk.Label(qwin, text=f"Fill in the blank: {blanked} (Difficulty: {difficulty})",
                     font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=18)
            ent = tk.Entry(qwin, font=("Arial", 14), width=8)
            ent.pack(pady=6)
            ent.focus_set()

            def submit_ans():
                nonlocal score
                ans = ent.get().strip()
                qwin.destroy()
                if len(ans) == 1 and ans.lower() == correct.lower():
                    score += 1
                    messagebox.showinfo("Correct", "Good job!")
                else:
                    messagebox.showinfo("Incorrect", f"Correct letter was: '{correct}'")
                asked_plus()

            tk.Button(qwin, text="Submit", font=("Arial", 12, "bold"),
                      bg="#4CAF50", fg="white", width=12, command=submit_ans).pack(pady=12)
            tk.Button(qwin, text="Back", font=("Arial", 12, "bold"),
                      bg="#9E9E9E", fg="white", width=10, command=lambda: [qwin.destroy(), self.build_main_menu()]).pack(pady=6)

        def asked_plus():
            nonlocal asked
            asked += 1
            if asked <= total:
                ask_one()

        ask_one()

    # ------------ Math exercise ------------
    def math_exercise(self):
        if not self.current_user_id:
            messagebox.showerror("No user", "Please select a user first.")
            return
        difficulty = self.get_user_difficulty_level()

        total = 10
        score = 0
        asked = 0

        def ask_one():
            nonlocal asked, score
            if asked >= total:
                save_score_db(self.current_user_id, "Math", score)
                update_rewards_db(self.current_user_id, add_stars=score, add_badge=(score == total))
                messagebox.showinfo("Result", f"{self.current_user_name}, you got {score}/{total} correct! (Difficulty: {difficulty})")
                self.show_rewards()
                if score >= 9:
                    row = get_user_row(self.current_user_name)
                    if row:
                        uid, _, cls = row
                        new_cls = min(8, cls + 1)
                        update_user_class(uid, new_cls)
                return

            prob, correct_digit = generate_math_problem(self.current_class or 1, difficulty)
            qwin = tk.Toplevel(self.root)
            qwin.title("Math Exercise")
            qwin.geometry("420x260")
            qwin.configure(bg="#FFF9B1")
            tk.Label(qwin, text=f"Solve: {prob} (Difficulty: {difficulty})",
                     font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=18)
            ent = tk.Entry(qwin, font=("Arial", 14), width=8)
            ent.pack(pady=6)
            ent.focus_set()

            def submit_ans():
                nonlocal score
                ans = ent.get().strip()
                qwin.destroy()
                if ans and (correct_digit in ans or ans == correct_digit):
                    score += 1
                    messagebox.showinfo("Correct", "Well done!")
                else:
                    messagebox.showinfo("Incorrect", f"Correct digit was: '{correct_digit}'")
                asked_plus()

            tk.Button(qwin, text="Submit", font=("Arial", 12, "bold"),
                      bg="#4CAF50", fg="white", width=12, command=submit_ans).pack(pady=12)
            tk.Button(qwin, text="Back", font=("Arial", 12, "bold"),
                      bg="#9E9E9E", fg="white", width=10, command=lambda: [qwin.destroy(), self.build_main_menu()]).pack(pady=6)

        def asked_plus():
            nonlocal asked
            asked += 1
            if asked <= total:
                ask_one()

        ask_one()

    # ------------ difficulty selection ------------
    def get_user_difficulty_level(self):
        win = tk.Toplevel(self.root)
        win.title("Select Difficulty")
        win.geometry("360x200")
        win.configure(bg="#FFF9B1")
        tk.Label(win, text="Select Difficulty:", font=("Arial", 14, "bold"),
                 bg="#FFF9B1", fg="#333").pack(pady=12)
        var = tk.StringVar(win)
        var.set("Easy")
        dropdown = ttk.OptionMenu(win, var, "Easy", "Easy", "Medium", "Hard")
        dropdown.config(width=20)
        dropdown.pack(pady=10)

        def submit():
            win.destroy()

        tk.Button(win, text="Submit", font=("Arial", 12, "bold"),
                  bg="#4CAF50", fg="white", width=12, command=submit).pack(pady=10)
        win.grab_set()
        self.root.wait_window(win)
        return var.get()

    # ------------ rewards ------------
    def show_rewards(self):
        if not self.current_user_id:
            messagebox.showerror("No user", "Please select a user first.")
            return
        stars, badges = get_rewards(self.current_user_id)
        messagebox.showinfo("Rewards", f"Stars: {stars}\nBadges: {badges or 'None'}")

# ---------- program start ----------

def main():
    init_db()
    root = tk.Tk()
    app = ChildApp(root)
    users = get_all_users()
    if not users:
        app.add_new_child_dialog()
    root.mainloop()

if __name__ == "__main__":
    main()
