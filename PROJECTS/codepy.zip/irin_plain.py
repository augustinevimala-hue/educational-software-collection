import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3
import random
import threading
import platform
import os
# Removed: import numpy as np # Import numpy for sound generation

# Define distinct, pleasant background colors for main screens
COLOR_MAIN_APP = "#E0F7FA"  # Light Cyan/Aqua (Main/Base)
COLOR_LOGIN = "#FFF3E0"     # Very Light Orange/Cream (Login)
COLOR_MENU = "#E8F5E9"      # Very Light Green/Mint (Menu)
COLOR_TYPING = "#F3E5F5"    # Very Light Purple/Lavender (Typing)
COLOR_SPELL = "#FBEAEB"    # Very Light Pink/Blush (Spell Check)
COLOR_MATH = "#E1F5FE"      # Very Light Blue/Sky (Math)
COLOR_READ = "#FFFDE7"      # Very Light Yellow/Ivory (Read Words)
COLOR_ADMIN = "#FCE4EC"     # Very Light Rose/Rosewater (Admin Panel)


# 1. GLOBAL WORDS LIST
# This list will hold words from DEFAULT_WORDS and words added by any user.
GLOBAL_WORDS = []

# List of default words to ensure the database is populated on first run
DEFAULT_WORDS = [
    "cat", "dog", "mom", "dad", "ball", "apple", "book", "sun", 
    "tree", "milk", "cup", "car", "house", "pen", "bird", "fish", 
    "hat", "shoe", "door", "bed", "run", "jump", "play", "love", 
    "happy", "big", "small", "red", "blue", "green", "yellow", 
    "five", "zero", "nine", "open", "close", "walk", "sing", "talk",
    # Added more words to match the user's mention of ~400 words later
    "water", "flower", "chair", "table", "phone", "light", "street",
    "garden", "window", "paper", "pencil", "clock", "train", "plane",
    "cloud", "rain", "snow", "baby", "sister", "brother", "friend",
    "school", "pencil", "eraser", "ruler", "color", "slide", "swing",
    "robot", "rocket", "stars", "planet", "earth", "moon", "night",
    "mouse", "camel", "tiger", "zebra", "sheep", "goat", "horse",
    "ocean", "beach", "sand", "shell", "wave", "boat", "ship",
    "money", "store", "candy", "sweet", "sour", "cold", "warm",
    "cook", "bake", "wash", "sleep", "dream", "wake", "work"
]

class KidsLearningApp(tk.Tk):
    def __init__(self):
        super().__init__()
        
        # FIX: Cross-platform DPI awareness
        try:
            if platform.system() == "Windows":
                from ctypes import windll
                windll.shcore.SetProcessDpiAwareness(1)
                # TWEAK 1: Maximize window on Windows
                self.state('zoomed') 
            else:
                # TWEAK 1: Maximize window for other systems (Linux, Mac)
                self.attributes('-zoomed', True)
        except:
            pass
            
        self.title("Kids Typing Adventure - Plain Version")
        # Removed self.geometry("800x600")
        # TWEAK 2: Set distinct base color
        self.configure(bg=COLOR_MAIN_APP) 
        
        # REMOVED: Speech engine initialization (pyttsx3)
        self.speech_enabled = False # Explicitly disable speech
        
        # REMOVED: Sound initialization (pygame)
        self.sound_enabled = False # Explicitly disable sound
        
        self.current_user_id = None
        self.current_username = "Guest"
        self.init_database()
        self.update_global_words() # Populate global words on startup
        
        # FIX: Better style configuration and new style for spell check radio buttons
        self.style = ttk.Style()
        self.style.theme_use('clam')  # Use a more reliable theme
        self.style.configure("TButton", font=("Arial", 20, "bold"), padding=10)
        self.style.configure("TRadiobutton", font=("Arial", 24))
        self.style.configure("TEntry", font=("Arial", 24))
        self.style.configure("TLabel", font=("Arial", 30, "bold"))
        
        # NEW STYLE for SpellCheck Quiz focusing
        self.style.configure("Nav.TRadiobutton", 
                             background=COLOR_MAIN_APP, # Use base color as default BG
                             foreground="black",
                             font=("Arial", 24),
                             padding=5)
        # Style for when the radiobutton has focus (navigation highlight)
        self.style.map("Nav.TRadiobutton", 
                       background=[('focus', '#9e9e9e'), ('selected', '#a5d6a7')],
                       foreground=[('focus', 'white'), ('selected', 'black')],
                       indicatorcolor=[('selected', '#3f51b5')]) # Indicator when selected

        self.show_login()

    def play_sound(self, sound_file):
        """Dummy method for sound playing (DISABLED)"""
        pass

    def speak(self, text, block=False):
        """Dummy method for speech (DISABLED)"""
        print(f"[SPEECH: {text}]")
        pass

    def speak_and_exit(self, text, sound_file=None):
        """MODIFIED: Clean exit with visible goodbye message, no sound/speech required"""
        # Create a goodbye window that stays visible
        goodbye_window = tk.Toplevel(self)
        goodbye_window.title("Thank You. Goodbye!")
        goodbye_window.geometry("400x200")
        # TWEAK 2: Use a pleasant color for the goodbye window
        goodbye_window.configure(bg="#FFE0B2") # Very Light Amber
        goodbye_window.resizable(False, False)
        
        # Center the goodbye window
        goodbye_window.transient(self)
        goodbye_window.grab_set()
        
        # Add goodbye message
        tk.Label(goodbye_window, text="👋 Goodbye!", 
                font=("Arial", 32, "bold"), bg="#FFE0B2", fg="#3f51b5").pack(pady=20)
        tk.Label(goodbye_window, text="Thanks for learning with us!", 
                font=("Arial", 18), bg="#FFE0B2", fg="#ff4081").pack(pady=10)
        tk.Label(goodbye_window, text="See you next time! 🌟", 
                font=("Arial", 16), bg="#FFE0B2", fg="#666").pack(pady=10)
        
        # Close after a short wait (no speech/sound to wait for)
        goodbye_window.after(1500, self.quit)


    def init_database(self):
        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            level TEXT DEFAULT 'KG'
        )''')
        # TWEAK 1: Remove user_id from words table to make them global.
        # This will contain all words, for all users.
        c.execute('''CREATE TABLE IF NOT EXISTS words (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            word TEXT NOT NULL UNIQUE
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            exercise TEXT,
            score INTEGER,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )''')
        
        # Insert default words if the table is empty
        # MODIFIED: Use the DEFAULT_WORDS list defined above
        for word in DEFAULT_WORDS:
            try:
                c.execute("INSERT INTO words (word) VALUES (?)", (word,))
            except sqlite3.IntegrityError:
                # Word already exists, no problem
                pass
                
        conn.commit()
        conn.close()
        
    def update_global_words(self):
        """TWEAK 1: Update the GLOBAL_WORDS list from the database"""
        global GLOBAL_WORDS
        try:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            c.execute("SELECT word FROM words ORDER BY word")
            GLOBAL_WORDS = [row[0] for row in c.fetchall()]
            conn.close()
        except sqlite3.Error as e:
            print(f"Database error loading global words: {e}")
            GLOBAL_WORDS = [] # Fallback to empty list

    def show_login(self):
        for widget in self.winfo_children():
            widget.destroy()
        LoginScreen(self)

    def start_session(self, username, user_id):
        self.current_username = username
        self.current_user_id = user_id
        for widget in self.winfo_children():
            widget.destroy()
        MainMenu(self, username, user_id)

    def exit_app(self):
        # MODIFIED: Changed the exit message since there's no sound/speech
        self.speak_and_exit("Goodbye for now!") 

# --- LoginScreen (Color changed) ---

class LoginScreen(tk.Frame):
    def __init__(self, parent):
        # TWEAK 2: Use distinct background color
        super().__init__(parent, bg=COLOR_LOGIN) 
        self.parent = parent
        self.pack(fill=tk.BOTH, expand=True)
        self.create_widgets()

    def create_widgets(self):
        tk.Label(self, text="Welcome to Kids Typing Adventure!", 
                font=("Arial", 32, "bold"), bg=COLOR_LOGIN, fg="#3f51b5").pack(pady=20)
        tk.Label(self, text="Select or Enter Username", 
                font=("Arial", 24), bg=COLOR_LOGIN).pack(pady=10)

        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        c.execute("SELECT id, username FROM users")
        users = c.fetchall()
        conn.close()
        
        usernames = ["Guest"] + [u[1] for u in users]
        self.user_var = tk.StringVar(value="Guest")
        
        combo = ttk.Combobox(self, textvariable=self.user_var, values=usernames, 
                           state="normal", font=("Arial", 20))
        combo.pack(pady=10)
        
        tk.Label(self, text="New Username (optional)", 
                font=("Arial", 20), bg=COLOR_LOGIN).pack()
        self.new_user_entry = ttk.Entry(self, font=("Arial", 20))
        self.new_user_entry.pack(pady=5)
        self.new_user_entry.bind("<Return>", lambda e: self.login())

        btn_frame = ttk.Frame(self, style='TFrame')
        btn_frame.pack(pady=20)
        ttk.Button(btn_frame, text="Login", command=self.login).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)
        
        tk.Label(self, text="Created by Augustine Anbananthan\nDeveloper Note: This is a fun learning tool for kids!", 
                font=("Arial", 12), bg=COLOR_LOGIN).pack(side=tk.BOTTOM, pady=10)

    def login(self):
        username = self.user_var.get()
        new_username = self.new_user_entry.get().strip()
        user_id = None

        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        
        if new_username:
            try:
                c.execute("INSERT INTO users (username) VALUES (?)", (new_username,))
                conn.commit()
                user_id = c.lastrowid
                username = new_username
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "Username already exists!")
                conn.close()
                return
        elif username != "Guest":
            c.execute("SELECT id FROM users WHERE username = ?", (username,))
            row = c.fetchone()
            user_id = row[0] if row else None
            
        conn.close()
        self.parent.start_session(username, user_id)

# --- MainMenu (Color changed) ---

class MainMenu(tk.Frame):
    def __init__(self, parent, username, user_id):
        # TWEAK 2: Use distinct background color
        super().__init__(parent, bg=COLOR_MENU) 
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.pack(fill=tk.BOTH, expand=True)
        
        # Menu navigation variables for highlighting
        self.current_selection = 0
        self.buttons = []
        self.button_commands = []
        self.is_selected = False  # Track if item is selected (red state)
        
        self.create_widgets()
        self.setup_navigation()

    def create_widgets(self):
        tk.Label(self, text=f"Hello, {self.username}!", 
                font=("Arial", 32, "bold"), bg=COLOR_MENU, fg="#3f51b5").pack(pady=20)
        tk.Label(self, text="Choose an activity!", 
                font=("Arial", 24), bg=COLOR_MENU, fg="#ff4081").pack(pady=10)
        
        btn_frame = tk.Frame(self, bg=COLOR_MENU)  # Changed to tk.Frame for custom buttons
        btn_frame.pack(pady=20)
        
        # Define button configurations
        button_configs = [
            ("Typing Exercise", self.open_typing),
            ("Spell Check Quiz", self.open_spellcheck),
            ("Math Practice", self.open_math),
            ("View Scores", self.view_scores),
            ("Read Words", self.read_words),
            ("Switch User", self.switch_user),
            ("Admin", self.open_admin),
            ("Quit", self.parent.exit_app)
        ]
        
        # Create enhanced buttons with highlighting
        for i, (text, cmd) in enumerate(button_configs):
            btn = tk.Button(btn_frame, text=text, 
                          font=("Arial", 18, "bold"),
                          width=18, height=2,
                          bg="#bbdefb",  # Default background (light blue)
                          fg="black",
                          relief="raised",
                          borderwidth=2,
                          command=lambda c=cmd, idx=i: self.button_clicked(c, idx))
            
            btn.grid(row=i//2, column=i%2, padx=15, pady=15, sticky="ew")
            
            # Bind mouse events for highlighting
            btn.bind("<Enter>", lambda e, idx=i: self.on_hover_enter(idx))
            btn.bind("<Leave>", lambda e, idx=i: self.on_hover_leave(idx))
            btn.bind("<Button-1>", lambda e, idx=i: self.on_mouse_click(idx))
            
            self.buttons.append(btn)
            self.button_commands.append(cmd)
        
        # Configure grid weights for equal button sizes
        btn_frame.grid_columnconfigure(0, weight=1)
        btn_frame.grid_columnconfigure(1, weight=1)
        
        # Initial highlighting
        self.update_button_highlighting()
        
        tk.Label(self, text="Created by Augustine Anbananthan\nDeveloper Note: Have fun learning!", 
                font=("Arial", 12), bg=COLOR_MENU).pack(side=tk.BOTTOM, pady=10)

    def setup_navigation(self):
        """Setup keyboard navigation"""
        self.parent.bind("<Up>", self.navigate_up)
        self.parent.bind("<Down>", self.navigate_down)
        self.parent.bind("<Left>", self.navigate_left)
        self.parent.bind("<Right>", self.navigate_right)
        self.parent.bind("<Return>", self.select_current)
        self.parent.bind("<space>", self.select_current)
        self.parent.bind("<Escape>", self.deselect_current)
        
        # Set focus to enable keyboard navigation
        self.focus_set()

    def navigate_up(self, event):
        """Navigate up in the menu (grey highlighting)"""
        if not self.is_selected:
            if self.current_selection >= 2:
                self.current_selection -= 2
                self.update_button_highlighting()
                self.speak_current_option()
        return "break"

    def navigate_down(self, event):
        """Navigate down in the menu (grey highlighting)"""
        if not self.is_selected:
            if self.current_selection < len(self.buttons) - 2:
                self.current_selection += 2
                self.update_button_highlighting()
                self.speak_current_option()
        return "break"

    def navigate_left(self, event):
        """Navigate left in the menu (grey highlighting)"""
        if not self.is_selected:
            if self.current_selection % 2 == 1:  # If on right column
                self.current_selection -= 1
                self.update_button_highlighting()
                self.speak_current_option()
        return "break"

    def navigate_right(self, event):
        """Navigate right in the menu (grey highlighting)"""
        if not self.is_selected:
            if self.current_selection % 2 == 0 and self.current_selection < len(self.buttons) - 1:  # If on left column
                self.current_selection += 1
                self.update_button_highlighting()
                self.speak_current_option()
        return "break"

    def select_current(self, event):
        """Select current option (red highlighting)"""
        if not self.is_selected:
            self.is_selected = True
            self.update_button_highlighting()
            # Removed self.parent.speak(...)
        else:
            # Execute the command
            self.execute_current_command()
        return "break"

    def deselect_current(self, event):
        """Deselect current option (back to grey highlighting)"""
        if self.is_selected:
            self.is_selected = False
            self.update_button_highlighting()
            # Removed self.parent.speak(...)
        return "break"

    def execute_current_command(self):
        """Execute the currently selected command"""
        command = self.button_commands[self.current_selection]
        # Removed self.parent.speak(...)
        
        # Cleanup key bindings before switching screens
        self.cleanup_navigation()
        command()

    def button_clicked(self, command, index):
        """Handle button click"""
        self.current_selection = index
        self.is_selected = True
        self.update_button_highlighting()
        
        # Execute after a short delay to show the red highlighting
        self.after(200, lambda: (self.cleanup_navigation(), command()))

    def on_hover_enter(self, index):
        """Handle mouse hover enter (grey highlighting)"""
        if not self.is_selected:
            self.current_selection = index
            self.update_button_highlighting()

    def on_hover_leave(self, index):
        """Handle mouse hover leave"""
        if not self.is_selected:
            self.update_button_highlighting()

    def on_mouse_click(self, index):
        """Handle mouse click for selection (red highlighting)"""
        self.current_selection = index
        self.is_selected = True
        self.update_button_highlighting()

    def update_button_highlighting(self):
        """Update button colors based on current state"""
        for i, button in enumerate(self.buttons):
            if i == self.current_selection:
                if self.is_selected:
                    # RED highlighting for selected state
                    button.config(bg="#f44336", fg="white", relief="sunken")
                else:
                    # GREY highlighting for navigation
                    button.config(bg="#9e9e9e", fg="white", relief="raised")
            else:
                # Default state (light blue)
                button.config(bg="#bbdefb", fg="black", relief="raised")

    def speak_current_option(self):
        """Dummy method for speaking the option"""
        if hasattr(self.parent, 'speak'):
            button_text = self.buttons[self.current_selection].cget('text')
            self.parent.speak(button_text)

    def cleanup_navigation(self):
        """Clean up keyboard bindings when leaving the menu"""
        try:
            self.parent.unbind("<Up>")
            self.parent.unbind("<Down>")
            self.parent.unbind("<Left>")
            self.parent.unbind("<Right>")
            self.parent.unbind("<Return>")
            self.parent.unbind("<space>")
            self.parent.unbind("<Escape>")
        except:
            pass

    def open_typing(self): 
        self.destroy()
        TypingExercise(self.parent, self.username, self.user_id)
        
    def open_spellcheck(self): 
        self.destroy()
        SpellCheckQuiz(self.parent, self.username, self.user_id)
        
    def open_math(self): 
        self.destroy()
        MathExercise(self.parent, self.username, self.user_id)
        
    def view_scores(self):
        scores_window = tk.Toplevel(self.parent, bg="#f0f8ff")
        scores_window.title(f"{self.username}'s Scores")
        scores_window.geometry("400x400")
        scores_window.resizable(False, False)
        
        tk.Label(scores_window, text="Your Learning Progress! 🎉", 
                font=("Arial", 28, "bold"), bg="#f0f8ff", fg="#3f51b5").pack(pady=15)

        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        # Guest users won't have scores
        if self.user_id:
            c.execute("SELECT exercise, score FROM scores WHERE user_id = ? ORDER BY id DESC LIMIT 10", 
                     (self.user_id,))
            scores = c.fetchall()
        else:
            scores = []
        conn.close()
        
        if scores:
            for ex, sc in scores:
                color = "green" if sc >= 7 else "orange" if sc >= 4 else "red"
                tk.Label(scores_window, text=f"{ex}: {sc}/10", 
                        font=("Arial", 20), bg="#f0f8ff", fg=color).pack(pady=3)
        else:
            tk.Label(scores_window, text="No scores yet. Get started!", 
                    font=("Arial", 20), bg="#f0f8ff", fg="#ff4081").pack(pady=20)
        
        ttk.Button(scores_window, text="Close", command=scores_window.destroy).pack(pady=20)
        scores_window.transient(self.parent)
        scores_window.grab_set()
        
    def read_words(self): 
        self.destroy()
        ReadWords(self.parent, self.username, self.user_id)
        
    def switch_user(self): 
        self.destroy()
        self.parent.show_login()
        
    def open_admin(self): 
        self.destroy()
        AdminPanel(self.parent, self.username, self.user_id)

# --- TypingExercise (Color changed) ---

class TypingExercise(tk.Frame):
    # TWEAK 1: Use GLOBAL_WORDS
    def __init__(self, parent, username, user_id):
        # TWEAK 2: Use distinct background color
        super().__init__(parent, bg=COLOR_TYPING) 
        self.parent = parent
        self.username = username
        self.user_id = user_id
        # Use GLOBAL_WORDS
        if GLOBAL_WORDS:
            self.words = random.sample(GLOBAL_WORDS, min(10, len(GLOBAL_WORDS)))
        else:
            self.words = []
        self.current_word_index = 0
        self.pack(fill=tk.BOTH, expand=True)
        
        # Initialize all required attributes BEFORE create_widgets
        self.key_buttons = {}
        self.entry_var = None
        self.entry = None
        self.word_label = None
        self.instruction_label = None
        self.feedback = None
        self.enter_btn = None
        self.current_word = ""
        
        self.create_widgets()
        if self.words:
            self.show_word()
        else:
            self.word_label.config(text="No words available. Add some in Admin Panel!", fg="red")
            self.parent.speak("No words available. Please add some in the Admin Panel.")

    def create_widgets(self):
        tk.Label(self, text="Type the word shown below", 
                font=("Arial", 24), bg=COLOR_TYPING).pack(pady=10)
        
        # FIX: Single instruction label that updates
        self.instruction_label = tk.Label(self, text="Press the highlighted key!", 
                                        font=("Arial", 20), bg=COLOR_TYPING, fg="#ff4081")
        self.instruction_label.pack(pady=5)
        
        self.word_label = tk.Label(self, text="", font=("Arial", 36, "bold"), 
                                  bg=COLOR_TYPING, fg="#d81b60")
        self.word_label.pack(pady=10)
        
        self.entry_var = tk.StringVar()
        self.entry = ttk.Entry(self, textvariable=self.entry_var, 
                              font=("Arial", 28), width=20)
        self.entry.pack(pady=10)
        self.entry.bind("<Key>", self.on_key_press)
        self.entry.bind("<Return>", lambda e: self.check_word())
        self.entry.bind("<Escape>", lambda e: self.back())
        self.entry.focus_set()

        # Virtual keyboard
        kb_frame = ttk.Frame(self)
        kb_frame.pack(pady=10)
        
        rows = ["qwertyuiop", "asdfghjkl", "zxcvbnm"]
        for row in rows:
            row_frame = ttk.Frame(kb_frame)
            row_frame.pack()
            for ch in row:
                btn = tk.Button(row_frame, text=ch.upper(), width=5, height=2, 
                               bg="#bbdefb", font=("Arial", 20, "bold"))
                btn.pack(side=tk.LEFT, padx=3)
                self.key_buttons[ch] = btn

        self.enter_btn = tk.Button(self, text="Enter (Submit)", width=15, 
                                  bg="#a5d6a7", command=self.check_word, 
                                  font=("Arial", 20, "bold"))
        self.enter_btn.pack(pady=5)
        
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)
        
        self.feedback = tk.Label(self, text="", font=("Arial", 24), bg=COLOR_TYPING)
        self.feedback.pack(pady=5)

    def show_word(self):
        if self.current_word_index >= len(self.words):
            self.word_label.config(text="All done! Great job!", fg="#4caf50")
            self.entry.config(state="disabled")
            self.enter_btn.config(state="disabled")
            self.feedback.config(text="Exercise completed!", fg="green")
            self.instruction_label.config(text="Well done! 🎉")
            
            continue_btn = ttk.Button(self, text="Back to Menu", command=self.back)
            continue_btn.pack(pady=20)
            
            self.parent.play_sound("correct.wav") # Dummy call
            # Removed self.parent.speak(...)
            return
            
        self.current_word = self.words[self.current_word_index].lower()
        self.word_label.config(text=self.current_word.upper(), fg="#d81b60")
        self.entry_var.set("")
        self.update_keyboard()
        self.update_instruction_text()
        self.entry.focus_set()
        
        # Removed self.parent.speak(...)

    def update_keyboard(self):
        current_text = self.entry_var.get()
        current_letter_index = len(current_text)
        
        # Reset all keys
        for btn in self.key_buttons.values():
            btn.config(bg="#bbdefb")
        self.enter_btn.config(bg="#a5d6a7")
        
        # Highlight next key
        if current_letter_index < len(self.current_word):
            ch = self.current_word[current_letter_index]
            if ch in self.key_buttons:
                self.key_buttons[ch].config(bg="#ffd54f")
        else:
            self.enter_btn.config(bg="#4caf50")

    def update_instruction_text(self):
        current_text = self.entry_var.get()
        current_letter_index = len(current_text)
        
        if current_letter_index < len(self.current_word):
            next_char = self.current_word[current_letter_index].upper()
            instruction = f"Press the key: {next_char}!"
        else:
            instruction = "Press Enter to check!"
            
        # FIX: Update existing label instead of creating new ones
        self.instruction_label.config(text=instruction)

    def on_key_press(self, event):
        if event.keysym in ("Return", "Escape", "BackSpace", "Shift_L", "Shift_R", 
                           "Control_L", "Control_R", "Alt_L", "Alt_R"):
            if event.keysym == "BackSpace":
                self.after(10, self.update_after_input)
            return
            
        ch = event.char.lower()
        
        if ch.isalpha():
            current_text = self.entry_var.get()
            expected_index = len(current_text)
            
            if expected_index < len(self.current_word):
                expected_char = self.current_word[expected_index]
                
                if ch == expected_char:
                    self.feedback.config(text="Good!", fg="green")
                    self.parent.play_sound("correct.wav") # Dummy call
                    self.after(10, self.update_after_input)
                    return
                else:
                    self.feedback.config(text=f"Wrong key! Try {expected_char.upper()}", fg="red")
                    # Removed self.parent.speak(...)
                    self.parent.play_sound("wrong.wav") # Dummy call
                    return "break"
            else:
                return "break"
        
        return "break"

    def update_after_input(self):
        self.update_keyboard()
        self.update_instruction_text()
        
    def check_word(self, event=None):
        typed_word = self.entry_var.get().lower().strip()
        
        if typed_word == self.current_word:
            # TWEAK 1: Removed save_word call as words are now globally managed
            self.current_word_index += 1
            self.feedback.config(text="Correct! ✓", fg="green")
            # Removed self.parent.speak(...)
            self.parent.play_sound("correct.wav") # Dummy call
            self.after(1500, self.show_word)
        else:
            if typed_word:
                self.feedback.config(text="Not quite right. Try again!", fg="red")
                # Removed self.parent.speak(...)
                self.parent.play_sound("wrong.wav") # Dummy call
            else:
                self.feedback.config(text="Please type the complete word!", fg="orange")
                # Removed self.parent.speak(...)
            
            self.entry_var.set("")
            self.update_after_input()

    def back(self):
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

# --- SpellCheckQuiz (Color changed) ---

class SpellCheckQuiz(tk.Frame):
    # TWEAK 1: Use GLOBAL_WORDS
    def __init__(self, parent, username, user_id):
        # TWEAK 2: Use distinct background color
        super().__init__(parent, bg=COLOR_SPELL) 
        self.parent = parent
        self.username = username
        self.user_id = user_id
        # Use GLOBAL_WORDS
        if GLOBAL_WORDS:
            self.words = random.sample(GLOBAL_WORDS, min(10, len(GLOBAL_WORDS)))
        else:
            self.words = []
            
        self.current_question = 0
        self.attempts = 0
        self.score = 0
        self.pack(fill=tk.BOTH, expand=True)
        
        # Initialize attributes before create_widgets
        self.choice_var = tk.StringVar()
        self.radio_buttons = []
        self.word_label = None
        self.choices_frame = None
        self.feedback = None
        
        self.create_widgets()
        if self.words:
            self.show_question()
            self.speak_instruction()
        else:
            self.word_label.config(text="No words available. Add some in Admin Panel!", fg="red")
            self.parent.speak("No words available. Please add some in the Admin Panel.")

    def speak_instruction(self):
        instruction = "Choose the correct spelling using mouse or keyboard navigation. Tab to navigate, space bar to select. Press Enter to submit."
        self.parent.speak(instruction) # Dummy call

    def create_widgets(self):
        tk.Label(self, text="Spell Check Quiz", 
                font=("Arial", 32, "bold"), bg=COLOR_SPELL, fg="#3f51b5").pack(pady=10)
        tk.Label(self, text="Choose the correct spelling!Use tab to navigate, space bar to select and ENTER key to submit. You can also use the mouse.", 
                font=("Arial", 24), bg=COLOR_SPELL, fg="#ff4081").pack(pady=5)
        
        self.word_label = tk.Label(self, text="", font=("Arial", 32, "bold"), bg=COLOR_SPELL)
        self.word_label.pack(pady=10)
        
        self.choices_frame = ttk.Frame(self)
        self.choices_frame.pack(pady=10)
        
        self.feedback = tk.Label(self, text="", font=("Arial", 24), bg=COLOR_SPELL)
        self.feedback.pack(pady=5)
        
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Submit", command=self.check_answer).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)

    def show_question(self):
        if not self.words:
            return
            
        if self.current_question >= len(self.words):
            self.save_score()
            self.word_label.config(text=f"Quiz Complete! Score: {self.score}/{len(self.words)}", fg="#4caf50")
            
            for widget in self.choices_frame.winfo_children():
                widget.destroy()
                
            self.feedback.config(text="Well done! 🎉", fg="green")
            
            result_frame = ttk.Frame(self)
            result_frame.pack(pady=20)
            ttk.Button(result_frame, text="Try Again", command=self.restart_quiz).pack(side=tk.LEFT, padx=10)
            ttk.Button(result_frame, text="Back to Menu", command=self.back).pack(side=tk.LEFT, padx=10)
            
            self.parent.play_sound("result.wav") # Dummy call
            # Removed self.parent.speak(...)
            return
            
        self.attempts = 0
        self.choice_var.set("")
        current_word = self.words[self.current_question]
        
        # Removed self.parent.speak(...)
        
        self.word_label.config(text=f"Question {self.current_question + 1}: Choose the correct spelling", 
                              fg="#d81b60")
        
        # Create choices with one correct and three incorrect spellings
        choices = [current_word]
        for _ in range(3):
            wrong_word = self.create_wrong_spelling(current_word)
            while wrong_word in choices:
                wrong_word = self.create_wrong_spelling(current_word)
            choices.append(wrong_word)
        
        random.shuffle(choices)
        
        # Clear previous choices
        for widget in self.choices_frame.winfo_children():
            widget.destroy()
            
        self.radio_buttons = []
        for choice in choices:
            # TWEAK 2: Use the new style for radio buttons
            rb = ttk.Radiobutton(self.choices_frame, text=choice, value=choice, 
                               variable=self.choice_var, style="Nav.TRadiobutton")
            rb.pack(anchor="w", pady=5, padx=20)
            self.radio_buttons.append(rb)
            
            # TWEAK 2: Bind events for visual feedback
            rb.bind("<FocusIn>", self.on_radio_focus_in)
            rb.bind("<FocusOut>", self.on_radio_focus_out)
            # The select_current will handle the spacebar selection highlight

        self.feedback.config(text=f"Attempts left: 3", fg="#3f51b5")
        self.setup_keyboard_navigation()
    
    def on_radio_focus_in(self, event):
        """TWEAK 2: Handle focus in (navigation highlight)"""
        # The 'focus' map in the style handles the color change
        pass

    def on_radio_focus_out(self, event):
        """TWEAK 2: Handle focus out"""
        # The 'background' map in the style handles the color change
        # If it was selected (spacebar pressed), maintain the selected state color
        widget = event.widget
        if self.choice_var.get() == widget.cget("value"):
            widget.config(style="Nav.TRadiobutton") # Keeps the selected state visually

    def create_wrong_spelling(self, word):
        """FIX: Create more realistic wrong spellings"""
        if len(word) < 2:
            return word + 'x'
            
        methods = [
            lambda w: w[1:] + w[0],  # Move first letter to end
            lambda w: w[:-1] + ('x' if w[-1] != 'x' else 'z'),  # Change last letter
            lambda w: w[:len(w)//2] + ('x' if w[len(w)//2] != 'x' else 'z') + w[len(w)//2+1:] if len(w) > 2 else w + 'x',  # Change middle letter
            lambda w: w[0] + w[2:] + w[1] if len(w) > 2 else w + 'x',  # Swap 2nd and 3rd letter
        ]
        
        method = random.choice(methods)
        try:
            result = method(word)
            return result if result != word else word + 'x'
        except:
            return word + 'x'
    
    def setup_keyboard_navigation(self):
        """FIX: Better keyboard navigation"""
        # Unbind previous bindings first
        self.cleanup_navigation()
        self.parent.bind("<Up>", self.navigate_up)
        self.parent.bind("<Down>", self.navigate_down)
        self.parent.bind("<Tab>", self.navigate_tab)
        self.parent.bind("<space>", self.select_current)
        self.parent.bind("<Return>", self.check_answer)
        
        # Focus first radio button
        if self.radio_buttons:
            self.radio_buttons[0].focus_set()

    def cleanup_navigation(self):
        """Clean up keyboard bindings when leaving the quiz"""
        try:
            self.parent.unbind("<Up>")
            self.parent.unbind("<Down>")
            self.parent.unbind("<Tab>")
            self.parent.unbind("<space>")
            self.parent.unbind("<Return>")
        except:
            pass

    def navigate_up(self, event):
        current = self.parent.focus_get()
        if current in self.radio_buttons:
            index = self.radio_buttons.index(current)
            prev_index = (index - 1) % len(self.radio_buttons)
            self.radio_buttons[prev_index].focus_set()
        return "break"

    def navigate_down(self, event):
        current = self.parent.focus_get()
        if current in self.radio_buttons:
            index = self.radio_buttons.index(current)
            next_index = (index + 1) % len(self.radio_buttons)
            self.radio_buttons[next_index].focus_set()
        return "break"
        
    def navigate_tab(self, event):
        """Allow tab navigation to cycle through radio buttons and then other widgets"""
        current = self.parent.focus_get()
        if current in self.radio_buttons:
            index = self.radio_buttons.index(current)
            # Find next focusable widget
            try:
                next_index = (index + 1) % len(self.radio_buttons)
                self.radio_buttons[next_index].focus_set()
            except:
                # Fall back to default Tkinter focus if radio buttons are the last items
                return
            return "break" # Stop default tab behavior on radio buttons
        return

    def select_current(self, event):
        """TWEAK 2: Select current option with spacebar and make it colorful"""
        current = self.parent.focus_get()
        if current in self.radio_buttons:
            # Set the choice variable
            selected_value = current.cget("value")
            self.choice_var.set(selected_value)
            
            # Update styles to make the selected one colorful
            for rb in self.radio_buttons:
                if rb.cget("value") == selected_value:
                    # 'selected' map in the style makes it colorful
                    rb.config(style="Nav.TRadiobutton") 
                else:
                    rb.config(style="Nav.TRadiobutton") # Reset to default non-selected state
        return "break"

    def check_answer(self, event=None):
        selected = self.choice_var.get()
        if not selected:
            self.feedback.config(text="Please select an option!", fg="red")
            self.parent.play_sound("wrong.wav") # Dummy call
            return
            
        correct = self.words[self.current_question]
        
        if selected == correct:
            self.score += 1
            self.feedback.config(text="Correct! ✓", fg="green")
            # Removed self.parent.speak(...)
            self.current_question += 1
            self.parent.play_sound("correct.wav") # Dummy call
            # Clear selection highlighting
            self.choice_var.set("")
            self.after(1500, self.show_question)
        else:
            self.attempts += 1
            if self.attempts >= 3:
                self.feedback.config(text=f"Correct spelling: {correct}", 
                                   fg="red", font=("Arial", 28, "bold"))
                # Removed self.parent.speak(...)
                self.current_question += 1
                self.parent.play_sound("wrong.wav") # Dummy call
                # Clear selection highlighting
                self.choice_var.set("")
                self.after(2000, self.show_question)
            else:
                self.feedback.config(text=f"Wrong! Attempts left: {3 - self.attempts}", fg="red")
                # Removed self.parent.speak(...)
                self.choice_var.set("")
                # Reset selection highlighting for all radio buttons
                for rb in self.radio_buttons:
                    rb.config(style="Nav.TRadiobutton")
                # Re-focus the first one
                if self.radio_buttons:
                    self.radio_buttons[0].focus_set()
                self.parent.play_sound("wrong.wav") # Dummy call

    def save_score(self):
        if self.user_id:
            try:
                conn = sqlite3.connect('learning.db')
                c = conn.cursor()
                c.execute("INSERT INTO scores (user_id, exercise, score) VALUES (?, ?, ?)", 
                         (self.user_id, "SpellCheck", self.score))
                conn.commit()
                conn.close()
            except sqlite3.Error as e:
                print(f"Database error: {e}")

    def restart_quiz(self):
        self.destroy()
        SpellCheckQuiz(self.parent, self.username, self.user_id)

    def back(self):
        self.cleanup_navigation()
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

# --- MathExercise (Color changed) ---

class MathExercise(tk.Frame):
    def __init__(self, parent, username, user_id):
        # TWEAK 2: Use distinct background color
        super().__init__(parent, bg=COLOR_MATH) 
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.questions = [(random.randint(1, 10), random.randint(1, 10)) for _ in range(10)]
        self.current_question = 0
        self.score = 0
        self.pack(fill=tk.BOTH, expand=True)
        
        # Initialize attributes before create_widgets
        self.question_label = None
        self.answer_var = None
        self.answer_entry = None
        self.feedback = None
        
        self.create_widgets()
        self.show_question()
        self.speak_instruction()
        
    def speak_instruction(self):
        self.parent.speak("Enter the number answer and press submit or Enter key.") # Dummy call

    def create_widgets(self):
        tk.Label(self, text="Math Practice", 
                font=("Arial", 32, "bold"), bg=COLOR_MATH, fg="#3f51b5").pack(pady=10)
        tk.Label(self, text="Solve the addition problems!", 
                font=("Arial", 24), bg=COLOR_MATH, fg="#ff4081").pack(pady=5)
        
        self.question_label = tk.Label(self, text="", font=("Arial", 36, "bold"), 
                                     bg=COLOR_MATH, fg="#d81b60")
        self.question_label.pack(pady=10)
        
        self.answer_var = tk.StringVar()
        self.answer_entry = ttk.Entry(self, textvariable=self.answer_var, 
                                    font=("Arial", 28), width=10, justify='center')
        self.answer_entry.pack(pady=10)
        self.answer_entry.bind("<Return>", self.check_answer)
        self.answer_entry.bind("<KeyPress>", self.validate_number_input)
        
        self.feedback = tk.Label(self, text="", font=("Arial", 24), bg=COLOR_MATH)
        self.feedback.pack(pady=5)
        
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Submit", command=self.check_answer).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)

    def validate_number_input(self, event):
        """FIX: Only allow numbers and basic editing keys"""
        if event.char.isdigit() or event.keysym in ('BackSpace', 'Delete', 'Left', 'Right', 'Return'):
            return
        else:
            return "break"

    def show_question(self):
        if self.current_question >= len(self.questions):
            self.save_score()
            self.question_label.config(text=f"Math Complete! Score: {self.score}/10", fg="#4caf50")
            self.answer_entry.config(state="disabled")
            self.feedback.config(text="Great work! 🎉", fg="green")
            
            result_frame = ttk.Frame(self)
            result_frame.pack(pady=20)
            ttk.Button(result_frame, text="Try Again", command=self.restart).pack(side=tk.LEFT, padx=10)
            ttk.Button(result_frame, text="Back to Menu", command=self.back).pack(side=tk.LEFT, padx=10)
            
            self.parent.play_sound("result.wav") # Dummy call
            # Removed self.parent.speak(...)
            return
            
        a, b = self.questions[self.current_question]
        self.question_label.config(text=f"{a} + {b} = ?", fg="#d81b60")
        self.answer_var.set("")
        self.answer_entry.focus()
        self.feedback.config(text="")
        
        # Removed self.parent.speak(...)

    def check_answer(self, event=None):
        try:
            answer = int(self.answer_var.get().strip())
            a, b = self.questions[self.current_question]
            correct_answer = a + b
            
            if answer == correct_answer:
                self.score += 1
                self.feedback.config(text="Correct! ✓", fg="green")
                # Removed self.parent.speak(...)
                self.current_question += 1
                self.parent.play_sound("correct.wav") # Dummy call
                self.after(1500, self.show_question)
            else:
                self.feedback.config(text=f"Not quite. The answer is {correct_answer}", fg="red")
                # Removed self.parent.speak(...)
                self.current_question += 1
                self.parent.play_sound("wrong.wav") # Dummy call
                self.after(2000, self.show_question)
                
        except ValueError:
            self.feedback.config(text="Please enter a valid number!", fg="red")
            # Removed self.parent.speak(...)
            self.parent.play_sound("wrong.wav") # Dummy call

    def save_score(self):
        if self.user_id:
            try:
                conn = sqlite3.connect('learning.db')
                c = conn.cursor()
                c.execute("INSERT INTO scores (user_id, exercise, score) VALUES (?, ?, ?)", 
                         (self.user_id, "Math", self.score))
                conn.commit()
                conn.close()
            except sqlite3.Error as e:
                print(f"Database error: {e}")

    def restart(self):
        self.destroy()
        MathExercise(self.parent, self.username, self.user_id)

    def back(self):
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

# --- ReadWords (Color changed) ---

class ReadWords(tk.Frame):
    # TWEAK 1: Use GLOBAL_WORDS
    def __init__(self, parent, username, user_id):
        # TWEAK 2: Use distinct background color
        super().__init__(parent, bg=COLOR_READ) 
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.pack(fill=tk.BOTH, expand=True)
        
        # Initialize attributes before other method calls
        # Use GLOBAL_WORDS
        self.words = GLOBAL_WORDS 
        self.current_word = 0
        self.instruction_label = None
        self.word_label = None
        
        self.create_widgets()
        if self.words:
            self.show_word()

    def create_widgets(self):
        tk.Label(self, text="Read Global Words", 
                font=("Arial", 32, "bold"), bg=COLOR_READ, fg="#3f51b5").pack(pady=10)
        
        self.instruction_label = tk.Label(self, text="View and practice the words!", 
                                        font=("Arial", 24), bg=COLOR_READ, fg="#ff4081")
        self.instruction_label.pack(pady=5)
        
        self.word_label = tk.Label(self, text="No words yet. Try the Admin Panel first!", 
                                 font=("Arial", 36, "bold"), bg=COLOR_READ, fg="#d81b60")
        self.word_label.pack(pady=20)
        
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        
        if self.words:
            ttk.Button(btn_frame, text="Next Word", command=self.next_word).pack(side=tk.LEFT, padx=10)
            ttk.Button(btn_frame, text="Repeat", command=self.read_aloud).pack(side=tk.LEFT, padx=10)
            
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)
        
        # Removed self.parent.speak(...)

    def show_word(self):
        if self.words and self.current_word < len(self.words):
            word = self.words[self.current_word]
            self.word_label.config(text=word.upper(), fg="#d81b60")
            self.read_aloud(initial_read=True)

    def next_word(self):
        if self.words:
            self.current_word = (self.current_word + 1) % len(self.words)
            self.show_word()

    def read_aloud(self, initial_read=False):
        if self.words and self.current_word < len(self.words):
            word = self.words[self.current_word]
            self.parent.speak(word) # Dummy call

    def back(self):
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

# --- AdminPanel (Color changed) ---

class AdminPanel(tk.Frame):
    def __init__(self, parent, username, user_id):
        # TWEAK 2: Use distinct background color
        super().__init__(parent, bg=COLOR_ADMIN) 
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.pack(fill=tk.BOTH, expand=True)
        
        # Initialize attributes before create_widgets
        self.word_map = {}  # Maps listbox index to database ID
        self.word_listbox = None
        self.word_entry = None
        
        self.create_widgets()

    def create_widgets(self):
        tk.Label(self, text="Admin Panel", 
                font=("Arial", 32, "bold"), bg=COLOR_ADMIN, fg="#3f51b5").pack(pady=10)
        tk.Label(self, text="Manage the GLOBAL word list", 
                font=("Arial", 24), bg=COLOR_ADMIN, fg="#ff4081").pack(pady=5)
        
        # Word list display
        list_frame = ttk.Frame(self)
        list_frame.pack(pady=10, padx=20, fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.word_listbox = tk.Listbox(list_frame, font=("Arial", 20), height=10,
                                      yscrollcommand=scrollbar.set)
        self.word_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.word_listbox.yview)
        
        # Word entry
        entry_frame = ttk.Frame(self)
        entry_frame.pack(pady=5)
        
        tk.Label(entry_frame, text="Add new word:", font=("Arial", 18), bg=COLOR_ADMIN).pack()
        self.word_entry = ttk.Entry(entry_frame, font=("Arial", 20), width=20)
        self.word_entry.pack(pady=5)
        self.word_entry.bind("<Return>", lambda e: self.add_word())
        
        # Buttons
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        
        ttk.Button(btn_frame, text="Add Word", command=self.add_word).pack(side=tk.LEFT, padx=10)
        # NEW FUNCTIONALITY: Append words from file
        ttk.Button(btn_frame, text="Append from File", command=self.append_from_file).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Delete Duplicates", command=self.delete_duplicates).pack(side=tk.LEFT, padx=10) 
        ttk.Button(btn_frame, text="Delete Selected", command=self.delete_word).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Clear All", command=self.clear_all_words).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)
        
        self.load_words()

    def load_words(self):
        self.word_listbox.delete(0, tk.END)
        self.word_map = {}
            
        try:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            # TWEAK 1: Load all words from the now global words table
            c.execute("SELECT id, word FROM words ORDER BY word")
            
            for i, (word_id, word) in enumerate(c.fetchall()):
                self.word_listbox.insert(tk.END, word)
                self.word_map[i] = word_id
                
            conn.close()
            self.parent.update_global_words() # Update global list after loading
        except sqlite3.Error as e:
            print(f"Database error: {e}")

    def add_word(self):
        word = self.word_entry.get().strip().lower()
        if not word:
            messagebox.showwarning("Warning", "Please enter a word!")
            return
            
        if not word.isalpha():
            messagebox.showwarning("Warning", "Please enter letters only!")
            return
            
        try:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            # TWEAK 1: Insert into the global words table
            c.execute("INSERT INTO words (word) VALUES (?)", (word,))
            conn.commit()
            conn.close()
            
            self.word_entry.delete(0, tk.END)
            self.load_words()
            messagebox.showinfo("Success", f"Word '{word}' added successfully!")
            
        except sqlite3.IntegrityError:
            messagebox.showwarning("Warning", "This word already exists!")
        except sqlite3.Error as e:
            messagebox.showerror("Error", f"Database error: {e}")

    # NEW FUNCTIONALITY: Append words from a text file
    def append_from_file(self):
        file_path = filedialog.askopenfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            title="Select a text file with words"
        )
        if not file_path:
            return

        words_to_add = []
        try:
            with open(file_path, 'r') as f:
                for line in f:
                    # Clean the word: remove whitespace, convert to lowercase, check for alpha
                    word = line.strip().lower()
                    if word and word.isalpha():
                        words_to_add.append(word)
        except Exception as e:
            messagebox.showerror("Error", f"Could not read file: {e}")
            return

        if not words_to_add:
            messagebox.showwarning("Warning", "No valid words found in the file (must be letters only).")
            return
            
        added_count = 0
        skipped_count = 0
        
        try:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            for word in words_to_add:
                try:
                    c.execute("INSERT INTO words (word) VALUES (?)", (word,))
                    added_count += 1
                except sqlite3.IntegrityError:
                    skipped_count += 1
            conn.commit()
            conn.close()
            
            self.load_words()
            messagebox.showinfo(
                "Success", 
                f"Finished importing from file:\nWords added: {added_count}\nWords skipped (already exist): {skipped_count}"
            )
            
        except sqlite3.Error as e:
            messagebox.showerror("Error", f"Database error during import: {e}")
    def delete_duplicates(self):
        if not messagebox.askyesno("Confirm", "Are you sure you want to remove all duplicate word entries?"):
            return
            
        try:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            
            # SQL to delete duplicate words, keeping the oldest entry (min(id)).
            c.execute('''
                DELETE FROM words 
                WHERE id NOT IN (
                    SELECT MIN(id) 
                    FROM words 
                    GROUP BY word
                )
            ''')
            
            deleted_count = c.rowcount
            conn.commit()
            conn.close()
            
            self.load_words()
            
            if deleted_count > 0:
                messagebox.showinfo("Success", f"Successfully deleted {deleted_count} duplicate word entries!")
            else:
                messagebox.showinfo("Success", "No duplicate word entries were found.")
            
        except sqlite3.Error as e:
            messagebox.showerror("Error", f"Database error during duplicate deletion: {e}")     
  

  # Existing delete_word and clear_all_words methods are kept the same
    def delete_word(self):
        try:
            selection = self.word_listbox.curselection()
            if not selection:
                messagebox.showwarning("Warning", "Please select a word to delete!")
                return
            
            listbox_index = selection[0]
            word_id_to_delete = self.word_map.get(listbox_index)
            
            if word_id_to_delete is None:
                messagebox.showerror("Error", "Invalid selection.")
                return

            # Confirm deletion
            word_to_delete = self.word_listbox.get(listbox_index)
            if not messagebox.askyesno("Confirm", f"Delete the word '{word_to_delete}'?"):
                return

            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            # TWEAK 1: Delete from the global words table
            c.execute("DELETE FROM words WHERE id = ?", (word_id_to_delete,))
            conn.commit()
            conn.close()
            
            self.load_words()
            messagebox.showinfo("Success", "Word deleted successfully!")
            
        except sqlite3.Error as e:
            messagebox.showerror("Error", f"Database error: {e}")
        except tk.TclError:
            messagebox.showwarning("Warning", "Please select a word to delete!")

    def clear_all_words(self):
        
        if not messagebox.askyesno("Confirm", "Delete ALL words? This cannot be undone!"):
            return
            
        try:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            # TWEAK 1: Clear all words from the global words table
            c.execute("DELETE FROM words")
            conn.commit()
            conn.close()
            
            self.load_words()
            messagebox.showinfo("Success", "All words deleted successfully!")
            
        except sqlite3.Error as e:
            messagebox.showerror("Error", f"Database error: {e}")

    def back(self):
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

if __name__ == "__main__":
    try:
        app = KidsLearningApp()
        app.mainloop()
    except KeyboardInterrupt:
        print("\nApplication closed by user.")
    except Exception as e:
        print(f"An error occurred: {e}")
        # Note: If running without a display, messagebox will fail.
        # messagebox.showerror("Error", f"An unexpected error occurred: {e}")
        # Keep the print for robust execution environment.