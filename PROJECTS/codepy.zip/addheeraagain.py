import pyttsx3

print("--- Available TTS Voices ---")

engine = pyttsx3.init()
voices = engine.getProperty('voices')

for v in voices:
    print(v.id)
