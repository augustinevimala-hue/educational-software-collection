import tkinter as tk
from tkinter import messagebox
import datetime

students = {
    101: {'name': 'Arun', 'class': 10, 'section': 'A'},
    102: {'name': 'Beena', 'class': 11, 'section': 'B'}
}
books = {
    1001: {'title': 'Python Basics'},
    1002: {'title': 'Data Science'}
}
transactions = []

def liststudents():
    return "\n".join(f"{mno} - {s['name']} Class {s['class']}{s['section']}" for mno, s in students.items())

def listbooks():
    return "\n".join(f"{acc} - {b['title']}" for acc, b in books.items())

def issuebook(mno, accno):
    if mno not in students:
        return "No such membership number."
    if accno not in books:
        return "No such book number."
    issued = [t for t in transactions if t['mno'] == mno and t['returndate'] is None]
    if len(issued) >= 3:
        return "This student already has 3 books."
    for t in transactions:
        if t['accno'] == accno and t['returndate'] is None:
            return "This book is already issued."
    transactions.append({
        'mno': mno,
        'accno': accno,
        'issuedate': datetime.date.today(),
        'returndate': None,
        'remarks': 'ISSUED'
    })
    return f"Book {books[accno]['title']} issued to student {mno} - {students[mno]['name']}."

def on_issue_click():
    try:
        mno = int(member_entry.get())
        accno = int(book_entry.get())
    except ValueError:
        messagebox.showerror("Input Error", "Please enter valid integers for member and book numbers.")
        return
    result = issuebook(mno, accno)
    messagebox.showinfo("Issue Book", result)

root = tk.Tk()
root.title("Student Book Issue")

tk.Label(root, text="Membership Number").pack()
member_entry = tk.Entry(root)
member_entry.pack()

tk.Label(root, text="Book Access Number").pack()
book_entry = tk.Entry(root)
book_entry.pack()

tk.Button(root, text="Issue Book", command=on_issue_click).pack()
tk.Button(root, text="List Students", command=lambda: messagebox.showinfo("Students", liststudents())).pack()
tk.Button(root, text="List Books", command=lambda: messagebox.showinfo("Books", listbooks())).pack()

root.mainloop()
