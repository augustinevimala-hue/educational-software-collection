#!/usr/bin/env python3
"""
Simple PDF Merger for Staff Cards
Place this script in the same folder as your Excel file and run it after creating individual PDFs.
"""

import os
import glob
#from PyPDF2 import PdfMerger
from pypdf import PdfWriter  # PdfWriter is used for merging in new pypdf

def merge_staff_pdfs():
    """Merge all Staff_Cards_MNO_*.pdf files into one combined PDF"""
    
    # Find all individual PDF files
    pdf_files = glob.glob("Staff_Cards_MNO_*.pdf")
    
    if not pdf_files:
        print("❌ No individual PDF files found!")
        print("Expected files: Staff_Cards_MNO_5001.pdf, Staff_Cards_MNO_5009.pdf, etc.")
        return
    
    # Sort files by MNO number
    pdf_files.sort(key=lambda x: int(x.split('_MNO_')[1].split('.pdf')[0]))
    
    print(f"Found {len(pdf_files)} PDF files to merge:")
    for pdf in pdf_files:
        print(f"  - {pdf}")
    
    # Create merger
    merger = PdfWriter()
    
    # Add each PDF
    for pdf_file in pdf_files:
        try:
            merger.append(pdf_file)
            print(f"✅ Added: {pdf_file}")
        except Exception as e:
            print(f"❌ Error adding {pdf_file}: {e}")
    
    # Create combined PDF
    output_file = "Staff_Cards_Combined.pdf"
    merger.write(output_file)
    merger.close()
    
    print(f"\n🎉 SUCCESS! Combined PDF created: {output_file}")
    print(f"File size: {os.path.getsize(output_file)} bytes")

if __name__ == "__main__":
    merge_staff_pdfs()

