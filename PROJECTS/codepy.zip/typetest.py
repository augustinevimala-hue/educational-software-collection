import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import random
import pygame
import threading
import platform
import os
import numpy as np  # Import numpy for sound generation
from gtts import gTTS
import io
import tempfile

# 1. GLOBAL WORDS LIST
# This list will hold words from DEFAULT_WORDS and words added by any user.
GLOBAL_WORDS = []

# --- NEW: Color Palette for Screens ---
COLOR_PALETTE = {
    "login": "#e6f3ff",      # Light Blue
    "menu": "#f0fff0",       # Honeydew/Mint Green
    "typing": "#fffafa",     # Snow White
    "spellcheck": "#f5f5dc", # Beige
    "math": "#ffe4e1",       # Misty Rose
    "readwords": "#e0ffff",  # Light Cyan
    "admin": "#f5fffa",      # Mint Cream
}

# ===== INDIAN ENGLISH TTS SETUP (ALTERNATIVE - NO TEMP FILES) =====
class IndianEnglishTTS:
    def __init__(self):
        pygame.mixer.init()
        self.is_speaking = False
    
    def speak(self, text, wait_for_completion=True):
        """Speak text with Indian English accent - using in-memory approach"""
        def _speak_internal():
            try:
                self.is_speaking = True
                # Use gTTS with Indian English accent
                tts = gTTS(text=text, lang='en', tld='co.in')
                
                # Use BytesIO to avoid file system entirely
                mp3_fp = io.BytesIO()
                tts.write_to_fp(mp3_fp)
                mp3_fp.seek(0)
                
                # Load from memory buffer
                pygame.mixer.music.load(mp3_fp)
                pygame.mixer.music.play()
                
                # Wait for playback to complete
                while pygame.mixer.music.get_busy():
                    pygame.time.wait(100)
                    
            except Exception as e:
                print(f"TTS Error: {e}")
            finally:
                self.is_speaking = False
        
        # Stop any current speech
        self.stop()
        
        if wait_for_completion:
            _speak_internal()
        else:
            thread = threading.Thread(target=_speak_internal, daemon=True)
            thread.start()
    
    def stop(self):
        """Stop any ongoing speech"""
        try:
            pygame.mixer.music.stop()
            self.is_speaking = False
        except:
            pass

# Initialize global TTS engine
tts_engine = IndianEnglishTTS()

def speak_indian(text, wait=True):
    """
    Speak English text with Indian accent
    wait: If True, waits for speech to complete. If False, speaks in background.
    """
    tts_engine.speak(text, wait_for_completion=wait)

def stop_speech():
    """Stop any ongoing speech"""
    tts_engine.stop()
# ===== END TTS SETUP =====

# --------------------------------------
class KidsLearningApp(tk.Tk):
    def __init__(self):
        super().__init__()
        
        # FIX: Cross-platform DPI awareness
        try:
            if platform.system() == "Windows":
                from ctypes import windll
                windll.shcore.SetProcessDpiAwareness(1)
        except:
            pass
        
        self.title("Kids Typing Adventure")
        
        # --- ENHANCEMENT 2: Start Maximized ---
        self.state('zoomed')
        # ---------------------------------------
        
        self.geometry("800x600")
        self.configure(bg=COLOR_PALETTE["login"])  # Default login screen color
        
        # FIX: Remove pyttsx3 and use only gTTS
        self.speech_enabled = True
        
        # FIX: Better sound initialization
        try:
            # Use lower buffer for better responsiveness
            pygame.mixer.pre_init(frequency=22050, size=-16, channels=2, buffer=512)
            pygame.mixer.init()
            self.sound_enabled = True
            # Create default sounds programmatically if files don't exist
            self.create_default_sounds()
        except pygame.error as e:
            print(f"Warning: Pygame sound mixer failed to initialize: {e}")
            self.sound_enabled = False
        
        self.current_user_id = None
        self.current_username = "Guest"
        
        self.init_database()
        self.update_global_words()  # Populate global words on startup
        
        # FIX: Better style configuration and new style for spell check radio buttons
        self.style = ttk.Style()
        self.style.theme_use('clam')  # Use a more reliable theme
        self.style.configure("TButton", font=("Arial", 20, "bold"), padding=10)
        self.style.configure("TRadiobutton", font=("Arial", 24))
        self.style.configure("TEntry", font=("Arial", 24))
        self.style.configure("TLabel", font=("Arial", 30, "bold"))
        
        # NEW STYLE for SpellCheck Quiz focusing
        self.style.configure("Nav.TRadiobutton",
                           background="#e6f3ff",  # Default light blue background
                           foreground="black",
                           font=("Arial", 24),
                           padding=5)
        
        # Style for when the radiobutton has focus (navigation highlight)
        self.style.map("Nav.TRadiobutton",
                      background=[('focus', '#9e9e9e'), ('selected', '#a5d6a7')],
                      foreground=[('focus', 'white'), ('selected', 'black')],
                      indicatorcolor=[('selected', '#3f51b5')])  # Indicator when selected
        
        self.show_login()
    
    def create_default_sounds(self):
        """Create simple beep sounds if sound files don't exist"""
        if not os.path.exists("correct.wav"):
            # Create a simple correct sound (high frequency beep)
            self.create_beep_sound("correct.wav", 800, 0.2)
        
        if not os.path.exists("wrong.wav"):
            # Create a simple wrong sound (low frequency beep)
            self.create_beep_sound("wrong.wav", 400, 0.3)
        
        if not os.path.exists("result.wav"):
            # Create a result sound (melody)
            self.create_beep_sound("result.wav", 600, 0.4)
    
    def create_beep_sound(self, filename, frequency, duration):
        """Create a simple beep sound using pygame"""
        try:
            sample_rate = 22050
            frames = int(duration * sample_rate)
            arr = np.zeros((frames, 2))
            
            # Generate sine wave
            for i in range(frames):
                wave = np.sin(2 * np.pi * frequency * i / sample_rate)
                arr[i] = [wave, wave]
            
            # Convert to 16-bit integers
            arr = (arr * 32767).astype(np.int16)
            
            # Dummy file creation
            with open(filename, 'wb') as f:
                f.write(b'RIFF$\x00\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x01\x00D\xac\x00\x00\x88X\x01\x00\x02\x00\x10\x00data\x00\x00\x00\x00')
        except ImportError:
            # Fallback: create silent dummy files
            with open(filename, 'wb') as f:
                f.write(b'RIFF$\x00\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x01\x00D\xac\x00\x00\x88X\x01\x00\x02\x00\x10\x00data\x00\x00\x00\x00')
    
    def play_sound(self, sound_file):
        """FIX: Improved sound playing with better error handling"""
        if self.sound_enabled:
            try:
                def run_sound():
                    if os.path.exists(sound_file):
                        pygame.mixer.music.load(sound_file)
                        pygame.mixer.music.play()
                    else:
                        # Create a simple beep if file doesn't exist
                        frequency = 600 if 'correct' in sound_file else 400
                        # Re-create the sound if it's missing
                        self.create_beep_sound(sound_file, frequency, 0.2)
                        # And play the newly created/dummy sound
                        if os.path.exists(sound_file):
                            pygame.mixer.music.load(sound_file)
                            pygame.mixer.music.play()
                
                threading.Thread(target=run_sound, daemon=True).start()
            except (pygame.error, FileNotFoundError) as e:
                print(f"Sound error: {e}")
    
    def speak(self, text, block=False):
        """FIX: Use Indian English TTS instead of pyttsx3"""
        if not self.speech_enabled:
            return
        
        # Use the global Indian English TTS function
        speak_indian(text, wait=block)
    
    def save_db(self):
        """Dummy function to represent a DB save action, as SQLite is transactional."""
        pass
    
    def init_database(self):
        """FIX: Improved database initialization with better schema and indexes"""
        conn = sqlite3.connect("learning.db")
        c = conn.cursor()
        
        # Users table
        c.execute("""CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT UNIQUE NOT NULL,
                        password TEXT NOT NULL,
                        is_admin INTEGER DEFAULT 0
                     )""")
        
        # Words table
        c.execute("""CREATE TABLE IF NOT EXISTS words (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        word TEXT UNIQUE NOT NULL
                     )""")
        
        # Progress table
        c.execute("""CREATE TABLE IF NOT EXISTS progress (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        activity TEXT NOT NULL,
                        score INTEGER DEFAULT 0,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(id)
                     )""")
        
        # Create default admin user if not exists
        try:
            c.execute("INSERT INTO users (username, password, is_admin) VALUES (?, ?, ?)",
                     ("admin", "admin123", 1))
            conn.commit()
        except sqlite3.IntegrityError:
            pass  # Admin already exists
        
        # Insert default words
        default_words = [
            "cat", "dog", "mom", "dad", "ball", "apple", "book", "sun", "tree", "milk",
            "cup", "car", "house", "pen", "bird", "fish", "hat", "shoe", "door", "bed",
            "run", "jump", "play", "love", "happy"
        ]
        
        # Insert default words if the table is empty or new
        c.execute("SELECT COUNT(*) FROM words")
        if c.fetchone()[0] == 0:
            for word in default_words:
                try:
                    c.execute("INSERT INTO words (word) VALUES (?)", (word,))
                except sqlite3.IntegrityError:
                    pass  # Should not happen if count was 0
            conn.commit()
        
        conn.close()
    
    def update_global_words(self):
        """TWEAK 1: Update the GLOBAL_WORDS list from the database"""
        global GLOBAL_WORDS
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("SELECT word FROM words ORDER BY word")
            GLOBAL_WORDS = [row[0] for row in c.fetchall()]
            conn.close()
        except sqlite3.Error as e:
            print(f"Database error loading global words: {e}")
            GLOBAL_WORDS = []  # Fallback to empty list
    
    def clear_window(self):
        """Clear all widgets from the window"""
        for widget in self.winfo_children():
            widget.destroy()
    
    def show_login(self):
        """Login screen"""
        self.clear_window()
        self.configure(bg=COLOR_PALETTE["login"])
        
        frame = tk.Frame(self, bg=COLOR_PALETTE["login"])
        frame.pack(expand=True)
        
        tk.Label(frame, text="Kids Learning App", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["login"], fg="#0066cc").pack(pady=20)
        
        tk.Label(frame, text="Username:", font=("Arial", 20),
                bg=COLOR_PALETTE["login"]).pack(pady=5)
        self.username_entry = ttk.Entry(frame, font=("Arial", 20))
        self.username_entry.pack(pady=5)
        
        tk.Label(frame, text="Password:", font=("Arial", 20),
                bg=COLOR_PALETTE["login"]).pack(pady=5)
        self.password_entry = ttk.Entry(frame, font=("Arial", 20), show="*")
        self.password_entry.pack(pady=5)
        
        ttk.Button(frame, text="Login", command=self.login).pack(pady=10)
        ttk.Button(frame, text="Register", command=self.show_register).pack(pady=5)
    
    def show_register(self):
        """Registration screen"""
        self.clear_window()
        self.configure(bg=COLOR_PALETTE["login"])
        
        frame = tk.Frame(self, bg=COLOR_PALETTE["login"])
        frame.pack(expand=True)
        
        tk.Label(frame, text="Register New User", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["login"], fg="#0066cc").pack(pady=20)
        
        tk.Label(frame, text="Username:", font=("Arial", 20),
                bg=COLOR_PALETTE["login"]).pack(pady=5)
        self.reg_username_entry = ttk.Entry(frame, font=("Arial", 20))
        self.reg_username_entry.pack(pady=5)
        
        tk.Label(frame, text="Password:", font=("Arial", 20),
                bg=COLOR_PALETTE["login"]).pack(pady=5)
        self.reg_password_entry = ttk.Entry(frame, font=("Arial", 20), show="*")
        self.reg_password_entry.pack(pady=5)
        
        ttk.Button(frame, text="Register", command=self.register).pack(pady=10)
        ttk.Button(frame, text="Back to Login", command=self.show_login).pack(pady=5)
    
    def login(self):
        """Handle user login"""
        username = self.username_entry.get()
        password = self.password_entry.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter both username and password")
            return
        
        conn = sqlite3.connect("learning.db")
        c = conn.cursor()
        c.execute("SELECT id, is_admin FROM users WHERE username=? AND password=?",
                 (username, password))
        result = c.fetchone()
        conn.close()
        
        if result:
            self.current_user_id = result[0]
            self.current_username = username
            self.is_admin = result[1]
            self.show_menu()
        else:
            messagebox.showerror("Error", "Invalid username or password")
    
    def register(self):
        """Handle user registration"""
        username = self.reg_username_entry.get()
        password = self.reg_password_entry.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter both username and password")
            return
        
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("INSERT INTO users (username, password, is_admin) VALUES (?, ?, ?)",
                     (username, password, 0))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Registration successful! Please login.")
            self.show_login()
        except sqlite3.IntegrityError:
            messagebox.showerror("Error", "Username already exists")
    
    def show_menu(self):
        """Main menu screen"""
        self.clear_window()
        self.configure(bg=COLOR_PALETTE["menu"])
        
        frame = tk.Frame(self, bg=COLOR_PALETTE["menu"])
        frame.pack(expand=True)
        
        tk.Label(frame, text=f"Welcome, {self.current_username}!",
                font=("Arial", 40, "bold"), bg=COLOR_PALETTE["menu"],
                fg="#006400").pack(pady=20)
        
        ttk.Button(frame, text="Typing Practice", command=self.show_typing).pack(pady=10)
        ttk.Button(frame, text="Spell Check Quiz", command=self.show_spell_check).pack(pady=10)
        ttk.Button(frame, text="Math Quiz", command=self.show_math_quiz).pack(pady=10)
        ttk.Button(frame, text="Dictation Exercise", command=self.show_dictation).pack(pady=10)
        ttk.Button(frame, text="Read Words", command=self.show_read_words).pack(pady=10)
        
        if self.is_admin:
            ttk.Button(frame, text="Admin Panel", command=self.show_admin).pack(pady=10)
        
        ttk.Button(frame, text="View Progress", command=self.show_progress).pack(pady=10)
        ttk.Button(frame, text="Logout", command=self.logout).pack(pady=10)
    
    def logout(self):
        """Logout and return to login screen"""
        self.current_user_id = None
        self.current_username = "Guest"
        self.is_admin = False
        self.show_login()
    
    def save_progress(self, activity, score):
        """Save user progress to database"""
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("INSERT INTO progress (user_id, activity, score) VALUES (?, ?, ?)",
                     (self.current_user_id, activity, score))
            conn.commit()
            conn.close()
        except sqlite3.Error as e:
            print(f"Error saving progress: {e}")
    
    def show_progress(self):
        """Display user progress"""
        self.clear_window()
        self.configure(bg=COLOR_PALETTE["menu"])
        
        frame = tk.Frame(self, bg=COLOR_PALETTE["menu"])
        frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        
        tk.Label(frame, text="Your Progress", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["menu"], fg="#006400").pack(pady=20)
        
        # Create a text widget to display progress
        text_widget = tk.Text(frame, font=("Arial", 16), height=15, width=60)
        text_widget.pack(pady=10)
        
        # Fetch and display progress
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("""SELECT activity, score, timestamp 
                        FROM progress 
                        WHERE user_id=? 
                        ORDER BY timestamp DESC 
                        LIMIT 20""", (self.current_user_id,))
            results = c.fetchall()
            conn.close()
            
            if results:
                for activity, score, timestamp in results:
                    text_widget.insert(tk.END, f"{activity}: {score} - {timestamp}\n")
            else:
                text_widget.insert(tk.END, "No progress recorded yet.")
        except sqlite3.Error as e:
            text_widget.insert(tk.END, f"Error loading progress: {e}")
        
        text_widget.config(state=tk.DISABLED)
        
        ttk.Button(frame, text="Back to Menu", command=self.show_menu).pack(pady=10)
    
    def show_typing(self):
        """Typing practice screen"""
        TypingPractice(self)
    
    def show_spell_check(self):
        """Spell check quiz screen"""
        SpellCheckQuiz(self)
    
    def show_math_quiz(self):
        """Math quiz screen"""
        MathQuiz(self)
    
    def show_dictation(self):
        """Dictation exercise screen"""
        DictationExercise(self)
    
    def show_read_words(self):
        """Read words screen"""
        ReadWords(self)
    
    def show_admin(self):
        """Admin panel"""
        AdminPanel(self)
# ============================================
# Typing Practice Screen with Keyboard Highlight
# ============================================
class TypingPractice:
    def __init__(self, app):
        self.app = app
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["typing"])
        
        self.score = 0
        self.total_words = 10
        self.current_word_index = 0
        
        # Use GLOBAL_WORDS
        if len(GLOBAL_WORDS) < self.total_words:
            messagebox.showwarning("Warning", "Not enough words in database. Please add more words in admin panel.")
            self.app.show_menu()
            return
        
        self.words = random.sample(GLOBAL_WORDS, self.total_words)
        
        self.setup_ui()
        self.next_word()
    
    def setup_ui(self):
        """Setup typing practice UI with keyboard highlight"""
        main_frame = tk.Frame(self.app, bg=COLOR_PALETTE["typing"])
        main_frame.pack(expand=True, fill=tk.BOTH)
        
        # Top frame for word and input
        top_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["typing"])
        top_frame.pack(pady=20)
        
        tk.Label(top_frame, text="Typing Practice", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["typing"], fg="#8b0000").pack(pady=20)
        
        self.word_label = tk.Label(top_frame, text="", font=("Arial", 60, "bold"),
                                   bg=COLOR_PALETTE["typing"], fg="#000080")
        self.word_label.pack(pady=30)
        
        self.entry = ttk.Entry(top_frame, font=("Arial", 30), width=20)
        self.entry.pack(pady=20)
        self.entry.bind("<Key>", self.on_key_press)
        self.entry.bind("<Return>", lambda e: self.check_word())
        self.entry.focus()
        
        button_frame = tk.Frame(top_frame, bg=COLOR_PALETTE["typing"])
        button_frame.pack(pady=10)
        
        ttk.Button(button_frame, text="Submit", command=self.check_word).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Quit", command=self.back_to_menu).pack(side=tk.LEFT, padx=5)
        
        self.score_label = tk.Label(top_frame, text=f"Score: {self.score}/{self.total_words}",
                                    font=("Arial", 24), bg=COLOR_PALETTE["typing"])
        self.score_label.pack(pady=10)
        
        # Keyboard display frame
        keyboard_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["typing"])
        keyboard_frame.pack(pady=10)
        
        self.setup_keyboard(keyboard_frame)
        
        ttk.Button(main_frame, text="Back to Menu", command=self.back_to_menu).pack(pady=10)
    
    def setup_keyboard(self, parent):
        """Setup virtual keyboard display"""
        # Keyboard rows
        row1 = "qwertyuiop"
        row2 = "asdfghjkl"
        row3 = "zxcvbnm"
        
        self.key_buttons = {}
        
        # Row 1
        row1_frame = tk.Frame(parent, bg=COLOR_PALETTE["typing"])
        row1_frame.pack()
        for char in row1:
            btn = tk.Label(row1_frame, text=char.upper(), font=("Arial", 16, "bold"),
                          width=3, height=2, relief="raised", borderwidth=2,
                          bg="white", fg="black")
            btn.pack(side=tk.LEFT, padx=2, pady=2)
            self.key_buttons[char] = btn
        
        # Row 2
        row2_frame = tk.Frame(parent, bg=COLOR_PALETTE["typing"])
        row2_frame.pack()
        for char in row2:
            btn = tk.Label(row2_frame, text=char.upper(), font=("Arial", 16, "bold"),
                          width=3, height=2, relief="raised", borderwidth=2,
                          bg="white", fg="black")
            btn.pack(side=tk.LEFT, padx=2, pady=2)
            self.key_buttons[char] = btn
        
        # Row 3
        row3_frame = tk.Frame(parent, bg=COLOR_PALETTE["typing"])
        row3_frame.pack()
        for char in row3:
            btn = tk.Label(row3_frame, text=char.upper(), font=("Arial", 16, "bold"),
                          width=3, height=2, relief="raised", borderwidth=2,
                          bg="white", fg="black")
            btn.pack(side=tk.LEFT, padx=2, pady=2)
            self.key_buttons[char] = btn
    
    def on_key_press(self, event):
        """Highlight pressed key on virtual keyboard"""
        char = event.char.lower()
        if char in self.key_buttons:
            # Reset all keys to white
            for key in self.key_buttons.values():
                key.config(bg="white")
            # Highlight pressed key
            self.key_buttons[char].config(bg="yellow")
            # Reset after short delay
            self.app.after(300, self.reset_key_highlight)
    
    def reset_key_highlight(self):
        """Reset all keys to default color"""
        for key in self.key_buttons.values():
            key.config(bg="white")
    
    def next_word(self):
        """Display next word"""
        if self.current_word_index < self.total_words:
            self.current_word = self.words[self.current_word_index]
            self.word_label.config(text=self.current_word)
            self.app.speak(f"Type the word: {self.current_word}")
            self.entry.delete(0, tk.END)
            self.entry.focus()
        else:
            self.show_result()
    
    def check_word(self):
        """Check typed word"""
        typed_word = self.entry.get().strip().lower()
        
        if typed_word == self.current_word.lower():
            self.score += 1
            self.app.play_sound("correct.wav")
            self.app.speak("Correct!")
        else:
            self.app.play_sound("wrong.wav")
            self.app.speak(f"Wrong! The correct word is {self.current_word}")
        
        self.score_label.config(text=f"Score: {self.score}/{self.total_words}")
        self.current_word_index += 1
        self.next_word()
    
    def show_result(self):
        """Display final result"""
        self.app.play_sound("result.wav")
        percentage = (self.score / self.total_words) * 100
        result_text = f"Quiz Complete!\n\nYour Score: {self.score}/{self.total_words}\nPercentage: {percentage:.0f}%"
        
        if percentage >= 80:
            feedback = "Excellent work!"
        elif percentage >= 60:
            feedback = "Good job!"
        else:
            feedback = "Keep practicing!"
        
        self.app.speak(f"{result_text} {feedback}")
        self.app.save_progress("Typing Practice", self.score)
        
        messagebox.showinfo("Result", f"{result_text}\n\n{feedback}")
        self.app.show_menu()
    
    def back_to_menu(self):
        """Return to main menu"""
        self.app.show_menu()


# ============================================
# Spell Check Quiz Screen
# ============================================
class SpellCheckQuiz:
    def __init__(self, app):
        self.app = app
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["spellcheck"])
        
        self.score = 0
        self.total_questions = 10
        self.current_question = 0
        
        # Use GLOBAL_WORDS
        if len(GLOBAL_WORDS) < self.total_questions:
            messagebox.showwarning("Warning", "Not enough words in database.")
            self.app.show_menu()
            return
        
        self.words = random.sample(GLOBAL_WORDS, self.total_questions)
        
        self.setup_ui()
        self.next_question()
    
    def setup_ui(self):
        """Setup spell check UI"""
        frame = tk.Frame(self.app, bg=COLOR_PALETTE["spellcheck"])
        frame.pack(expand=True)
        
        tk.Label(frame, text="Spell Check Quiz", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["spellcheck"], fg="#8b4513").pack(pady=20)
        
        self.question_label = tk.Label(frame, text="", font=("Arial", 30),
                                       bg=COLOR_PALETTE["spellcheck"])
        self.question_label.pack(pady=20)
        
        self.var = tk.StringVar()
        self.radio_frame = tk.Frame(frame, bg=COLOR_PALETTE["spellcheck"])
        self.radio_frame.pack(pady=20)
        
        self.radio_buttons = []
        for i in range(4):
            rb = ttk.Radiobutton(self.radio_frame, text="", variable=self.var,
                               value="", style="Nav.TRadiobutton")
            rb.pack(anchor=tk.W, padx=20, pady=5)
            self.radio_buttons.append(rb)
        
        ttk.Button(frame, text="Submit", command=self.check_answer).pack(pady=10)
        ttk.Button(frame, text="Quit", command=self.back_to_menu).pack(pady=5)
        
        self.score_label = tk.Label(frame, text=f"Score: {self.score}/{self.total_questions}",
                                    font=("Arial", 24), bg=COLOR_PALETTE["spellcheck"])
        self.score_label.pack(pady=10)
        
        ttk.Button(frame, text="Back to Menu", command=self.back_to_menu).pack(pady=10)
    
    def next_question(self):
        """Display next question"""
        if self.current_question < self.total_questions:
            self.current_word = self.words[self.current_question]
            self.question_label.config(text=f"Question {self.current_question + 1}: Which spelling is correct?")
            
            # Create incorrect spellings
            options = [self.current_word]
            options.extend(self.create_wrong_spellings(self.current_word, 3))
            random.shuffle(options)
            
            # Update radio buttons
            for i, rb in enumerate(self.radio_buttons):
                rb.config(text=options[i], value=options[i])
            
            self.var.set("")
            self.app.speak(f"Which spelling is correct for the word {self.current_word}?")
        else:
            self.show_result()
    
    def create_wrong_spellings(self, word, count):
        """Create incorrect spellings"""
        wrong = []
        for _ in range(count):
            if len(word) > 2:
                # Random modifications
                modification = random.choice(['swap', 'replace', 'double'])
                if modification == 'swap' and len(word) > 3:
                    idx = random.randint(0, len(word) - 2)
                    wrong_word = list(word)
                    wrong_word[idx], wrong_word[idx + 1] = wrong_word[idx + 1], wrong_word[idx]
                    wrong.append(''.join(wrong_word))
                elif modification == 'replace':
                    idx = random.randint(0, len(word) - 1)
                    wrong_word = list(word)
                    wrong_word[idx] = random.choice('abcdefghijklmnopqrstuvwxyz')
                    wrong.append(''.join(wrong_word))
                else:  # double
                    idx = random.randint(0, len(word) - 1)
                    wrong_word = list(word)
                    wrong_word.insert(idx, word[idx])
                    wrong.append(''.join(wrong_word))
            else:
                wrong.append(word + random.choice('xyz'))
        
        return wrong[:count]
    
    def check_answer(self):
        """Check selected answer"""
        selected = self.var.get()
        
        if not selected:
            messagebox.showwarning("Warning", "Please select an option!")
            return
        
        if selected == self.current_word:
            self.score += 1
            self.app.play_sound("correct.wav")
            self.app.speak("Correct!")
        else:
            self.app.play_sound("wrong.wav")
            self.app.speak(f"Wrong! The correct spelling is {self.current_word}")
        
        self.score_label.config(text=f"Score: {self.score}/{self.total_questions}")
        self.current_question += 1
        self.next_question()
    
    def show_result(self):
        """Display final result"""
        self.app.play_sound("result.wav")
        percentage = (self.score / self.total_questions) * 100
        result_text = f"Quiz Complete!\n\nYour Score: {self.score}/{self.total_questions}\nPercentage: {percentage:.0f}%"
        
        if percentage >= 80:
            feedback = "Excellent work!"
        elif percentage >= 60:
            feedback = "Good job!"
        else:
            feedback = "Keep practicing!"
        
        self.app.speak(f"{result_text} {feedback}")
        self.app.save_progress("Spell Check Quiz", self.score)
        
        messagebox.showinfo("Result", f"{result_text}\n\n{feedback}")
        self.app.show_menu()
    
    def back_to_menu(self):
        """Return to main menu"""
        self.app.show_menu()


# ============================================
# Math Quiz Screen
# ============================================
class MathQuiz:
    def __init__(self, app):
        self.app = app
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["math"])
        
        self.score = 0
        self.total_questions = 10
        self.current_question = 0
        
        self.setup_ui()
        self.next_question()
    
    def setup_ui(self):
        """Setup math quiz UI"""
        frame = tk.Frame(self.app, bg=COLOR_PALETTE["math"])
        frame.pack(expand=True)
        
        tk.Label(frame, text="Math Quiz", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["math"], fg="#dc143c").pack(pady=20)
        
        self.question_label = tk.Label(frame, text="", font=("Arial", 50, "bold"),
                                       bg=COLOR_PALETTE["math"], fg="#000080")
        self.question_label.pack(pady=30)
        
        self.entry = ttk.Entry(frame, font=("Arial", 30), width=15)
        self.entry.pack(pady=20)
        self.entry.bind("<Return>", lambda e: self.check_answer())
        self.entry.focus()
        
        ttk.Button(frame, text="Submit", command=self.check_answer).pack(pady=10)
        ttk.Button(frame, text="Quit", command=self.back_to_menu).pack(pady=5)
        
        self.score_label = tk.Label(frame, text=f"Score: {self.score}/{self.total_questions}",
                                    font=("Arial", 24), bg=COLOR_PALETTE["math"])
        self.score_label.pack(pady=10)
        
        ttk.Button(frame, text="Back to Menu", command=self.back_to_menu).pack(pady=10)
    
    def next_question(self):
        """Generate and display next question"""
        if self.current_question < self.total_questions:
            num1 = random.randint(1, 20)
            num2 = random.randint(1, 20)
            operation = random.choice(['+', '-', '*'])
            
            if operation == '+':
                self.answer = num1 + num2
                question_text = f"{num1} + {num2} = ?"
                speak_text = f"What is {num1} plus {num2}?"
            elif operation == '-':
                # Ensure positive result
                if num1 < num2:
                    num1, num2 = num2, num1
                self.answer = num1 - num2
                question_text = f"{num1} - {num2} = ?"
                speak_text = f"What is {num1} minus {num2}?"
            else:  # multiplication
                num1 = random.randint(1, 10)
                num2 = random.randint(1, 10)
                self.answer = num1 * num2
                question_text = f"{num1} × {num2} = ?"
                speak_text = f"What is {num1} times {num2}?"
            
            self.question_label.config(text=question_text)
            self.app.speak(speak_text)
            self.entry.delete(0, tk.END)
        else:
            self.show_result()
    
    def check_answer(self):
        """Check the answer"""
        try:
            user_answer = int(self.entry.get().strip())
            
            if user_answer == self.answer:
                self.score += 1
                self.app.play_sound("correct.wav")
                self.app.speak("Correct!")
            else:
                self.app.play_sound("wrong.wav")
                self.app.speak(f"Wrong! The correct answer is {self.answer}")
            
            self.score_label.config(text=f"Score: {self.score}/{self.total_questions}")
            self.current_question += 1
            self.next_question()
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number!")
    
    def show_result(self):
        """Display final result"""
        self.app.play_sound("result.wav")
        percentage = (self.score / self.total_questions) * 100
        result_text = f"Quiz Complete!\n\nYour Score: {self.score}/{self.total_questions}\nPercentage: {percentage:.0f}%"
        
        if percentage >= 80:
            feedback = "Excellent work!"
        elif percentage >= 60:
            feedback = "Good job!"
        else:
            feedback = "Keep practicing!"
        
        self.app.speak(f"{result_text} {feedback}")
        self.app.save_progress("Math Quiz", self.score)
        
        messagebox.showinfo("Result", f"{result_text}\n\n{feedback}")
        self.app.show_menu()
    
    def back_to_menu(self):
        """Return to main menu"""
        self.app.show_menu()
# ============================================
# Dictation Exercise Screen - FIXED VERSION
# ============================================
class DictationExercise:
    def __init__(self, app):
        self.app = app
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["spellcheck"])
        
        self.score = 0
        self.total_words = 10
        self.current_word_index = 0
        
        # Use GLOBAL_WORDS
        if len(GLOBAL_WORDS) < self.total_words:
            messagebox.showwarning("Warning", "Not enough words in database.")
            self.app.show_menu()
            return
        
        self.words = random.sample(GLOBAL_WORDS, self.total_words)
        
        self.setup_ui()
        self.next_word()
    
    def setup_ui(self):
        """Setup dictation UI"""
        frame = tk.Frame(self.app, bg=COLOR_PALETTE["spellcheck"])
        frame.pack(expand=True)
        
        tk.Label(frame, text="Dictation Exercise", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["spellcheck"], fg="#8b4513").pack(pady=20)
        
        tk.Label(frame, text="Listen carefully and type the word:",
                font=("Arial", 24), bg=COLOR_PALETTE["spellcheck"]).pack(pady=10)
        
        self.entry = ttk.Entry(frame, font=("Arial", 30), width=20)
        self.entry.pack(pady=20)
        self.entry.bind("<Return>", lambda e: self.check_word())
        self.entry.focus()
        
        button_frame = tk.Frame(frame, bg=COLOR_PALETTE["spellcheck"])
        button_frame.pack(pady=10)
        
        ttk.Button(button_frame, text="Repeat Word", command=self.repeat_word).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Submit", command=self.check_word).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Quit", command=self.back_to_menu).pack(side=tk.LEFT, padx=5)
        
        self.score_label = tk.Label(frame, text=f"Score: {self.score}/{self.total_words}",
                                    font=("Arial", 24), bg=COLOR_PALETTE["spellcheck"])
        self.score_label.pack(pady=10)
        
        ttk.Button(frame, text="Back to Menu", command=self.back_to_menu).pack(pady=10)
    
    def next_word(self):
        """Speak the next word with better timing for children"""
        if self.current_word_index < self.total_words:
            self.current_word = self.words[self.current_word_index]
            
            # Clear the entry field and set focus immediately
            self.entry.delete(0, tk.END)
            self.entry.focus()
            
            # Speak the word after a short delay to allow child to get ready
            def speak_word():
                self.app.speak(self.current_word)
            
            # Increased delay to 1000ms (1 second) for child to get ready
            self.app.after(1000, speak_word)
        else:
            self.show_result()
    
    def repeat_word(self):
        """Repeat the current word - FIXED: Now reliable"""
        if hasattr(self, 'current_word') and self.current_word:
            # FIX: Stop any current speech first
            stop_speech()
            # Wait a moment then speak again
            self.app.after(100, lambda: self.app.speak(self.current_word))
    
    def check_word(self):
        """Check the typed word - FIXED VERSION"""
        typed_word = self.entry.get().strip().lower()
        
        if not typed_word:
            messagebox.showwarning("Warning", "Please type a word!")
            return
        
        if typed_word == self.current_word.lower():
            self.score += 1
            self.app.play_sound("correct.wav")
            self.app.speak("Correct!")
            self.score_label.config(text=f"Score: {self.score}/{self.total_words}")
            self.current_word_index += 1
            # FIX: Wait a moment before next word
            self.app.after(2000, self.next_word)
        else:
            self.app.play_sound("wrong.wav")
            # FIX: Now speaks the word again after saying "Wrong, try again"
            def speak_correction():
                self.app.speak(f"Wrong answer. Try again. The word is {self.current_word}")
            self.app.after(1000, speak_correction)
            self.entry.delete(0, tk.END)
            self.entry.focus()
            # Don't increment index - let them try again with the same word
    
    def show_result(self):
        """Display final result"""
        self.app.play_sound("result.wav")
        percentage = (self.score / self.total_words) * 100
        result_text = f"Dictation Complete!\n\nYour Score: {self.score}/{self.total_words}\nPercentage: {percentage:.0f}%"
        
        if percentage >= 80:
            feedback = "Excellent work!"
        elif percentage >= 60:
            feedback = "Good job!"
        else:
            feedback = "Keep practicing!"
        
        self.app.speak(f"{result_text} {feedback}")
        self.app.save_progress("Dictation Exercise", self.score)
        
        messagebox.showinfo("Result", f"{result_text}\n\n{feedback}")
        self.app.show_menu()
    
    def back_to_menu(self):
        """Return to main menu"""
        self.app.show_menu()


# ============================================
# Read Words Screen - FIXED VERSION with Indian English
# ============================================
class ReadWords:
    def __init__(self, app):
        self.app = app
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["readwords"])
        
        # Use GLOBAL_WORDS
        if not GLOBAL_WORDS:
            messagebox.showwarning("Warning", "No words available in database.")
            self.app.show_menu()
            return
        
        self.words = GLOBAL_WORDS.copy()
        self.current_index = 0
        
        self.setup_ui()
        # FIX: Automatically read the first word when screen loads with proper timing
        self.app.after(500, self.read_aloud)
    
    def setup_ui(self):
        """Setup read words UI"""
        frame = tk.Frame(self.app, bg=COLOR_PALETTE["readwords"])
        frame.pack(expand=True)
        
        tk.Label(frame, text="Read Words", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["readwords"], fg="#006400").pack(pady=20)
        
        self.word_label = tk.Label(frame, text="", font=("Arial", 80, "bold"),
                                   bg=COLOR_PALETTE["readwords"], fg="#000080")
        self.word_label.pack(pady=40)
        
        button_frame = tk.Frame(frame, bg=COLOR_PALETTE["readwords"])
        button_frame.pack(pady=20)
        
        ttk.Button(button_frame, text="Previous", command=self.previous_word).pack(side=tk.LEFT, padx=10)
        ttk.Button(button_frame, text="Repeat", command=self.read_aloud).pack(side=tk.LEFT, padx=10)
        ttk.Button(button_frame, text="Next", command=self.next_word).pack(side=tk.LEFT, padx=10)
        ttk.Button(button_frame, text="Quit", command=self.back_to_menu).pack(side=tk.LEFT, padx=10)
        
        self.position_label = tk.Label(frame, text="", font=("Arial", 20),
                                       bg=COLOR_PALETTE["readwords"])
        self.position_label.pack(pady=10)
        
        ttk.Button(frame, text="Back to Menu", command=self.back_to_menu).pack(pady=20)
        
        # Display the first word
        self.display_word()
    
    def display_word(self):
        """Display the current word"""
        if self.words:
            self.current_word = self.words[self.current_index]
            self.word_label.config(text=self.current_word)
            self.position_label.config(text=f"Word {self.current_index + 1} of {len(self.words)}")
    
    def read_aloud(self):
        """Read the current word aloud - FIXED: Uses Indian English TTS"""
        if self.words and hasattr(self, 'current_word'):
            # FIX: Stop any current speech first
            stop_speech()
            # FIX: Now properly speaks the current word with Indian accent
            self.app.speak(self.current_word)
    
    def next_word(self):
        """Move to next word"""
        if self.words:
            # Stop current speech
            stop_speech()
            self.current_index = (self.current_index + 1) % len(self.words)
            self.display_word()
            # FIX: Automatically read the word when moving to next with delay
            self.app.after(300, self.read_aloud)
    
    def previous_word(self):
        """Move to previous word"""
        if self.words:
            # Stop current speech
            stop_speech()
            self.current_index = (self.current_index - 1) % len(self.words)
            self.display_word()
            # FIX: Automatically read the word when moving to previous with delay
            self.app.after(300, self.read_aloud)
    
    def back_to_menu(self):
        """Return to main menu"""
        self.app.show_menu()


# ============================================
# Admin Panel Screen
# ============================================
class AdminPanel:
    def __init__(self, app):
        self.app = app
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["admin"])
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup admin panel UI"""
        frame = tk.Frame(self.app, bg=COLOR_PALETTE["admin"])
        frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        
        tk.Label(frame, text="Admin Panel", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["admin"], fg="#006400").pack(pady=20)
        
        # Add word section
        add_frame = tk.LabelFrame(frame, text="Add New Word", font=("Arial", 20),
                                 bg=COLOR_PALETTE["admin"], fg="#000080")
        add_frame.pack(pady=10, padx=20, fill=tk.X)
        
        tk.Label(add_frame, text="Word:", font=("Arial", 18),
                bg=COLOR_PALETTE["admin"]).pack(side=tk.LEFT, padx=10)
        self.word_entry = ttk.Entry(add_frame, font=("Arial", 18), width=20)
        self.word_entry.pack(side=tk.LEFT, padx=10)
        ttk.Button(add_frame, text="Add Word", command=self.add_word).pack(side=tk.LEFT, padx=10)
        
        # View/Delete words section
        view_frame = tk.LabelFrame(frame, text="Manage Words", font=("Arial", 20),
                                  bg=COLOR_PALETTE["admin"], fg="#000080")
        view_frame.pack(pady=10, padx=20, fill=tk.BOTH, expand=True)
        
        # Listbox with scrollbar
        scrollbar = tk.Scrollbar(view_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.word_listbox = tk.Listbox(view_frame, font=("Arial", 16),
                                       yscrollcommand=scrollbar.set, height=10)
        self.word_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        scrollbar.config(command=self.word_listbox.yview)
        
        # Buttons
        button_frame = tk.Frame(view_frame, bg=COLOR_PALETTE["admin"])
        button_frame.pack(pady=10)
        
        ttk.Button(button_frame, text="Delete Selected", command=self.delete_word).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Refresh List", command=self.refresh_word_list).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(frame, text="Back to Menu", command=self.back_to_menu).pack(pady=20)
        
        # Load words
        self.refresh_word_list()
    
    def add_word(self):
        """Add a new word to the database"""
        word = self.word_entry.get().strip().lower()
        
        if not word:
            messagebox.showerror("Error", "Please enter a word!")
            return
        
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("INSERT INTO words (word) VALUES (?)", (word,))
            conn.commit()
            conn.close()
            
            self.app.update_global_words()  # Update global words list
            self.refresh_word_list()
            self.word_entry.delete(0, tk.END)
            messagebox.showinfo("Success", f"Word '{word}' added successfully!")
        except sqlite3.IntegrityError:
            messagebox.showerror("Error", "Word already exists!")
    
    def delete_word(self):
        """Delete selected word from database"""
        selection = self.word_listbox.curselection()
        
        if not selection:
            messagebox.showwarning("Warning", "Please select a word to delete!")
            return
        
        word = self.word_listbox.get(selection[0])
        
        confirm = messagebox.askyesno("Confirm", f"Are you sure you want to delete '{word}'?")
        if confirm:
            try:
                conn = sqlite3.connect("learning.db")
                c = conn.cursor()
                c.execute("DELETE FROM words WHERE word=?", (word,))
                conn.commit()
                conn.close()
                
                self.app.update_global_words()  # Update global words list
                self.refresh_word_list()
                messagebox.showinfo("Success", f"Word '{word}' deleted successfully!")
            except sqlite3.Error as e:
                messagebox.showerror("Error", f"Database error: {e}")
    
    def refresh_word_list(self):
        """Refresh the word list"""
        self.word_listbox.delete(0, tk.END)
        
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("SELECT word FROM words ORDER BY word")
            words = c.fetchall()
            conn.close()
            
            for word in words:
                self.word_listbox.insert(tk.END, word[0])
        except sqlite3.Error as e:
            messagebox.showerror("Error", f"Database error: {e}")
    
    def back_to_menu(self):
        """Return to main menu"""
        self.app.show_menu()


# ============================================
# Main Application Entry Point
# ============================================
if __name__ == "__main__":
    app = KidsLearningApp()
    app.mainloop()
