# Wordfun.py
# Fun With Words — Final edition
# Version 1.0 — October 2025
# Developed by: Augustine Anbananthan
# AI Assistance: ChatGPT (OpenAI)
#
# Requirements:
#   - Python 3.11
#   - packages: pygame, gtts, numpy  (install via pip)
#   - optional sound files in same folder:
#       correct.wav  wrong.wav  success.wav  result.wav
#
# Usage:
#   py -3.11 Wordfun.py
#
# This file is designed to be self-contained and well-commented for learning.

import os
import sys
import time
import random
import threading
import tempfile
import sqlite3
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk, messagebox, filedialog, simpledialog
import pygame
import numpy as np

# Try to import gTTS; if missing, the app will inform user when TTS actions are attempted.
try:
    from gtts import gTTS
    GTTS_AVAILABLE = True
except Exception:
    GTTS_AVAILABLE = False

# ---------- Configuration ----------
APP_TITLE = "🎯 Fun With Words — WordFun"
DB_FILE = "wordfun.db"           # SQLite DB filename (in same folder)
LANG = "en"                      # gTTS language
TLD = "co.in"                    # Indian English accent
VERSION_TEXT = "Version 1.0 — October 2025"

# Sound effect filenames (optional — placed in same folder)
SOUND_CORRECT = "correct.wav"
SOUND_WRONG = "wrong.wav"
SOUND_SUCCESS = "success.wav"
SOUND_RESULT = "result.wav"

# Colors and fonts
PALETTE = {
    "bg": "#fffbf0",
    "menu": "#e3f2fd",
    "typing": "#f3e5f5",
    "dictation": "#fce4ec",
    "read": "#e0f2f1",
    "math": "#e8f5e8",
    "admin": "#f1f8e9",
}

# ---------- Initialize pygame.mixer ----------
SOUND_OK = False
try:
    pygame.mixer.pre_init(22050, -16, 2, 512)
    pygame.mixer.init()
    SOUND_OK = True
except Exception as e:
    print("Warning: pygame.mixer init failed:", e)
    SOUND_OK = False

# Helper to play optional wav files (no error if file missing)
def try_play_sound(filename):
    if not SOUND_OK:
        return
    if not os.path.exists(filename):
        return
    try:
        snd = pygame.mixer.Sound(filename)
        snd.play()
    except Exception as e:
        print(f"Sound play error {filename}:", e)


# ---------- TTS Manager ----------
class TTSManager:
    """Handles gTTS creation and playback in a serialized safe way."""
    def __init__(self, lang=LANG, tld=TLD):
        self.lang = lang
        self.tld = tld
        self.lock = threading.Lock()
        self.enabled = GTTS_AVAILABLE

    def speak(self, text, repeat=1, block=False):
        if not text or not self.enabled:
            # If gTTS not available, print in console
            print("TTS unavailable: would say:", text)
            return
        if block:
            self._do_speak(text, repeat)
        else:
            threading.Thread(target=self._do_speak, args=(text, repeat), daemon=True).start()

    def _do_speak(self, text, repeat):
        with self.lock:
            for _ in range(repeat):
                tmp = None
                try:
                    tmp = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
                    tmp.close()
                    tts = gTTS(text=text, lang=self.lang, tld=self.tld)
                    tts.save(tmp.name)
                    if SOUND_OK:
                        try:
                            pygame.mixer.music.stop()
                            pygame.mixer.music.load(tmp.name)
                            pygame.mixer.music.play()
                            while pygame.mixer.music.get_busy():
                                pygame.time.wait(50)
                        except Exception as e:
                            print("Playback error:", e)
                    else:
                        print("TTS (no sound) :", text)
                except Exception as e:
                    print("gTTS error:", e)
                finally:
                    if tmp is not None and os.path.exists(tmp.name):
                        try:
                            os.unlink(tmp.name)
                        except:
                            pass
                time.sleep(0.25)

    def stop(self):
        if SOUND_OK:
            try:
                pygame.mixer.music.stop()
            except:
                pass

tts_manager = TTSManager()

# ---------- Database helpers ----------
def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS words (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            word TEXT UNIQUE NOT NULL
        )""")
    # If empty, insert defaults
    c.execute("SELECT COUNT(*) FROM words")
    if c.fetchone()[0] == 0:
        defaults = [
            "apple", "banana", "mango", "cat", "dog", "mom", "dad",
            "ball", "book", "sun", "tree", "milk", "cup", "car",
            "house", "pen", "bird", "fish", "hat", "shoe"
        ]
        for w in defaults:
            try:
                c.execute("INSERT INTO words (word) VALUES (?)", (w,))
            except:
                pass
        conn.commit()
    conn.close()

def load_words():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT word FROM words ORDER BY word")
    rows = c.fetchall()
    conn.close()
    return [r[0] for r in rows]

def add_word_to_db(word):
    word = word.strip().lower()
    if not word or not word.isalpha():
        return False, "Invalid word (only letters)."
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    try:
        c.execute("INSERT INTO words (word) VALUES (?)", (word,))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return False, "Word already exists."
    conn.close()
    return True, "Added."

def delete_duplicates_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    # This deletes duplicates keeping the smallest id
    c.execute("""
        DELETE FROM words
        WHERE id NOT IN (
            SELECT MIN(id) FROM words GROUP BY word
        )
    """)
    deleted = conn.total_changes
    conn.commit()
    conn.close()
    return deleted

def append_words_from_file(filepath):
    added = 0
    skipped = 0
    if not os.path.exists(filepath):
        return 0, 0
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    with open(filepath, "r", encoding="utf-8") as f:
        for line in f:
            w = line.strip().lower()
            if not w:
                continue
            if not w.isalpha():
                skipped += 1
                continue
            try:
                c.execute("INSERT INTO words (word) VALUES (?)", (w,))
                conn.commit()
                added += 1
            except sqlite3.IntegrityError:
                skipped += 1
    conn.close()
    return added, skipped

# ---------- Utility functions ----------
def speak_and_print(text, repeat=1, block=False):
    """Speak (via TTS) and optionally print to console for debug."""
    print("TTS ->", text)
    tts_manager.speak(text, repeat=repeat, block=block)

# ---------- Main Application ----------
class WordFunApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.configure(bg=PALETTE["bg"])
        self.geometry("1024x720")
        self.state("zoomed")
        self.protocol("WM_DELETE_WINDOW", self.quit_app)
        # Font
        try:
           import tkinter.font as tkfont
           self.base_font = ("Segoe UI", 20) if "Segoe UI" in tkfont.families() else ("Arial", 20)
        except Exception:
           self.base_font = ("Arial", 20)
        # Data
        init_db()
        self.words = load_words()
        self.child_name = "Learner"
        # Start with splash welcome, then main menu
        self.after(200, self.show_splash_and_welcome)

    # ---------------- Splash and Welcome ----------------
    def show_splash_and_welcome(self):
        self.clear_window()
        frame = tk.Frame(self, bg=PALETTE["bg"])
        frame.pack(expand=True, fill=tk.BOTH)
        title = tk.Label(frame, text="Welcome to WordFun!", font=(self.base_font[0], 44, "bold"),
                         bg=PALETTE["bg"], fg="#2e7d32")
        title.pack(pady=20)
        subtitle = tk.Label(frame, text=f"{VERSION_TEXT}\nDeveloped by: Augustine Anbananthan",
                            font=(self.base_font[0], 18), bg=PALETTE["bg"])
        subtitle.pack(pady=6)
        # Speak welcome (non-blocking) while showing splash
        speak_and_print("Welcome to WordFun! Augustine Anbananthan welcomes you, my little friend.", repeat=1, block=False)
        # show for ~3 seconds, then move to main menu
        self.after(3000, self.show_main_menu)

    # ---------------- General UI helpers ----------------
    def clear_window(self):
        for w in self.winfo_children():
            w.destroy()

    def show_main_menu(self):
        self.clear_window()
        self.configure(bg=PALETTE["menu"])
        frame = tk.Frame(self, bg=PALETTE["menu"])
        frame.pack(expand=True, fill=tk.BOTH, padx=24, pady=18)
        tk.Label(frame, text=f"Hello {self.child_name}!", font=(self.base_font[0], 36, "bold"),
                 bg=PALETTE["menu"], fg="#1565c0").pack(pady=8)
        tk.Label(frame, text="Choose your learning activity:", font=(self.base_font[0], 20),
                 bg=PALETTE["menu"]).pack(pady=6)

        btnf = tk.Frame(frame, bg=PALETTE["menu"])
        btnf.pack(pady=12)
        tk.Button(btnf, text="⌨️ Typing Practice", font=(self.base_font[0], 20, "bold"),
                  bg="#8e24aa", fg="white", width=22, height=2, command=self.open_typing).grid(row=0, column=0, padx=8, pady=8)
        tk.Button(btnf, text="👂 Dictation Exercise", font=(self.base_font[0], 20, "bold"),
                  bg="#e91e63", fg="white", width=22, height=2, command=self.open_dictation).grid(row=0, column=1, padx=8, pady=8)
        tk.Button(btnf, text="📖 Read Words", font=(self.base_font[0], 20, "bold"),
                  bg="#0097a7", fg="white", width=22, height=2, command=self.open_read).grid(row=1, column=0, padx=8, pady=8)
        tk.Button(btnf, text="🔢 Maths Quiz", font=(self.base_font[0], 20, "bold"),
                  bg="#43a047", fg="white", width=22, height=2, command=self.open_math).grid(row=1, column=1, padx=8, pady=8)

        # Admin options embedded in main menu
        admin_frame = tk.Frame(frame, bg=PALETTE["menu"])
        admin_frame.pack(pady=14)
        tk.Button(admin_frame, text="⚙️ Admin Panel", font=(self.base_font[0], 16, "bold"),
                  bg="#607d8b", fg="white", width=18, height=1, command=self.open_admin).pack(side=tk.LEFT, padx=6)
        tk.Button(admin_frame, text="ℹ️ About", font=(self.base_font[0], 16, "bold"),
                  bg="#546e7a", fg="white", width=18, height=1, command=self.show_about).pack(side=tk.LEFT, padx=6)
        tk.Button(admin_frame, text="🚪 Quit", font=(self.base_font[0], 16, "bold"),
                  bg="#ff7043", fg="white", width=12, height=1, command=self.quit_app).pack(side=tk.LEFT, padx=6)

    # ---------------- Typing Practice (QWERTY) ----------------
    class TypingScreen:
        QWERTY_ROWS = ["qwertyuiop", "asdfghjkl", "zxcvbnm"]

        def __init__(self, parent):
            self.parent = parent
            self.words = [w for w in load_words() if w.isalpha()]
            if not self.words:
                messagebox.showwarning("No words", "No words available for typing practice.")
                parent.show_main_menu()
                return
            self.total = min(10, len(self.words))
            random.shuffle(self.words)
            self.index = 0
            self.current = ""
            self.letter_index = 0
            self.key_widgets = {}
            self.build_ui()
            self.next_word()

        def build_ui(self):
            p = self.parent
            p.clear_window()
            p.configure(bg=PALETTE["typing"])
            frame = tk.Frame(p, bg=PALETTE["typing"])
            frame.pack(expand=True, fill=tk.BOTH, padx=12, pady=12)
            tk.Label(frame, text="⌨️ Typing Practice", font=(p.base_font[0], 32, "bold"),
                     bg=PALETTE["typing"], fg="#6a1b9a").pack(pady=6)
            self.word_label = tk.Label(frame, text="", font=(p.base_font[0], 64, "bold"),
                                       bg=PALETTE["typing"], fg="#1565c0")
            self.word_label.pack(pady=6)
            self.entry = ttk.Entry(frame, font=(p.base_font[0], 36), width=20)
            self.entry.pack(pady=6)
            self.entry.focus()
            self.entry.bind("<KeyRelease>", self.on_key_release)
            # On-screen keyboard
            kb = tk.Frame(frame, bg=PALETTE["typing"])
            kb.pack(pady=8)
            self.key_widgets = {}
            for r, row in enumerate(self.QWERTY_ROWS):
                rowf = tk.Frame(kb, bg=PALETTE["typing"])
                rowf.pack(pady=4)
                if r == 1:
                    tk.Frame(rowf, width=30, bg=PALETTE["typing"]).pack(side=tk.LEFT)
                if r == 2:
                    tk.Frame(rowf, width=50, bg=PALETTE["typing"]).pack(side=tk.LEFT)
                for ch in row:
                    lbl = tk.Label(rowf, text=ch.upper(), font=(p.base_font[0], 18, "bold"),
                                   width=4, height=2, bd=2, relief="raised", bg="lightgray", cursor="hand2")
                    lbl.pack(side=tk.LEFT, padx=4)
                    lbl.bind("<Button-1>", lambda e, c=ch: self.on_virtual_key(c))
                    self.key_widgets[ch] = lbl
            # Controls
            cf = tk.Frame(frame, bg=PALETTE["typing"])
            cf.pack(pady=12)
            tk.Button(cf, text="✅ Submit", font=(p.base_font[0], 18, "bold"),
                      bg="#4caf50", fg="white", width=12, command=self.check_word).pack(side=tk.LEFT, padx=6)
            tk.Button(cf, text="⬅️ Back", font=(p.base_font[0], 18, "bold"),
                      bg="#607d8b", fg="white", width=12, command=p.show_main_menu).pack(side=tk.LEFT, padx=6)
            self.status = tk.Label(frame, text=f"Progress: 0/{self.total}", font=(p.base_font[0], 18),
                                   bg=PALETTE["typing"])
            self.status.pack(pady=8)

        def highlight_next(self):
            # reset keys
            for w in self.key_widgets.values():
                w.config(bg="lightgray")
            if self.letter_index < len(self.current):
                expected = self.current[self.letter_index].lower()
                widget = self.key_widgets.get(expected)
                if widget:
                    widget.config(bg="#ffeb3b")  # yellow highlight

        def on_virtual_key(self, ch):
            self.entry.insert(tk.END, ch)
            self.on_key_release(None)

        def on_key_release(self, event):
            typed = self.entry.get()
            # trim to target length
            if len(typed) > len(self.current):
                typed = typed[:len(self.current)]
                self.entry.delete(0, tk.END)
                self.entry.insert(0, typed)
            # if prefix mismatch, erase last char and flash
            if not self.current.lower().startswith(typed.lower()):
                if typed:
                    last = typed[-1].lower()
                    w = self.key_widgets.get(last)
                    if w:
                        orig = w.cget("bg")
                        w.config(bg="#ff8a80")
                        self.parent.after(180, lambda w=w, o=orig: w.config(bg=o))
                    # delete wrong char
                    self.entry.delete(len(typed)-1, tk.END)
                return
            # advance
            self.letter_index = len(typed)
            self.highlight_next()
            # if complete
            if typed.lower() == self.current.lower():
                self.check_word()

        def next_word(self):
            if self.index >= self.total:
                messagebox.showinfo("Done", f"Typing practice complete! Score: {self.index}/{self.total}")
                self.parent.show_main_menu()
                return
            self.current = self.words[self.index]
            self.letter_index = 0
            self.word_label.config(text=self.current)
            self.entry.delete(0, tk.END)
            self.entry.focus()
            self.status.config(text=f"Progress: {self.index}/{self.total}")
            # instruction + repeat word twice
            speak_and_print(f"Type the word {self.current}", repeat=1, block=False)
            threading.Thread(target=lambda: tts_manager.speak(self.current, repeat=2, block=False), daemon=True).start()
            self.highlight_next()

        def check_word(self):
            typed = self.entry.get().strip().lower()
            if typed == self.current.lower():
                try_play_sound(SOUND_CORRECT)
                speak_and_print("Excellent! Correct!", repeat=1, block=False)
            else:
                try_play_sound(SOUND_WRONG)
                speak_and_print(f"Oops! The correct word is {self.current}", repeat=2, block=False)
            self.index += 1
            self.parent.after(800, self.next_word)

    def open_typing(self):
        self.TypingScreen(self)

    # ---------------- Dictation Screen ----------------
    class DictationScreen:
        def __init__(self, parent):
            self.parent = parent
            self.words = load_words().copy()
            random.shuffle(self.words)
            self.total = min(10, len(self.words))
            self.index = 0
            self.score = 0
            self.current = ""
            self.build_ui()
            self.next_word()

        def build_ui(self):
            p = self.parent
            p.clear_window()
            p.configure(bg=PALETTE["dictation"])
            frame = tk.Frame(p, bg=PALETTE["dictation"])
            frame.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)
            tk.Label(frame, text="👂 Dictation Exercise", font=(p.base_font[0], 32, "bold"),
                     bg=PALETTE["dictation"], fg="#c2185b").pack(pady=6)
            self.counter = tk.Label(frame, text="", font=(p.base_font[0], 18), bg=PALETTE["dictation"])
            self.counter.pack()
            self.entry = ttk.Entry(frame, font=(p.base_font[0], 32), width=24)
            self.entry.pack(pady=10)
            self.entry.bind("<Return>", lambda e: self.check_answer())
            btnf = tk.Frame(frame, bg=PALETTE["dictation"])
            btnf.pack(pady=8)
            tk.Button(btnf, text="🔄 Repeat", font=(p.base_font[0], 18, "bold"), bg="#9c27b0", fg="white",
                      command=self.repeat_word, width=14).pack(side=tk.LEFT, padx=6)
            tk.Button(btnf, text="⬅️ Back", font=(p.base_font[0], 18, "bold"), bg="#607d8b", fg="white",
                      command=p.show_main_menu, width=14).pack(side=tk.LEFT, padx=6)
            self.feedback = tk.Label(frame, text="", font=(p.base_font[0], 20, "bold"), bg=PALETTE["dictation"], fg="#333")
            self.feedback.pack(pady=8)
            self.score_lbl = tk.Label(frame, text=f"Score: {self.score}/{self.total}", font=(p.base_font[0], 18),
                                      bg=PALETTE["dictation"])
            self.score_lbl.pack(pady=6)

        def next_word(self):
            if self.index >= self.total:
                messagebox.showinfo("Result", f"Dictation Complete! Score: {self.score}/{self.total}")
                try_play_sound(SOUND_SUCCESS)
                speak_and_print(f"Dictation complete! Score {self.score} out of {self.total}", repeat=1, block=False)
                self.parent.show_main_menu()
                return
            self.current = self.words[self.index]
            self.counter.config(text=f"Word {self.index+1} of {self.total}")
            self.entry.delete(0, tk.END)
            self.entry.focus()
            self.feedback.config(text="")
            speak_and_print("Listen carefully and write the word", repeat=1, block=False)
            threading.Thread(target=lambda: tts_manager.speak(self.current, repeat=2, block=False), daemon=True).start()

        def repeat_word(self):
            if self.current:
                tts_manager.speak(self.current, repeat=2, block=False)
                self.entry.focus()

        def check_answer(self):
            ans = self.entry.get().strip().lower()
            if not ans:
                self.entry.focus()
                return
            if ans == self.current.lower():
                self.score += 1
                try_play_sound(SOUND_CORRECT)
                speak_and_print("Excellent! Correct!", repeat=1, block=False)
                self.feedback.config(text="Correct!", fg="#2e7d32")
            else:
                try_play_sound(SOUND_WRONG)
                # Show correct word visually and speak it twice
                self.feedback.config(text=f"Correct: {self.current}", fg="#d32f2f")
                speak_and_print(f"Oops! The correct word is {self.current}", repeat=2, block=False)
            self.score_lbl.config(text=f"Score: {self.score}/{self.total}")
            self.index += 1
            self.parent.after(1200, self.next_word)

    def open_dictation(self):
        self.DictationScreen(self)

    # ---------------- Read Words Screen ----------------
    class ReadWordsScreen:
        def __init__(self, parent):
            self.parent = parent
            self.words = load_words().copy()
            if not self.words:
                messagebox.showwarning("No words", "No words available.")
                parent.show_main_menu()
                return
            self.index = 0
            self.build_ui()
            self.read_current()

        def build_ui(self):
            p = self.parent
            p.clear_window()
            p.configure(bg=PALETTE["read"])
            frame = tk.Frame(p, bg=PALETTE["read"])
            frame.pack(expand=True, fill=tk.BOTH)
            tk.Label(frame, text="📖 Read Words", font=(p.base_font[0], 32, "bold"),
                     bg=PALETTE["read"], fg="#00695c").pack(pady=6)
            self.word_label = tk.Label(frame, text="", font=(p.base_font[0], 64, "bold"), bg=PALETTE["read"], fg="#1565c0")
            self.word_label.pack(pady=10)
            btnf = tk.Frame(frame, bg=PALETTE["read"])
            btnf.pack(pady=8)
            tk.Button(btnf, text="⬅️ Prev", font=(p.base_font[0], 18, "bold"), bg="#607d8b", fg="white",
                      command=self.prev_word, width=14).pack(side=tk.LEFT, padx=6)
            tk.Button(btnf, text="🔊 Read Again", font=(p.base_font[0], 18, "bold"), bg="#9c27b0", fg="white",
                      command=self.read_current, width=14).pack(side=tk.LEFT, padx=6)
            tk.Button(btnf, text="➡️ Next", font=(p.base_font[0], 18, "bold"), bg="#4caf50", fg="white",
                      command=self.next_word, width=14).pack(side=tk.LEFT, padx=6)
            tk.Button(frame, text="⬅️ Back to Menu", font=(p.base_font[0], 18, "bold"),
                      bg="#ff5722", fg="white", command=p.show_main_menu, width=18).pack(pady=10)

        def read_current(self):
            word = self.words[self.index]
            self.word_label.config(text=word)
            speak_and_print("Read the word aloud", repeat=1, block=False)
            threading.Thread(target=lambda: tts_manager.speak(word, repeat=2, block=False), daemon=True).start()

        def next_word(self):
            self.index = (self.index + 1) % len(self.words)
            self.read_current()

        def prev_word(self):
            self.index = (self.index - 1) % len(self.words)
            self.read_current()

    def open_read(self):
        self.ReadWordsScreen(self)

    # ---------------- Maths Quiz (simple Class 1-5 level) ----------------
    class MathQuizScreen:
        def __init__(self, parent):
            self.parent = parent
            self.num_questions = 8
            self.current_q = 0
            self.score = 0
            self.answer = None
            self.build_ui()
            self.next_question()

        def build_ui(self):
            p = self.parent
            p.clear_window()
            p.configure(bg=PALETTE["math"])
            frame = tk.Frame(p, bg=PALETTE["math"])
            frame.pack(expand=True, fill=tk.BOTH)
            tk.Label(frame, text="🔢 Maths Quiz", font=(p.base_font[0], 32, "bold"),
                     bg=PALETTE["math"], fg="#2e7d32").pack(pady=6)
            self.question_label = tk.Label(frame, text="", font=(p.base_font[0], 44, "bold"), bg=PALETTE["math"], fg="#1565c0")
            self.question_label.pack(pady=12)
            self.entry = ttk.Entry(frame, font=(p.base_font[0], 32), width=12)
            self.entry.pack(pady=8)
            self.entry.bind("<Return>", lambda e: self.check_answer())
            tk.Button(frame, text="✅ Submit", font=(p.base_font[0], 18, "bold"), bg="#4caf50", fg="white",
                      command=self.check_answer, width=14).pack(pady=6)
            tk.Button(frame, text="⬅️ Back", font=(p.base_font[0], 18, "bold"), bg="#607d8b", fg="white",
                      command=p.show_main_menu, width=14).pack(pady=6)
            self.score_lbl = tk.Label(frame, text=f"Score: {self.score}/{self.num_questions}", font=(p.base_font[0], 18), bg=PALETTE["math"])
            self.score_lbl.pack(pady=6)

        def next_question(self):
            if self.current_q >= self.num_questions:
                messagebox.showinfo("Result", f"Maths complete! Score: {self.score}/{self.num_questions}")
                try_play_sound(SOUND_SUCCESS)
                speak_and_print(f"Maths complete! Score {self.score} out of {self.num_questions}", repeat=1, block=False)
                self.parent.show_main_menu()
                return
            op = random.choice(["+", "-", "*"])
            if op == "+":
                a = random.randint(1, 20); b = random.randint(1, 20); ans = a + b
                text = f"What is {a} plus {b}?"
                label = f"{a} + {b} = ?"
            elif op == "-":
                a = random.randint(1, 20); b = random.randint(1, a); ans = a - b
                text = f"What is {a} minus {b}?"
                label = f"{a} - {b} = ?"
            else:
                a = random.randint(1, 12); b = random.randint(1, 12); ans = a * b
                text = f"What is {a} times {b}?"
                label = f"{a} × {b} = ?"
            self.answer = ans
            self.question_label.config(text=label)
            speak_and_print(text, repeat=1, block=False)
            self.entry.delete(0, tk.END)
            self.entry.focus()

        def check_answer(self):
            try:
                val = int(self.entry.get().strip())
            except:
                self.entry.delete(0, tk.END)
                self.entry.focus()
                speak_and_print("Please enter a valid number", repeat=1, block=False)
                return
            if val == self.answer:
                self.score += 1
                try_play_sound(SOUND_CORRECT)
                speak_and_print("Correct! Well done!", repeat=1, block=False)
            else:
                try_play_sound(SOUND_WRONG)
                speak_and_print(f"Oops! The correct answer is {self.answer}", repeat=1, block=False)
            self.current_q += 1
            self.score_lbl.config(text=f"Score: {self.score}/{self.num_questions}")
            self.parent.after(900, self.next_question)

    def open_math(self):
        self.MathQuizScreen(self)

    # ---------------- Admin Panel (embedded in main window) ----------------
    class AdminPanel:
        def __init__(self, parent):
            self.parent = parent
            self.build_ui()

        def build_ui(self):
            p = self.parent
            p.clear_window()
            p.configure(bg=PALETTE["admin"])
            frame = tk.Frame(p, bg=PALETTE["admin"])
            frame.pack(expand=True, fill=tk.BOTH, padx=12, pady=12)
            tk.Label(frame, text="⚙️ Admin Panel", font=(p.base_font[0], 32, "bold"),
                     bg=PALETTE["admin"], fg="#33691e").pack(pady=6)
            # Add word
            addf = tk.Frame(frame, bg=PALETTE["admin"])
            addf.pack(pady=6)
            tk.Label(addf, text="Add word:", font=(p.base_font[0], 16), bg=PALETTE["admin"]).pack(side=tk.LEFT, padx=6)
            self.add_entry = ttk.Entry(addf, font=(p.base_font[0], 16), width=20)
            self.add_entry.pack(side=tk.LEFT, padx=6)
            tk.Button(addf, text="➕ Add", font=(p.base_font[0], 14, "bold"), bg="#4caf50", fg="white",
                      command=self.add_word).pack(side=tk.LEFT, padx=6)
            # Delete duplicates
            tk.Button(frame, text="🧹 Delete Duplicates", font=(p.base_font[0], 16, "bold"), bg="#ffb300", fg="white",
                      command=self.delete_duplicates, width=20).pack(pady=8)
            # Append from text file
            tk.Button(frame, text="📁 Append from Text File", font=(p.base_font[0], 16, "bold"), bg="#5c6bc0", fg="white",
                      command=self.append_from_file, width=28).pack(pady=8)
            # Word list
            self.listbox = tk.Listbox(frame, font=(p.base_font[0], 14))
            self.listbox.pack(pady=8, fill=tk.BOTH, expand=True)
            # Buttons
            btnf = tk.Frame(frame, bg=PALETTE["admin"])
            btnf.pack(pady=6)
            tk.Button(btnf, text="ℹ️ About", font=(p.base_font[0], 14, "bold"), bg="#546e7a", fg="white",
                      command=p.show_about).pack(side=tk.LEFT, padx=6)
            tk.Button(btnf, text="⬅️ Back", font=(p.base_font[0], 14, "bold"), bg="#607d8b", fg="white",
                      command=p.show_main_menu).pack(side=tk.LEFT, padx=6)
            self.refresh_list()

        def refresh_list(self):
            self.listbox.delete(0, tk.END)
            words = load_words()
            for w in words:
                self.listbox.insert(tk.END, w)

        def add_word(self):
            w = self.add_entry.get().strip().lower()
            if not w:
                return
            ok, msg = add_word_to_db(w)
            messagebox.showinfo("Add word", msg)
            try_play_sound(SOUND_SUCCESS if ok else SOUND_WRONG)
            self.add_entry.delete(0, tk.END)
            self.refresh_list()

        def delete_duplicates(self):
            deleted = delete_duplicates_db()
            if deleted > 0:
                messagebox.showinfo("Duplicates", f"Deleted {deleted} duplicate entries.")
                try_play_sound(SOUND_SUCCESS)
            else:
                messagebox.showinfo("Duplicates", "No duplicates found.")
            self.refresh_list()

        def append_from_file(self):
            fn = filedialog.askopenfilename(title="Select word list (text file)", filetypes=[("Text files","*.txt"), ("All files","*.*")])
            if not fn:
                return
            added, skipped = append_words_from_file(fn)
            messagebox.showinfo("Append words", f"Added {added} new words. Skipped {skipped}.")
            if added > 0:
                try_play_sound(SOUND_SUCCESS)
            else:
                try_play_sound(SOUND_WRONG)
            self.refresh_list()

    def open_admin(self):
        self.AdminPanel(self)

    # ---------------- About (accessible to all) ----------------
    def show_about(self):
        # pastel popup inside same main window
        self.clear_window()
        frame = tk.Frame(self, bg="#fffde7")
        frame.pack(expand=True, fill=tk.BOTH)
        tk.Label(frame, text="🎯 Fun With Words — WordFun", font=(self.base_font[0], 28, "bold"), bg="#fffde7").pack(pady=8)
        tk.Label(frame, text=VERSION_TEXT, font=(self.base_font[0], 16), bg="#fffde7").pack(pady=4)
        tk.Label(frame, text="Developed by: Augustine Anbananthan", font=(self.base_font[0], 16), bg="#fffde7").pack(pady=4)
        tk.Label(frame, text="AI Assistance: ChatGPT (OpenAI)", font=(self.base_font[0], 14), bg="#fffde7").pack(pady=6)
        tk.Label(frame, text="\nCreated freely for the joy of learning.\nNo cost. No limits.", font=(self.base_font[0], 14), bg="#fffde7").pack(pady=6)
        tk.Button(frame, text="⬅️ Back", font=(self.base_font[0], 16, "bold"), bg="#607d8b", fg="white", command=self.show_main_menu).pack(pady=12)
        # read about text aloud
        speak_and_print("This is WordFun, Version one point zero, created by Augustine Anbananthan with AI assistance from ChatGPT. Made freely for the joy of learning.", repeat=1, block=False)

    # ---------------- Quit ----------------
    def quit_app(self):
        # play result sound and speak goodbye, then exit cleanly
        try_play_sound(SOUND_RESULT)
        speak_and_print("Goodbye, my little friend! See you soon.", repeat=1, block=False)
        # ensure TTS stops and mixer quits
        self.after(900, self._final_exit)

    def _final_exit(self):
        try:
            tts_manager.stop()
        except:
            pass
        try:
            if SOUND_OK:
                pygame.mixer.quit()
        except:
            pass
        try:
            self.destroy()
        except:
            pass

# ---------- Entry point ----------
if __name__ == "__main__":
    # ensure current directory is script directory (so sounds and DB are located properly)
    try:
        os.chdir(os.path.dirname(os.path.abspath(__file__)))
    except Exception:
        pass
    print("Starting WordFun...")
    app = WordFunApp()
    app.mainloop()
