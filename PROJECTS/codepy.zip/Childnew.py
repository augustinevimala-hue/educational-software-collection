﻿import tkinter as tk
from tkinter import messagebox, ttk
import random
import dbf
import phunspell
import os
from datetime import datetime

# Initialize spell checkers
pspell_us = phunspell.Phunspell('en_US')
pspell_gb = phunspell.Phunspell('en_GB')

# DBF files
WORDS_DBF = 'words.dbf'
USERS_DBF = 'users.dbf'
SCORES_DBF = 'scores.dbf'
REWARDS_DBF = 'rewards.dbf'

# Ensure DBF files exist
for db_file in [WORDS_DBF, USERS_DBF, SCORES_DBF, REWARDS_DBF]:
    if not os.path.exists(db_file):
        if db_file == WORDS_DBF:
            table = dbf.Table(filename=WORDS_DBF, field_specs='word C(8)')
        elif db_file == USERS_DBF:
            table = dbf.Table(filename=USERS_DBF, field_specs='name C(50); class N(2,0); password C(20)')
        elif db_file == SCORES_DBF:
            table = dbf.Table(filename=SCORES_DBF, field_specs='name C(50); module C(20); score N(3,0); date D')
        elif db_file == REWARDS_DBF:
            table = dbf.Table(filename=REWARDS_DBF, field_specs='name C(50); stars N(3,0); badges C(100)')
        table.open(dbf.READ_WRITE)
        table.close()

# Credit
DEVELOPER_CREDIT = "Software Developer: I Augustine Anbananthan"

# Function to check spelling
def is_correct_spelling(word):
    return pspell_us.lookup(word) or pspell_gb.lookup(word)

# Function to get suggestions
def get_suggestions(word):
    suggestions = set(pspell_us.suggest(word) + pspell_gb.suggest(word))
    return list(suggestions)[:3]  # Limit to 3 suggestions

# Function to get user data and show startup window
def get_user_data(root):
    def select_user():
        selected_name = name_var.get()
        print(f"Selected name: {selected_name}")  # Debug
        start_window.destroy()
        if selected_name == "Add New Child":
            new_child_window = tk.Toplevel(root)
            new_child_window.title("Add New Child")
            new_child_window.geometry("500x400")
            new_child_window.configure(bg="#FFF9B1")
            tk.Label(new_child_window, text="Enter new child's name:", font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=20)
            name_entry = tk.Entry(new_child_window, font=("Arial", 14), width=20)
            name_entry.pack(pady=10)
            name_entry.focus_set()
            tk.Label(new_child_window, text="Enter class (1-8):", font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=20)
            class_entry = tk.Entry(new_child_window, font=("Arial", 14), width=5)
            class_entry.pack(pady=10)
            
            def submit_new_child():
                new_name = name_entry.get().strip()
                new_class_str = class_entry.get().strip()
                if not new_name:
                    new_name = "Student"
                try:
                    new_class = int(new_class_str)
                    if not 1 <= new_class <= 8:
                        messagebox.showerror("Error", "Class must be between 1 and 8.", parent=new_child_window)
                        return
                except ValueError:
                    new_class = 1
                with dbf.Table(USERS_DBF, codepage='ascii') as table:
                    table.open(dbf.READ_WRITE)
                    table.append({'name': new_name.upper(), 'class': new_class, 'password': ''})
                with dbf.Table(REWARDS_DBF, codepage='ascii') as table:
                    table.open(dbf.READ_WRITE)
                    table.append({'name': new_name.upper(), 'stars': 0, 'badges': ''})
                new_child_window.destroy()
                root.deiconify()
                root.set_user(new_name, new_class)
            
            tk.Button(new_child_window, text="Submit", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=submit_new_child).pack(pady=20)
            new_child_window.grab_set()
            root.wait_window(new_child_window)
        elif selected_name == "Parent/Teacher Login":
            parent_window = tk.Toplevel(root)
            parent_window.title("Parent/Teacher Login")
            parent_window.geometry("500x400")
            parent_window.configure(bg="#FFF9B1")
            tk.Label(parent_window, text="Enter password:", font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=20)
            password_entry = tk.Entry(parent_window, font=("Arial", 14), width=20, show="*")
            password_entry.pack(pady=10)
            password_entry.focus_set()
            
            def submit_password():
                password = password_entry.get().strip()
                if password == "admin":  # Simple password, can be changed
                    parent_window.destroy()
                    parent_menu()
                else:
                    messagebox.showerror("Error", "Incorrect password.", parent=parent_window)
            
            tk.Button(parent_window, text="Submit", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=submit_password).pack(pady=20)
            parent_window.grab_set()
            root.wait_window(parent_window)
        else:
            with dbf.Table(USERS_DBF, codepage='ascii') as table:
                table.open()
                for user in table:
                    if user['name'].strip().upper() == selected_name.upper():
                        class_level = user['class']
                        root.deiconify()
                        root.set_user(selected_name, class_level)
                        return
            root.deiconify()
            root.set_user(selected_name, 1)

    table = dbf.Table(USERS_DBF)
    table.open()
    users = [rec['name'].strip() for rec in table]
    table.close()
    if not users:
        new_child_window = tk.Toplevel(root)
        new_child_window.title("Welcome to Fun Learning!")
        new_child_window.geometry("500x400")
        new_child_window.configure(bg="#FFF9B1")
        tk.Label(new_child_window, text="Enter your name:", font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=20)
        name_entry = tk.Entry(new_child_window, font=("Arial", 14), width=20)
        name_entry.pack(pady=10)
        name_entry.focus_set()
        tk.Label(new_child_window, text="Enter your class (1-8):", font=("Arial", 16, "bold"), bg="#FFF9B1", fg="#333").pack(pady=20)
        class_entry = tk.Entry(new_child_window, font=("Arial", 14), width=5)
        class_entry.pack(pady=10)
        
        def submit_first_child():
            new_name = name_entry.get().strip()
            new_class_str = class_entry.get().strip()
            if not new_name:
                new_name = "Student"
            try:
                new_class = int(new_class_str)
                if not 1 <= new_class <= 8:
                    messagebox.showerror("Error", "Class must be between 1 and 8.", parent=new_child_window)
                    return
            except ValueError:
                new_class = 1
            with dbf.Table(USERS_DBF, codepage='ascii') as table:
                table.open(dbf.READ_WRITE)
                table.append({'name': new_name.upper(), 'class': new_class, 'password': ''})
            with dbf.Table(REWARDS_DBF, codepage='ascii') as table:
                table.open(dbf.READ_WRITE)
                table.append({'name': new_name.upper(), 'stars': 0, 'badges': ''})
            new_child_window.destroy()
            root.deiconify()
            root.set_user(new_name, new_class)
        
        tk.Button(new_child_window, text="Submit", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=submit_first_child).pack(pady=20)
        new_child_window.grab_set()
        root.wait_window(new_child_window)
        return "Student", 1
    else:
        start_window = tk.Toplevel(root)
        start_window.title("Welcome to Fun Learning!")
        start_window.geometry("500x400")
        start_window.configure(bg="#FFF9B1")
        tk.Label(start_window, text="Choose your name:", font=("Arial", 18, "bold"), bg="#FFF9B1", fg="#333").pack(pady=30)
        name_var = tk.StringVar(start_window)
        name_var.set(users[0])
        users.extend(["Add New Child", "Parent/Teacher Login"])
        dropdown = ttk.OptionMenu(start_window, name_var, *users)
        dropdown.config(width=20)
        dropdown["menu"].config(font=("Arial", 14))
        dropdown.pack(pady=20)
        tk.Button(start_window, text="Start", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=select_user).pack(pady=20)
        start_window.grab_set()
        root.wait_window(start_window)
        return users[0], 1

# Parent/Teacher Menu
def parent_menu():
    parent_window = tk.Toplevel(root)
    parent_window.title("Parent/Teacher Controls")
    parent_window.geometry("500x400")
    parent_window.configure(bg="#FFF9B1")
    tk.Label(parent_window, text="Manage Word Lists", font=("Arial", 18, "bold"), bg="#FFF9B1", fg="#333").pack(pady=30)
    tk.Button(parent_window, text="Add Word", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=parent_add_word).pack(pady=10)
    tk.Button(parent_window, text="View Words", font=("Arial", 14, "bold"), bg="#2196F3", fg="white", width=15, height=2, command=parent_view_words).pack(pady=10)
    tk.Button(parent_window, text="Close", font=("Arial", 14, "bold"), bg="#F44336", fg="white", width=15, height=2, command=parent_window.destroy).pack(pady=10)


def parent_edit_words():
        with dbf.Table(WORDS_DBF, codepage='ascii') as table:
            table.open()
            words = [rec['word'].strip().lower() for rec in table]
        edit_window = tk.Toplevel(root)
        edit_window.title("Edit/View Words")
        edit_window.geometry("500x400")
        edit_window.configure(bg="#FFF9B1")
        tk.Label(edit_window, text="Saved Words:", font=("Arial", 18, "bold"), bg="#FFF9B1", fg="#333").pack(pady=30)
        listbox = tk.Listbox(edit_window, font=("Arial", 14), width=40, height=10)
        for idx, word in enumerate(words):
            listbox.insert(tk.END, word)
        listbox.pack(pady=20)
        
        def edit_selected():
            selected = listbox.curselection()
            if selected:
                idx = selected[0]
                word = listbox.get(idx)
                new_word = tk.simpledialog.askstring("Edit Word", "Enter new word:", initialvalue=word)
                if new_word and 3 <= len(new_word) <= 8:
                    with dbf.Table(WORDS_DBF, codepage='ascii') as table:
                        table.open(dbf.READ_WRITE)
                        table[idx]['word'] = new_word.upper()
                    listbox.delete(idx)
                    listbox.insert(idx, new_word.lower())
                    messagebox.showinfo("Success", "Word updated!")

        def delete_selected():
            selected = listbox.curselection()
            if selected:
                idx = selected[0]
                with dbf.Table(WORDS_DBF, codepage='ascii') as table:
                    table.open(dbf.READ_WRITE)
                    table.delete(idx)
                listbox.delete(idx)
                messagebox.showinfo("Success", "Word deleted!")

        tk.Button(edit_window, text="Edit Selected", font=("Arial", 14, "bold"), bg="#FF9800", fg="white", width=15, height=2, command=edit_selected).pack(pady=10)
        tk.Button(edit_window, text="Delete Selected", font=("Arial", 14, "bold"), bg="#F44336", fg="white", width=15, height=2, command=delete_selected).pack(pady=10)
        tk.Button(edit_window, text="Close", font=("Arial", 14, "bold"), bg="#F44336", fg="white", width=15, height=2, command=edit_window.destroy).pack(pady=10)

# Save score
def save_score(module, score):
    with dbf.Table(SCORES_DBF, codepage='ascii') as table:
        table.open(dbf.READ_WRITE)
        table.append({'name': child_name.upper(), 'module': module, 'score': score, 'date': datetime.date.today()})
# Update rewards with appreciation
    def update_rewards(score):
        appreciation = "Great job! Keep it up!" if score > 5 else "Good effort! Try again!"
        messagebox.showinfo("Appreciation", appreciation)
        with dbf.Table(REWARDS_DBF, codepage='ascii') as table:
            table.open(dbf.READ_WRITE)
            for rec in table:
                if rec['name'].strip().upper() == child_name.upper():
                    rec['stars'] = rec['stars'] + score
                    badges = rec['badges'].strip()
                    new_badges = badges + ", Badge" if badges else "Badge" if score > 5 else badges
                    rec['badges'] = new_badges
                    break
# Show rewards
def show_rewards():
    with dbf.Table(REWARDS_DBF, codepage='ascii') as table:
        table.open()
        stars = 0
        badges = ""
        for rec in table:
            if rec['name'].strip().upper() == child_name.upper():
                stars = rec['stars']
                badges = rec['badges']
                break
    messagebox.showinfo("Rewards", f"Stars: {stars}\nBadges: {badges}")

# Add word module
def add_word():
    def submit_word():
        word = entry.get().strip().lower()
        if len(word) < 3 or len(word) > 8:
            show_result_dialog("Error", "Word must be 3-8 letters.", continue_add_word, close_add_window, add_window)
            return
        
        attempts = 0
        while attempts < 3:
            if is_correct_spelling(word):
                with dbf.Table(WORDS_DBF, codepage='ascii') as table:
                    table.open(dbf.READ_WRITE)
                    table.append({'word': word.upper()})
                show_result_dialog("Success", "Word saved!", continue_add_word, close_add_window, add_window)
                return
            else:
                attempts += 1
                if attempts < 3:
                    word = tk.simpledialog.askstring("Try Again", f"Incorrect spelling. Attempt {attempts}/3. Try again:", parent=add_window)
                    if word is None:
                        close_add_window()
                        return
                else:
                    suggestions = get_suggestions(word)
                    msg = f"Suggestions: {', '.join(suggestions)}\nEnter correct word to save:" if suggestions else "No suggestions found. Enter correct word to save:"
                    corrected = tk.simpledialog.askstring("Correct Word", msg, parent=add_window)
                    if corrected and is_correct_spelling(corrected) and 3 <= len(corrected) <= 8:
                        with dbf.Table(WORDS_DBF, codepage='ascii') as table:
                            table.open(dbf.READ_WRITE)
                            table.append({'word': corrected.upper()})
                        show_result_dialog("Success", "Corrected word saved!", continue_add_word, close_add_window, add_window)
                    else:
                        show_result_dialog("Error", "Invalid correction. Not saved.", continue_add_word, close_add_window, add_window)
                    return

    def continue_add_word():
        entry.delete(0, tk.END)
        entry.focus()

    def close_add_window():
        add_window.destroy()

    def show_result_dialog(title, message, continue_cmd, back_cmd, parent):
        dialog = tk.Toplevel(parent)
        dialog.title(title)
        dialog.geometry("500x400")
        dialog.configure(bg="#FFF9B1")
        tk.Label(dialog, text=message, font=("Arial", 18, "bold"), bg="#FFF9B1", fg="#333").pack(pady=30)
        tk.Button(dialog, text="Continue", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=lambda: [dialog.destroy(), continue_cmd()]).pack(pady=20, side=tk.LEFT, padx=20)
        tk.Button(dialog, text="Back to Main Menu", font=("Arial", 14, "bold"), bg="#F44336", fg="white", width=15, height=2, command=lambda: [dialog.destroy(), back_cmd()]).pack(pady=20, side=tk.LEFT, padx=20)

    add_window = tk.Toplevel(root)
    add_window.title("Add Word")
    add_window.geometry("500x400")
    add_window.configure(bg="#FFF9B1")
    tk.Label(add_window, text=f"{child_name}, enter a 3-8 letter word:", font=("Arial", 18, "bold"), bg="#FFF9B1", fg="#333").pack(pady=30)
    entry = tk.Entry(add_window, font=("Arial", 16), width=25)
    entry.pack(pady=20)
    tk.Button(add_window, text="Submit", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=submit_word).pack(pady=20)

# Get saved words with difficulty
def get_saved_words(difficulty):
    with dbf.Table(WORDS_DBF, codepage='ascii') as table:
        table.open()
        words = [rec['word'].strip().lower() for rec in table]
    min_len = 3 + difficulty - 1
    max_len = 8 if difficulty > 5 else min_len + difficulty
    return [w for w in words if min_len <= len(w) <= max_len]

# Generate word with blank (multiple correct possibilities)
def generate_blank_word(word):
    pos = random.randint(0, len(word) - 1)
    blanked = word[:pos] + '_' + word[pos+1:]
    correct_letters = [word[pos]]  # Base correct letter
    # Multiple answer recognition
    if word == "box":
        correct_letters.append('f')  # Accept "box" or "fox"
    return blanked, correct_letters

# Word exercise module
def word_exercise():
    difficulty = get_user_difficulty_level(*word*)
    words = get_saved_words(difficulty)
    if not words:
        show_result_dialog("Error", "No words saved yet. Add some first.", lambda: None, lambda: None, root)
        return
    
    score = 0
    total = 10
    current = 0

    def next_word():
        nonlocal current, score
        if current >= total:
            save_score("Word", score)
            update_rewards(score)
            show_result_dialog("Score", f"{child_name}, you got {score}/{total} correct!", lambda: word_exercise(), lambda: None, root)
            show_rewards()
            update_user_difficulty(score)
            return
        
        word = random.choice(words)
        blanked, correct_letters = generate_blank_word(word)
        dialog = tk.Toplevel(root)
        dialog.title("Word Exercise")
        dialog.geometry("500x400")
        dialog.configure(bg="#FFF9B1")
        tk.Label(dialog, text=f"Fill in: {blanked}", font=("Arial", 20, "bold"), bg="#FFF9B1", fg="#333").pack(pady=30)
        entry = tk.Entry(dialog, font=("Arial", 16), width=10)
        entry.pack(pady=20)
        
        def submit_guess():
            nonlocal score, current
            guess = entry.get().strip()
            dialog.destroy()
            if len(guess) == 1 and guess.lower() in [cl.lower() for cl in correct_letters]:
                score += 1
                show_result_dialog("Correct", "Good job!", next_word, lambda: None, root)
            else:
                attempts[current] += 1
                if attempts[current] < 3:
                    show_result_dialog("Wrong", f"Try again. Attempt {attempts[current]}/3.", lambda: try_again(word, correct_letters), lambda: None, root)
                else:
                    show_result_dialog("Suggestion", f"Correct letter is '{correct_letters[0]}'. Word: {word}", next_word, lambda: None, root)
        
        def try_again(word, correct_letters):
            dialog = tk.Toplevel(root)
            dialog.title("Word Exercise")
            dialog.geometry("500x400")
            dialog.configure(bg="#FFF9B1")
            tk.Label(dialog, text=f"Fill in: {blanked}", font=("Arial", 20, "bold"), bg="#FFF9B1", fg="#333").pack(pady=30)
            entry = tk.Entry(dialog, font=("Arial", 16), width=10)
            entry.pack(pady=20)
            tk.Button(dialog, text="Submit", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=submit_guess).pack(pady=20)
        
        tk.Button(dialog, text="Submit", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=submit_guess).pack(pady=20)
    
    attempts = [0] * total
    next_word()
# Generate math problem (child-aware symbols)
    def generate_math_problem(level, difficulty):
        ops = ['+', '-', 'x', '÷']  # Child-aware symbols
        op = random.choice(ops)
        max_num = 10 ** (level // 2 + 1) * (1 if difficulty == "Easy" else 2 if difficulty == "Medium" else 3)
        if op in ['+', '-']:
            a = random.randint(1, max_num)
            b = random.randint(1, max_num // 2)
            ans = a + b if op == '+' else (a - b if a > b else b - a)
        elif op == 'x':
            a = random.randint(1, max_num // 10)
            b = random.randint(1, 10 + level)
            ans = a * b
        else:  # '÷'
            b = random.randint(1, 10 + level)
            ans = random.randint(1, max_num // b)
            a = ans * b
        pos = random.randint(0, len(str(ans)) - 1)
        blanked = str(ans)[:pos] + '_' + str(ans)[pos+1:]
        return f"{a} {op} {b} = {blanked}", str(ans)[pos


# Generate math problem (child-aware symbols)
   def generate_math_problem(level, difficulty):
       ops = ['+', '-', 'x', '÷']  # Child-aware symbols
       op = random.choice(ops)
       max_num = 10 ** (level // 2 + 1) * (1 if difficulty == "Easy" else 2 if difficulty == "Medium" else 3)
       if op in ['+', '-']:
           a = random.randint(1, max_num)
           b = random.randint(1, max_num // 2)
           ans = a + b if op == '+' else (a - b if a > b else b - a)
       elif op == 'x':
           a = random.randint(1, max_num // 10)
           b = random.randint(1, 10 + level)
           ans = a * b
       else:  # '÷'
           b = random.randint(1, 10 + level)
           ans = random.randint(1, max_num // b)
           a = ans * b
       pos = random.randint(0, len(str(ans)) - 1)
       blanked = str(ans)[:pos] + '_' + str(ans)[pos+1:]
       return f"{a} {op} {b} = {blanked}", str(ans)[pos]


# Math exercise module
def math_exercise():
    difficulty = get_user_difficulty_level(*math*)
    score = 0
    total = 10
    current = 0

    def next_problem():
        nonlocal current, score
        if current >= total:
            save_score("Math", score)
            update_rewards(score)
            show_result_dialog("Score", f"{child_name}, you got {score}/{total} correct!", lambda: math_exercise(), lambda: None, root)
            show_rewards()
            update_user_difficulty(score)
            return
        
        problem, correct_digit = generate_math_problem(child_class, difficulty)
        dialog = tk.Toplevel(root)
        dialog.title("Math Exercise")
        dialog.geometry("600x450")
        dialog.configure(bg="#FFF9B1")
        tk.Label(dialog, text=f"Solve: {problem}", font=("Arial", 24, "bold"), bg="#FFF9B1", fg="#333").pack(pady=40)
        entry = tk.Entry(dialog, font=("Arial", 18), width=10)
        entry.pack(pady=20)
        
        def submit_guess():
            nonlocal score, current
            guess = entry.get().strip()
            dialog.destroy()
            if len(guess) == 1 and guess.isdigit() and guess == correct_digit:
                score += 1
                show_result_dialog("Correct", "Good job!", next_problem, lambda: None, root)
            else:
                attempts[current] += 1
                if attempts[current] < 3:
                    show_result_dialog("Wrong", f"Try again. Attempt {attempts[current]}/3.", lambda: try_again(problem, correct_digit), lambda: None, root)
                else:
                    show_result_dialog("Suggestion", f"Correct digit is '{correct_digit}'.", next_problem, lambda: None, root)
        
        def try_again(problem, correct_digit):
            dialog = tk.Toplevel(root)
            dialog.title("Math Exercise")
            dialog.geometry("600x450")
            dialog.configure(bg="#FFF9B1")
            tk.Label(dialog, text=f"Solve: {problem}", font=("Arial", 24, "bold"), bg="#FFF9B1", fg="#333").pack(pady=40)
            entry = tk.Entry(dialog, font=("Arial", 18), width=10)
            entry.pack(pady=20)
            tk.Button(dialog, text="Submit", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=submit_guess).pack(pady=20)
        
        tk.Button(dialog, text="Submit", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=submit_guess).pack(pady=20)
    
    attempts = [0] * total
    next_problem()


# Get user difficulty level
    def get_user_difficulty_level():
        difficulty_window = tk.Toplevel(root)
        difficulty_window.title("Select Difficulty")
        difficulty_window.geometry("500x400")
        difficulty_window.configure(bg="#FFF9B1")
        tk.Label(difficulty_window, text="Select Difficulty:", font=("Arial", 18, "bold"), bg="#FFF9B1", fg="#333").pack(pady=30)
        difficulty_var = tk.StringVar(difficulty_window)
        difficulty_var.set("Easy")
        dropdown = ttk.OptionMenu(difficulty_window, difficulty_var, "Easy", "Medium", "Hard")
        dropdown.config(width=20)
        dropdown["menu"].config(font=("Arial", 14))
        dropdown.pack(pady=20)
        def submit_difficulty():
            difficulty_window.destroy()
            if caller == "word":
                word_exercise()
            elif caller == "math":
                math_exercise()
        tk.Button(difficulty_window, text="Submit", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=15, height=2, command=submit_difficulty).pack(pady=20)
        difficulty_window.grab_set()
        root.wait_window(difficulty_window)
        return difficulty_var.get()


# Update user difficulty
def update_user_difficulty(score):
    if score > 8:
        with dbf.Table(USERS_DBF, codepage='ascii') as table:
            table.open()
            for rec in table:
                if rec['name'].strip().upper() == child_name.upper():
                    rec['class'] = min(8, rec['class'] + 1)
                    break

# Main GUI
root = tk.Tk()
root.title("Child Learning App")
root.geometry("800x600")
root.configure(bg="#FFF9B1")
root.iconify()  # Minimize main window on startup

tk.Label(root, text=DEVELOPER_CREDIT, font=("Arial", 10), bg="#FFF9B1", fg="#333").pack(side=tk.BOTTOM, pady=10)

# Function to set user after selection
def set_user(name, class_level):
    global child_name, child_class
    child_name, child_class = name, class_level
    tk.Label(root, text=f"Welcome, {child_name}!", font=("Arial", 24, "bold"), bg="#FFF9B1", fg="#333").pack(pady=30)
    tk.Button(root, text="Add Words", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", width=20, height=2, command=add_word).pack(pady=20)
    tk.Button(root, text="Word Exercises", font=("Arial", 14, "bold"), bg="#2196F3", fg="white", width=20, height=2, command=word_exercise).pack(pady=20)
    tk.Button(root, text="Math Exercises", font=("Arial", 14, "bold"), bg="#FF9800", fg="white", width=20, height=2, command=math_exercise).pack(pady=20)
    tk.Button(root, text="Show Rewards", font=("Arial", 14, "bold"), bg="#FF9800", fg="white", width=20, height=2, command=show_rewards).pack(pady=20)
    tk.Button(root, text="Quit", font=("Arial", 14, "bold"), bg="#F44336", fg="white", width=20, height=2, command=root.quit).pack(pady=20)

root.set_user = set_user
child_name, child_class = get_user_data(root)
root.mainloop()