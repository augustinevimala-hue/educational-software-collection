import os
import time
import subprocess
import win32com.client as win32
from pathlib import Path

# Try to import pypdf for merging
try:
    from pypdf import PdfMerger
    HAS_PYPDF = True
except ImportError:
    HAS_PYPDF = False
    print("WARNING: pypdf not installed. Install with: pip install pypdf")

# === SETTINGS YOU CAN EDIT ===

# Full path to your Excel file
EXCEL_FILE = r"D:\Anbu files\school library\staff1.xlsx"

# Sheet names (as in your workbook)
INPUT_SHEET_NAME = "Input_sheet"
PRINT_SHEET_NAME = "Print_Layout"

# Cell where you type main MNO (currently A3 in your description)
MNO_CELL = "A3"

# List of MNOs to generate pages for (8 cards per page for each MNO)
MNO_LIST = [5001, 5009]

# Output folder for temp PDFs and final merged PDF
OUTPUT_FOLDER = r"D:\Anbu files\school library\ID_Cards_Output"

# Final merged PDF name
FINAL_PDF_NAME = "All_Staff_IDCards.pdf"

# Clean up individual PDFs after merging? (True/False)
CLEANUP_TEMP_PDFS = True


def kill_excel():
    """Force kill all Excel processes."""
    try:
        os.system("taskkill /F /IM excel.exe")
        time.sleep(1)
        print("Cleaned up existing Excel processes")
    except:
        pass


def export_id_cards():
    """Main function to export ID cards and merge into single PDF."""

    # Kill any running Excel instances first
    print("Checking for running Excel instances...")
    kill_excel()
    time.sleep(2)

    # Create output folder if it does not exist
    if not os.path.exists(OUTPUT_FOLDER):
        os.makedirs(OUTPUT_FOLDER)
        print(f"Created output folder: {OUTPUT_FOLDER}")

    # Check if file exists
    if not os.path.exists(EXCEL_FILE):
        print(f"ERROR: Excel file not found: {EXCEL_FILE}")
        return False

    excel = None
    wb = None
    temp_pdfs = []

    try:
        # Start fresh Excel instance
        print(f"\nOpening Excel application...")
        excel = win32.Dispatch("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False

        time.sleep(1)

        print(f"Opening Excel file: {EXCEL_FILE}")
        wb = excel.Workbooks.Open(EXCEL_FILE)

        input_sheet = wb.Worksheets(INPUT_SHEET_NAME)
        print_sheet = wb.Worksheets(PRINT_SHEET_NAME)

        print(f"\nStarting export of {len(MNO_LIST)} pages...")
        print("=" * 60)

        for idx, mno in enumerate(MNO_LIST, 1):
            # Put MNO into Input_sheet cell
            input_sheet.Range(MNO_CELL).Value = mno

            # Force recalculation of all formulas
            excel.Calculate()
            time.sleep(1)

            # Build PDF file name (temporary)
            pdf_name = f"_temp_IDCards_{mno}.pdf"
            pdf_path = os.path.join(OUTPUT_FOLDER, pdf_name)

            # Export Print_Layout sheet to PDF using its print area
            try:
                print_sheet.ExportAsFixedFormat(
                    Type=0,
                    Filename=pdf_path,
                    Quality=0,
                    IncludeDocProperties=True,
                    IgnorePrintAreas=False,
                    OpenAfterPublish=False
                )
                temp_pdfs.append(pdf_path)
                print(f"[{idx}/{len(MNO_LIST)}] Exported MNO {mno}")
            except Exception as e:
                print(f"[{idx}/{len(MNO_LIST)}] ERROR exporting MNO {mno}: {e}")

        print("=" * 60)
        print(f"\nGenerated {len(temp_pdfs)} PDF pages")

        # Close workbook
        wb.Close(SaveChanges=False)
        time.sleep(1)

    except Exception as e:
        print(f"ERROR in export process: {e}")
        return False

    finally:
        # Try to close Excel gracefully
        try:
            if excel:
                excel.Quit()
                time.sleep(1)
        except:
            pass

        # Force kill Excel if still running
        kill_excel()

    # Merge all PDFs into one
    if temp_pdfs and HAS_PYPDF:
        merge_pdfs(temp_pdfs, OUTPUT_FOLDER, FINAL_PDF_NAME, CLEANUP_TEMP_PDFS)
        return True
    elif temp_pdfs and not HAS_PYPDF:
        print("\n" + "=" * 60)
        print("NOTE: pypdf not installed. PDFs generated but not merged.")
        print("To merge PDFs, install pypdf:")
        print("  pip install pypdf")
        print("=" * 60)
        return True
    else:
        print("ERROR: No PDFs were generated")
        return False


def merge_pdfs(pdf_list, output_folder, final_name, cleanup=True):
    """Merge multiple PDFs into a single PDF."""

    try:
        print(f"\nMerging {len(pdf_list)} PDFs into single file...")
        print("=" * 60)

        merger = PdfMerger()

        for pdf_path in pdf_list:
            if os.path.exists(pdf_path):
                merger.append(pdf_path)
                print(f"Added: {os.path.basename(pdf_path)}")
            else:
                print(f"Warning: File not found {pdf_path}")

        # Write merged PDF
        final_path = os.path.join(output_folder, final_name)
        merger.write(final_path)
        merger.close()

        print("=" * 60)
        print(f"\n✓ SUCCESS: Merged PDF created!")
        print(f"  Location: {final_path}")

        # Clean up temporary PDFs
        if cleanup:
            print(f"\nCleaning up temporary PDF files...")
            for pdf_path in pdf_list:
                try:
                    os.remove(pdf_path)
                    print(f"  Removed: {os.path.basename(pdf_path)}")
                except Exception as e:
                    print(f"  Warning: Could not delete {pdf_path}: {e}")
            print("Cleanup completed.")

        print("\n" + "=" * 60)
        print(f"Final merged PDF: {final_name}")
        print("=" * 60)
        return True

    except Exception as e:
        print(f"ERROR during merge: {e}")
        return False


if __name__ == "__main__":
    success = export_id_cards()
    if success:
        print("\nProcess completed successfully!")
    else:
        print("\nProcess failed. Check the messages above.")
