# PART 1/4 - MAIN STRUCTURE & WELCOME (NO PASSWORD, COLOUR & FONT UPDATES)
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3, random, pygame, threading, platform, os, numpy as np
from gtts import gTTS
import io, tempfile

# ---- Color Palette ----
COLORPALETTE = {
    "login": "#e6f3ff",         # Light Blue
    "menu": "#f0fff0",          # Honeydew/Mint Green
    "typing": "#fffafa",        # Snow White
    "spellcheck": "#f5f5dc",    # Beige
    "math": "#ffe4e1",          # Misty Rose
    "readwords": "#e0ffff",     # Light Cyan
    "admin": "#f5fffa"          # Mint Cream
}
DEFAULT_FONT = ("Arial Rounded MT Bold", 20)
TITLE_FONT   = ("Arial Rounded MT Bold", 40, "bold")
LABEL_FONT   = ("Arial Rounded MT Bold", 24)
CREDIT_LINE  = "Developed by Augustine Anbananthan"

# ---- Main Application Class ----
class KidsLearningApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.state('zoomed')
        self.geometry("1100x720")
        self.title("Kids Learning App")
        self.currentusername = "Guest"
        self.soundenabled = True
        self.speechenabled = True
        self.isadmin = False
        self.credit_line = CREDIT_LINE
        self.protocol("WM_DELETE_WINDOW", self.quit_app)
        self.showwelcome()

    def clearwindow(self):
        for widget in self.winfo_children():
            widget.destroy()

    def configurebg(self, colourkey):
        self.configure(bg=COLORPALETTE.get(colourkey, "#ffffff"))

    def showwelcome(self):
        self.clearwindow()
        self.configurebg("login")
        frame = tk.Frame(self, bg=COLORPALETTE["login"])
        frame.pack(expand=True)
        tk.Label(frame, text="Kids Learning App", font=TITLE_FONT, bg=COLORPALETTE["login"], fg="#0066cc").pack(pady=20)
        tk.Label(frame, text="Enter Your Name", font=LABEL_FONT, bg=COLORPALETTE["login"]).pack(pady=10)
        self.nameentry = ttk.Entry(frame, font=LABEL_FONT)
        self.nameentry.pack(pady=5)
        ttk.Button(frame, text="Start", command=self.start_app).pack(pady=20)
        tk.Label(self, text=self.credit_line, font=("Arial", 14), bg=COLORPALETTE["login"], fg="#333", anchor="se").place(relx=0.5, rely=0.98, anchor="s")  # credit line at bottom

    def start_app(self):
        username = self.nameentry.get().strip()
        if not username:
            username = "Guest"
        self.currentusername = username
        self.showmenu()

    # --- Add Quit function globally ---
    def quit_app(self):
        self.clearwindow()
        self.configurebg("menu")
        tk.Label(self, text="Hope you had a nice time learning.\nGood bye!", font=TITLE_FONT, bg=COLORPALETTE["menu"]).pack(expand=True)
        tk.Label(self, text=self.credit_line, font=("Arial", 14), bg=COLORPALETTE["menu"], fg="#333", anchor="se").place(relx=0.5, rely=0.98, anchor="s")
        # Play result.wav if available
        try:
            pygame.mixer.init()
            if os.path.exists("result.wav"):
                pygame.mixer.music.load("result.wav")
                pygame.mixer.music.play()
            else:
                self.after(3000, self.destroy)
        except Exception:
            self.after(3000, self.destroy)
        self.after(3500, self.destroy)

    # --- Main menu (to be detailed in Part 2) ---
    def showmenu(self):
        pass   # Placeholder, see Part 2



# ------END OF PART 1/4------
# COPY THIS TO typetest_part1.py, then add Part 2 etc. below.
# PART 2/4 - MAIN MENU & TYPING EXERCISE (Enhanced for Colour, Speech, Keyboard)
#import tkinter as tk
#from tkinter import ttk
#import random
#import pygame

# --- Continue KidsLearningApp Class ---

def showmenu(self):
    self.clearwindow()
    self.configurebg("menu")
    frame = tk.Frame(self, bg=COLORPALETTE["menu"])
    frame.pack(expand=True, fill='both')

    tk.Label(frame, text=f"Welcome, {self.currentusername}!", font=TITLE_FONT, bg=COLORPALETTE["menu"], fg="#228B22").pack(pady=(20, 30))

    ttk.Style().configure("Big.TButton", font=("Arial Rounded MT Bold", 28), padding=18)

    btn_frame = tk.Frame(frame, bg=COLORPALETTE["menu"])
    btn_frame.pack(pady=20)

    buttons = [
        ("Typing Exercise", self.show_typing_exercise),
        ("Spellcheck", self.show_spellcheck),
        ("Maths Quiz", self.show_math_quiz),
        ("Dictation", self.show_dictation),
        ("Read Words", self.show_read_words),
        ("Admin", self.show_admin_menu),
        ("Credits", self.show_credits),
        ("Quit", self.quit_app)
    ]
    # Arrange buttons in 2 rows
    for i, (text, cmd) in enumerate(buttons):
        b = ttk.Button(btn_frame, text=text, command=cmd, style="Big.TButton", width=18)
        b.grid(row=i//4, column=i%4, padx=20, pady=20, ipadx=10, ipady=10)

    tk.Label(self, text=self.credit_line, font=("Arial", 16), bg=COLORPALETTE["menu"], fg="#333", anchor="se").place(relx=0.5, rely=0.98, anchor="s")

def show_typing_exercise(self):
    self.exercise_count = getattr(self, 'exercise_count', 0)
    if self.exercise_count >= 10:
        self.exercise_count = 0  # Reset for next session
        tk.messagebox.showinfo("Session Complete", "Well done! You've finished 10 exercises.")
        self.showmenu()
        return
    self.clearwindow()
    self.configurebg("typing")
    frame = tk.Frame(self, bg=COLORPALETTE["typing"])
    frame.pack(expand=True, fill='both')

    words = ["elephant", "giraffe", "sky", "rainbow", "blue", "sun", "flower"]
    current_word = random.choice(words)
    self.typing_word = current_word
    self.typing_position = 0

    tk.Label(frame, text="Type the Word You Hear", font=LABEL_FONT, bg=COLORPALETTE["typing"], fg="#0077b6").pack(pady=20)
    word_display = tk.Label(frame, text=current_word, font=TITLE_FONT, bg=COLORPALETTE["typing"])
    word_display.pack(pady=12)

    entry = tk.Entry(frame, font=TITLE_FONT, justify='center', width=18)
    entry.pack(pady=12)
    entry.focus_set()

    # QWERTY Keyboard layout
    qwerty_rows = ["qwertyuiop", "asdfghjkl", "zxcvbnm"]
    key_frame = tk.Frame(frame, bg=COLORPALETTE["typing"])
    key_frame.pack(pady=20)
    keys = []
    def type_letter(letter):
        entry.insert('end', letter)
        entry.focus_set()
        highlight_keys()

    for row_idx, row in enumerate(qwerty_rows):
        row_frame = tk.Frame(key_frame, bg=COLORPALETTE["typing"])
        row_frame.pack()
        for char in row:
            b = tk.Button(row_frame, text=char.upper(), font=("Arial Rounded MT Bold", 28, "bold"),
                          bg="#f3bbfc", width=4, height=2,
                          command=lambda l=char: type_letter(l))
            b.pack(side="left", padx=2, pady=2)
            keys.append(b)

    # Move focus to entry on any key click
    def on_entry_click(event):
        entry.focus_set()
    for b in keys:
        b.bind("<Button-1>", on_entry_click)

    def highlight_keys():
        typed = entry.get()
        for b in keys:
            b.config(bg="#f3bbfc")
        next_idx = len(typed)
        if next_idx < len(current_word):
            target = current_word[next_idx]
            for b in keys:
                if b["text"].lower() == target:
                    b.config(bg="#98ff98")
                    break

    def speak_typing_word():
        self.speak_word_twice(current_word, language="en", tld="co.in")

    def check_word(event=None):
        typed = entry.get().strip().lower()
        if typed == current_word:
            message = "Correct!"
            color = "#50fa7b"
            self.play_sound("correct.wav")
        else:
            message = f"Try again!\nCorrect: {current_word}"
            color = "#ffaaaa"
            self.play_sound("wrong.wav")
        result = tk.Label(frame, text=message, font=LABEL_FONT, fg=color, bg=COLORPALETTE["typing"])
        result.pack(pady=7)
        self.after(2000, self.show_typing_exercise)

    entry.bind("<Return>", check_word)
    entry.bind("<KeyRelease>", lambda e: highlight_keys())

    # Action buttons, with large font
    btn_frame = tk.Frame(frame, bg=COLORPALETTE["typing"])
    btn_frame.pack(pady=16)
    ttk.Style().configure("Big.TButton", font=("Arial Rounded MT Bold", 22), padding=16)
    ttk.Button(btn_frame, text="Check", command=check_word, style="Big.TButton").pack(side='left', padx=12)
    ttk.Button(btn_frame, text="Repeat Word", command=speak_typing_word, style="Big.TButton").pack(side='left', padx=12)
    ttk.Button(btn_frame, text="← Main Menu", command=self.showmenu, style="Big.TButton").pack(side='left', padx=12)
    ttk.Button(btn_frame, text="Quit", command=self.quit_app, style="Big.TButton").pack(side='left', padx=12)

    highlight_keys()
    speak_typing_word()

    tk.Label(self, text=self.credit_line, font=("Arial", 14), bg=COLORPALETTE["typing"], fg="#333", anchor="se").place(relx=0.5, rely=0.98, anchor="s")

def speak_word_twice(self, word, language="en", tld="co.in"):
    # Speaks the word twice, with a small delay
    try:
        from gtts import gTTS
        import io
        tts = gTTS(text=word, lang=language, tld=tld)
        mp3_fp = io.BytesIO()
        tts.write_to_fp(mp3_fp)
        mp3_fp.seek(0)
        pygame.mixer.init()
        sound = pygame.mixer.Sound(mp3_fp)
        sound.play()
        pygame.time.wait(int(sound.get_length() * 1000) + 350)
        mp3_fp.seek(0)
        sound = pygame.mixer.Sound(mp3_fp)
        sound.play()
        pygame.time.wait(int(sound.get_length() * 1000) + 200)
    except Exception as e:
        print("Speech error:", e)

def play_sound(self, filename="correct.wav"):
    if os.path.exists(filename):
        try:
            pygame.mixer.init()
            pygame.mixer.music.load(filename)
            pygame.mixer.music.play()
        except Exception:
            pass

# Attach enhanced functions to KidsLearningApp
KidsLearningApp.showmenu = showmenu
KidsLearningApp.show_typing_exercise = show_typing_exercise
KidsLearningApp.speak_word_twice = speak_word_twice
KidsLearningApp.play_sound = play_sound

# ------END OF PART 2/4------
# COPY THIS TO typetest_part2.py (append below part 1), then add Part 3.
# PART 3/4 - SPELLCHECK, MATHS QUIZ, DICTATION, READ WORDS (Enhanced UI, Sound, Credit)

#import tkinter as tk
#from tkinter import ttk, messagebox
#import random, pygame

def show_spellcheck(self):
    self.exercise_count = getattr(self, 'exercise_count', 0)
    if self.exercise_count >= 10:
        self.exercise_count = 0  # Reset for next session
        tk.messagebox.showinfo("Session Complete", "Well done! You've finished 10 exercises.")
        self.showmenu()
        return
    self.clearwindow()
    self.configurebg("spellcheck")
    frame = tk.Frame(self, bg=COLORPALETTE["spellcheck"])
    frame.pack(expand=True, fill='both')
    words = ["apple", "banana", "car", "dog"]
    word = random.choice(words)
    tk.Label(frame, text="Spell the Word", font=LABEL_FONT, bg=COLORPALETTE["spellcheck"]).pack(pady=20)
    self.speak_word_twice(word)
    entry = tk.Entry(frame, font=LABEL_FONT, justify='center')
    entry.pack(pady=10)
    entry.focus_set()
    ttk.Button(frame, text="Check", command=lambda: self.check_spell(word, entry.get(), frame)).pack(pady=15)
    ttk.Button(frame, text="Repeat Word", command=lambda: self.speak_word_twice(word)).pack(pady=5)
    ttk.Button(frame, text="Quit", command=self.quit_app).pack(pady=5)
    tk.Label(self, text=self.credit_line, font=("Arial", 14), bg=COLORPALETTE["spellcheck"], fg="#333", anchor="se").place(relx=0.5, rely=0.98, anchor="s")

def check_spell(self, word, answer, frame):
    answer = answer.strip().lower()
    color, feedback = ("#28a745", "Well done!") if answer == word else ("#e74c3c", f"Oops! Correct: {word}")
    self.play_sound("correct.wav" if answer == word else "wrong.wav")
    label = tk.Label(frame, text=feedback, font=LABEL_FONT, bg=COLORPALETTE["spellcheck"], fg=color)
    label.pack(pady=10)
    self.after(2200, self.showmenu)

def show_math_quiz(self):
    self.exercise_count = getattr(self, 'exercise_count', 0)
    if self.exercise_count >= 10:
        self.exercise_count = 0
        tk.messagebox.showinfo("Session Complete", "Well done! You've finished 10 exercises.")
        self.showmenu()
        return
    self.clearwindow()
    # ... rest of your code

    self.clearwindow()
    self.configurebg("math")
    frame = tk.Frame(self, bg=COLORPALETTE["math"])
    frame.pack(expand=True, fill='both')
    a = random.randint(1, 20)
    b = random.randint(1, 20)
    tk.Label(frame, text=f"{a} + {b} = ?", font=TITLE_FONT, bg=COLORPALETTE["math"], fg="#b22134").pack(pady=35)
    entry = tk.Entry(frame, font=LABEL_FONT, justify='center')
    entry.pack(pady=10)
    entry.focus_set()
    def check():
        try:
            answer = int(entry.get())
            correct = (answer == (a + b))
        except ValueError:
            correct = False
        self.play_sound("correct.wav" if correct else "wrong.wav")
        msg = "Correct!" if correct else f"Wrong. {a} + {b} = {a + b}"
        tk.Label(frame, text=msg, font=LABEL_FONT, fg=("#18b226" if correct else "#c24432"), bg=COLORPALETTE["math"]).pack(pady=10)
        self.after(1800, self.showmenu)
    ttk.Button(frame, text="Check", command=check).pack(pady=12)
    ttk.Button(frame, text="Quit", command=self.quit_app).pack(pady=6)
    tk.Label(self, text=self.credit_line, font=("Arial", 14), bg=COLORPALETTE["math"], fg="#333", anchor="se").place(relx=0.5, rely=0.98, anchor="s")

def show_dictation(self):
    self.exercise_count = getattr(self, 'exercise_count', 0)
    if self.exercise_count >= 10:
        self.exercise_count = 0  # Reset for next session
        tk.messagebox.showinfo("Session Complete", "Well done! You've finished 10 exercises.")
        self.showmenu()
        return
    self.clearwindow()
    self.configurebg("typing")
    frame = tk.Frame(self, bg=COLORPALETTE["typing"])
    frame.pack(expand=True, fill='both')
    words = ["rabbit", "river", "kite", "queen"]
    word = random.choice(words)
    tk.Label(frame, text="Listen and Type the Word", font=TITLE_FONT, bg=COLORPALETTE["typing"]).pack(pady=15)
    self.speak_word_twice(word)
    entry = tk.Entry(frame, font=LABEL_FONT, justify='center')
    entry.pack(pady=10)
    entry.focus_set()
    def check():
        correct = (entry.get().strip().lower() == word)
        msg = "Correct!" if correct else f"Wrong. Word was: {word}"
        self.play_sound("correct.wav" if correct else "wrong.wav")
        tk.Label(frame, text=msg, font=LABEL_FONT, fg=("#36d133" if correct else "#d13336"), bg=COLORPALETTE["typing"]).pack(pady=10)
        self.after(2100, self.showmenu)
    ttk.Button(frame, text="Check", command=check).pack(pady=10)
    ttk.Button(frame, text="Repeat Word", command=lambda: self.speak_word_twice(word)).pack(pady=5)
    ttk.Button(frame, text="Quit", command=self.quit_app).pack(pady=5)
    tk.Label(self, text=self.credit_line, font=("Arial", 14), bg=COLORPALETTE["typing"], fg="#333", anchor="se").place(relx=0.5, rely=0.98, anchor="s")

def show_read_words(self):
    self.clearwindow()
    self.configurebg("readwords")
    frame = tk.Frame(self, bg=COLORPALETTE["readwords"])
    frame.pack(expand=True, fill='both')
    words = ["mountain", "river", "cloud", "music", "cake"]
    word = random.choice(words)
    tk.Label(frame, text="Read the Word", font=TITLE_FONT, bg=COLORPALETTE["readwords"], fg="#0c5f94").pack(pady=20)
    self.speak_word_twice(word)
    ttk.Button(frame, text="Repeat Word", command=lambda: self.speak_word_twice(word)).pack(pady=15)
    ttk.Button(frame, text="Quit", command=self.quit_app).pack(pady=10)
    tk.Label(self, text=self.credit_line, font=("Arial", 14), bg=COLORPALETTE["readwords"], fg="#333", anchor="se").place(relx=0.5, rely=0.98, anchor="s")

# Attach new features to KidsLearningApp
KidsLearningApp.show_spellcheck = show_spellcheck
KidsLearningApp.check_spell = check_spell
KidsLearningApp.show_math_quiz = show_math_quiz
KidsLearningApp.show_dictation = show_dictation
KidsLearningApp.show_read_words = show_read_words

# Update button commands in showmenu (Part 2/4) to use new functions:
# ("Spellcheck", self.show_spellcheck),
# ("Maths Quiz", self.show_math_quiz),
# ("Dictation", self.show_dictation),
# ("Read Words", self.show_read_words),

# ------END OF PART 3/4------
# COPY THIS TO typetest_part3.py (append below previous parts), then request Part 4.
# PART 4/4 - FINAL IMPROVEMENTS, CREDITS, UTILITY FUNCTIONS

import pygame, os

# Utility: Play correct/incorrect/result sounds with fallback melody if file not present.
def play_sound(self, filename):
    try:
        pygame.mixer.init()
        if os.path.exists(filename):
            pygame.mixer.music.load(filename)
            pygame.mixer.music.play()
        else:
            # Fallback: beep sound using pygame if .wav not found
            duration = 0.25              # seconds
            freq = 520 if filename == "correct.wav" else 240
            samplerate = 22050
            arr = pygame.sndarray.make_sound((np.sin(2 * np.pi * np.arange(samplerate * duration) * freq / samplerate) * 32767).astype(np.int16))
            arr.play()
    except Exception as e:
        print("Sound error:", e)

KidsLearningApp.play_sound = play_sound

# Utility: Show credits window (can be used from menus or splash screens)
def show_credits(self):
    self.clearwindow()
    credit_msg = "Developed by Augustine Anbananthan\nAll rights reserved\n2025"
    self.configurebg("admin")
    tk.Label(self, text="Credits", font=TITLE_FONT, fg="#003366", bg=COLORPALETTE["admin"]).pack(pady=30)
    tk.Label(self, text=credit_msg, font=LABEL_FONT, bg=COLORPALETTE["admin"], fg="#333333").pack(pady=20)
    ttk.Button(self, text="Back to Menu", command=self.showmenu).pack(pady=30)
    tk.Label(self, text=self.credit_line, font=("Arial", 14), bg=COLORPALETTE["admin"], fg="#333", anchor="se").place(relx=0.5, rely=0.98, anchor="s")

KidsLearningApp.show_credits = show_credits

# Optional: Add "Credits" button to main menu (update showmenu in Part 2/4)
#           
#    btns = [
#        ("Typing Exercise", self.show_typing_exercise),
#        ... other activities ...,
#        ("Credits", self.show_credits),
#        ("Quit", self.quit_app)
#    ]

# Utility: Clean up window, stop sound
def clearwindow(self):
    try:
        pygame.mixer.music.stop()
    except:
        pass
    for widget in self.winfo_children():
        widget.destroy()

def show_admin_menu(self):
    self.clearwindow()
    self.configurebg("admin")
    frame = tk.Frame(self, bg=COLORPALETTE["admin"])
    frame.pack(expand=True, fill='both')
    tk.Label(frame, text="Admin: Word Management", font=TITLE_FONT, bg=COLORPALETTE["admin"], fg="#112288").pack(pady=14)
    ttk.Button(frame, text="Back to Menu", command=self.showmenu).pack(pady=40, ipadx=10, ipady=8)
    tk.Label(self, text=self.credit_line, font=("Arial", 14), bg=COLORPALETTE["admin"], fg="#333", anchor="se").place(relx=0.5, rely=0.98, anchor="s")

# Attach the method to the class:
KidsLearningApp.show_admin_menu = show_admin_menu

KidsLearningApp.clearwindow = clearwindow
# --- Main run ---
if __name__ == "__main__":
    app = KidsLearningApp()
    app.mainloop()
# Utility: Quit from anywhere with both message and sound (already added globally)
# The quit_app function (see part 1) handles clearing, message, and playing result.wav

# --------------------------------------
# ---- END OF PART 4/4 ----
# COPY THIS BELOW previous parts in your final file to complete the refactor!
