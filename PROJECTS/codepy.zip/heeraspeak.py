import win32com.client

speaker = win32com.client.Dispatch("SAPI.SpVoice")

print("Available voices:")
for voice in speaker.GetVoices():
    print(voice.GetDescription())

# Try to select Heera explicitly
for voice in speaker.GetVoices():
    if "Heera" in voice.GetDescription():
        speaker.Voice = voice
        break

speaker.Speak("Hello! I am Heera, your Indian English voice from Windows speech.")