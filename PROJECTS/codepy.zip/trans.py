import tkinter as tk
from tkinter import messagebox
import sqlite3

DBFILE = "library.db"

def accchoose(accno):
    conn = sqlite3.connect(DBFILE)
    cur = conn.cursor()
    cur.execute(
        "SELECT t.accno, m.title, t.issue, t.return, t.mno, s.name as staffname, st.name as studentname "
        "FROM transact t "
        "LEFT JOIN master m ON t.accno = m.accno "
        "LEFT JOIN staff s ON t.mno = s.mno "
        "LEFT JOIN students st ON t.mno = st.mno "
        "WHERE t.accno = ?",
        (accno,)
    )
    row = cur.fetchone()
    conn.close()
    if not row:
        return "The book has not been issued."
    else:
        return (f"Book Details\n{'-'*40}\n"
                f"Access No: {row[0]}\n"
                f"Title: {row[1]}\n"
                f"Issued On: {row[2]}\n"
                f"Return Date: {row[3]}\n"
                f"Member No: {row[4]}\n"
                f"Staff: {row[5] or '-'}\n"
                f"Student: {row[6] or '-'}")

def on_search_click():
    try:
        accno = int(accno_entry.get())
    except ValueError:
        messagebox.showerror("Input Error", "Please enter a valid Access No.")
        return
    result = accchoose(accno)
    messagebox.showinfo("Search Result", result)

root = tk.Tk()
root.title("Book Transaction Search")

tk.Label(root, text="Enter Access No of the book:").pack()
accno_entry = tk.Entry(root)
accno_entry.pack()

tk.Button(root, text="Search", command=on_search_click).pack()

root.mainloop()
