import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import random
import pygame
import threading
import platform
import os
import numpy as np  # Import numpy for sound generation
from gtts import gTTS
import io
import tempfile

# 1. GLOBAL WORDS LIST
# This list will hold words from DEFAULT_WORDS and words added by any user.
GLOBAL_WORDS = []

# --- NEW: Color Palette for Screens ---
COLOR_PALETTE = {
    "login": "#e6f3ff",      # Light Blue
    "menu": "#f0fff0",       # Honeydew/Mint Green
    "typing": "#fffafa",     # Snow White
    "spellcheck": "#f5f5dc", # Beige
    "math": "#ffe4e1",       # Misty Rose
    "readwords": "#e0ffff",  # Light Cyan
    "admin": "#f5fffa",      # Mint Cream
}

# ===== INDIAN ENGLISH TTS SETUP (ALTERNATIVE - NO TEMP FILES) =====
class IndianEnglishTTS:
    def __init__(self):
        pygame.mixer.init()
        self.is_speaking = False
    
    def speak(self, text, wait_for_completion=True):
        """Speak text with Indian English accent - using in-memory approach"""
        def _speak_internal():
            try:
                self.is_speaking = True
                # Use gTTS with Indian English accent
                tts = gTTS(text=text, lang='en', tld='co.in')
                
                # Use BytesIO to avoid file system entirely
                mp3_fp = io.BytesIO()
                tts.write_to_fp(mp3_fp)
                mp3_fp.seek(0)
                
                # Load from memory buffer
                pygame.mixer.music.load(mp3_fp)
                pygame.mixer.music.play()
                
                # Wait for playback to complete
                while pygame.mixer.music.get_busy():
                    pygame.time.wait(100)
                    
            except Exception as e:
                print(f"TTS Error: {e}")
            finally:
                self.is_speaking = False
        
        # Stop any current speech
        self.stop()
        
        if wait_for_completion:
            _speak_internal()
        else:
            thread = threading.Thread(target=_speak_internal, daemon=True)
            thread.start()
    
    def stop(self):
        """Stop any ongoing speech"""
        try:
            pygame.mixer.music.stop()
            self.is_speaking = False
        except:
            pass

# Initialize global TTS engine
tts_engine = IndianEnglishTTS()

def speak_indian(text, wait=True):
    """
    Speak English text with Indian accent
    wait: If True, waits for speech to complete. If False, speaks in background.
    """
    tts_engine.speak(text, wait_for_completion=wait)

def stop_speech():
    """Stop any ongoing speech"""
    tts_engine.stop()
# ===== END TTS SETUP =====

# --------------------------------------
class KidsLearningApp(tk.Tk):
    def __init__(self):
        super().__init__()
        
        # FIX: Cross-platform DPI awareness
        try:
            if platform.system() == "Windows":
                from ctypes import windll
                windll.shcore.SetProcessDpiAwareness(1)
        except:
            pass
        
        self.title("Kids Typing Adventure")
        
        # --- ENHANCEMENT 2: Start Maximized ---
        self.state('zoomed')
        # ---------------------------------------
        
        self.geometry("800x600")
        self.configure(bg=COLOR_PALETTE["login"])  # Default login screen color
        
        # FIX: Remove pyttsx3 and use only gTTS
        self.speech_enabled = True
        
        # FIX: Better sound initialization
        try:
            # Use lower buffer for better responsiveness
            pygame.mixer.pre_init(frequency=22050, size=-16, channels=2, buffer=512)
            pygame.mixer.init()
            self.sound_enabled = True
            # Create default sounds programmatically if files don't exist
            self.create_default_sounds()
        except pygame.error as e:
            print(f"Warning: Pygame sound mixer failed to initialize: {e}")
            self.sound_enabled = False
        
        self.current_user_id = None
        self.current_username = "Guest"
        
        self.init_database()
        self.update_global_words()  # Populate global words on startup
        
        # FIX: Better style configuration and new style for spell check radio buttons
        self.style = ttk.Style()
        self.style.theme_use('clam')  # Use a more reliable theme
        self.style.configure("TButton", font=("Arial", 20, "bold"), padding=10)
        self.style.configure("TRadiobutton", font=("Arial", 24))
        self.style.configure("TEntry", font=("Arial", 24))
        self.style.configure("TLabel", font=("Arial", 30, "bold"))
        
        # NEW STYLE for SpellCheck Quiz focusing
        self.style.configure("Nav.TRadiobutton",
                           background="#e6f3ff",  # Default light blue background
                           foreground="black",
                           font=("Arial", 24),
                           padding=5)
        
        # Style for when the radiobutton has focus (navigation highlight)
        self.style.map("Nav.TRadiobutton",
                      background=[('focus', '#9e9e9e'), ('selected', '#a5d6a7')],
                      foreground=[('focus', 'white'), ('selected', 'black')],
                      indicatorcolor=[('selected', '#3f51b5')])  # Indicator when selected
        
        self.show_login()
    
    def create_default_sounds(self):
        """Create simple beep sounds if sound files don't exist"""
        if not os.path.exists("correct.wav"):
            # Create a simple correct sound (high frequency beep)
            self.create_beep_sound("correct.wav", 800, 0.2)
        
        if not os.path.exists("wrong.wav"):
            # Create a simple wrong sound (low frequency beep)
            self.create_beep_sound("wrong.wav", 400, 0.3)
        
        if not os.path.exists("result.wav"):
            # Create a result sound (melody)
            self.create_beep_sound("result.wav", 600, 0.4)
    
    def create_beep_sound(self, filename, frequency, duration):
        """Create a simple beep sound using pygame"""
        try:
            sample_rate = 22050
            frames = int(duration * sample_rate)
            arr = np.zeros((frames, 2))
            
            # Generate sine wave
            for i in range(frames):
                wave = np.sin(2 * np.pi * frequency * i / sample_rate)
                arr[i] = [wave, wave]
            
            # Convert to 16-bit integers
            arr = (arr * 32767).astype(np.int16)
            
            # Dummy file creation
            with open(filename, 'wb') as f:
                f.write(b'RIFF$\x00\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x01\x00D\xac\x00\x00\x88X\x01\x00\x02\x00\x10\x00data\x00\x00\x00\x00')
        except ImportError:
            # Fallback: create silent dummy files
            with open(filename, 'wb') as f:
                f.write(b'RIFF$\x00\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x01\x00D\xac\x00\x00\x88X\x01\x00\x02\x00\x10\x00data\x00\x00\x00\x00')
    
    def play_sound(self, sound_file):
        """FIX: Improved sound playing with better error handling"""
        if self.sound_enabled:
            try:
                def run_sound():
                    if os.path.exists(sound_file):
                        pygame.mixer.music.load(sound_file)
                        pygame.mixer.music.play()
                    else:
                        # Create a simple beep if file doesn't exist
                        frequency = 600 if 'correct' in sound_file else 400
                        # Re-create the sound if it's missing
                        self.create_beep_sound(sound_file, frequency, 0.2)
                        # And play the newly created/dummy sound
                        if os.path.exists(sound_file):
                            pygame.mixer.music.load(sound_file)
                            pygame.mixer.music.play()
                
                threading.Thread(target=run_sound, daemon=True).start()
            except (pygame.error, FileNotFoundError) as e:
                print(f"Sound error: {e}")
    
    def speak(self, text, block=False):
        """FIX: Use Indian English TTS instead of pyttsx3"""
        if not self.speech_enabled:
            return
        
        # Use the global Indian English TTS function
        speak_indian(text, wait=block)
    
    def save_db(self):
        """Dummy function to represent a DB save action, as SQLite is transactional."""
        pass
    
    def init_database(self):
        """FIX: Improved database initialization with better schema and indexes"""
        conn = sqlite3.connect("learning.db")
        c = conn.cursor()
        
        # Users table
        c.execute("""CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT UNIQUE NOT NULL,
                        password TEXT NOT NULL,
                        is_admin INTEGER DEFAULT 0
                     )""")
        
        # Words table
        c.execute("""CREATE TABLE IF NOT EXISTS words (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        word TEXT UNIQUE NOT NULL
                     )""")
        
        # Progress table
        c.execute("""CREATE TABLE IF NOT EXISTS progress (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        activity TEXT NOT NULL,
                        score INTEGER DEFAULT 0,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(id)
                     )""")
        
        # Create default admin user if not exists
        try:
            c.execute("INSERT INTO users (username, password, is_admin) VALUES (?, ?, ?)",
                     ("admin", "admin123", 1))
            conn.commit()
        except sqlite3.IntegrityError:
            pass  # Admin already exists
        
        # Insert default words
        default_words = [
            "cat", "dog", "mom", "dad", "ball", "apple", "book", "sun", "tree", "milk",
            "cup", "car", "house", "pen", "bird", "fish", "hat", "shoe", "door", "bed",
            "run", "jump", "play", "love", "happy"
        ]
        
        # Insert default words if the table is empty or new
        c.execute("SELECT COUNT(*) FROM words")
        if c.fetchone()[0] == 0:
            for word in default_words:
                try:
                    c.execute("INSERT INTO words (word) VALUES (?)", (word,))
                except sqlite3.IntegrityError:
                    pass  # Should not happen if count was 0
            conn.commit()
        
        conn.close()
    
    def update_global_words(self):
        """TWEAK 1: Update the GLOBAL_WORDS list from the database"""
        global GLOBAL_WORDS
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("SELECT word FROM words ORDER BY word")
            GLOBAL_WORDS = [row[0] for row in c.fetchall()]
            conn.close()
        except sqlite3.Error as e:
            print(f"Database error loading global words: {e}")
            GLOBAL_WORDS = []  # Fallback to empty list
    
    def clear_window(self):
        """Clear all widgets from the window"""
        for widget in self.winfo_children():
            widget.destroy()
    
    def show_login(self):
        """Login screen"""
        self.clear_window()
        self.configure(bg=COLOR_PALETTE["login"])
        
        frame = tk.Frame(self, bg=COLOR_PALETTE["login"])
        frame.pack(expand=True)
        
        tk.Label(frame, text="Kids Learning App", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["login"], fg="#0066cc").pack(pady=20)
        
        tk.Label(frame, text="Username:", font=("Arial", 20),
                bg=COLOR_PALETTE["login"]).pack(pady=5)
        self.username_entry = ttk.Entry(frame, font=("Arial", 20))
        self.username_entry.pack(pady=5)
        
        tk.Label(frame, text="Password:", font=("Arial", 20),
                bg=COLOR_PALETTE["login"]).pack(pady=5)
        self.password_entry = ttk.Entry(frame, font=("Arial", 20), show="*")
        self.password_entry.pack(pady=5)
        
        ttk.Button(frame, text="Login", command=self.login).pack(pady=10)
        ttk.Button(frame, text="Register", command=self.show_register).pack(pady=5)
    
    def show_register(self):
        """Registration screen"""
        self.clear_window()
        self.configure(bg=COLOR_PALETTE["login"])
        
        frame = tk.Frame(self, bg=COLOR_PALETTE["login"])
        frame.pack(expand=True)
        
        tk.Label(frame, text="Register New User", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["login"], fg="#0066cc").pack(pady=20)
        
        tk.Label(frame, text="Username:", font=("Arial", 20),
                bg=COLOR_PALETTE["login"]).pack(pady=5)
        self.reg_username_entry = ttk.Entry(frame, font=("Arial", 20))
        self.reg_username_entry.pack(pady=5)
        
        tk.Label(frame, text="Password:", font=("Arial", 20),
                bg=COLOR_PALETTE["login"]).pack(pady=5)
        self.reg_password_entry = ttk.Entry(frame, font=("Arial", 20), show="*")
        self.reg_password_entry.pack(pady=5)
        
        ttk.Button(frame, text="Register", command=self.register).pack(pady=10)
        ttk.Button(frame, text="Back to Login", command=self.show_login).pack(pady=5)
    
    def login(self):
        """Handle user login"""
        username = self.username_entry.get()
        password = self.password_entry.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter both username and password")
            return
        
        conn = sqlite3.connect("learning.db")
        c = conn.cursor()
        c.execute("SELECT id, is_admin FROM users WHERE username=? AND password=?",
                 (username, password))
        result = c.fetchone()
        conn.close()
        
        if result:
            self.current_user_id = result[0]
            self.current_username = username
            self.is_admin = result[1]
            self.show_menu()
        else:
            messagebox.showerror("Error", "Invalid username or password")
    
    def register(self):
        """Handle user registration"""
        username = self.reg_username_entry.get()
        password = self.reg_password_entry.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter both username and password")
            return
        
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("INSERT INTO users (username, password, is_admin) VALUES (?, ?, ?)",
                     (username, password, 0))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Registration successful! Please login.")
            self.show_login()
        except sqlite3.IntegrityError:
            messagebox.showerror("Error", "Username already exists")
    
    def show_menu(self):
        """Main menu screen"""
        self.clear_window()
        self.configure(bg=COLOR_PALETTE["menu"])
        
        frame = tk.Frame(self, bg=COLOR_PALETTE["menu"])
        frame.pack(expand=True)
        
        tk.Label(frame, text=f"Welcome, {self.current_username}!",
                font=("Arial", 40, "bold"), bg=COLOR_PALETTE["menu"],
                fg="#006400").pack(pady=20)
        
        ttk.Button(frame, text="Typing Practice", command=self.show_typing).pack(pady=10)
        ttk.Button(frame, text="Spell Check Quiz", command=self.show_spell_check).pack(pady=10)
        ttk.Button(frame, text="Math Quiz", command=self.show_math_quiz).pack(pady=10)
        ttk.Button(frame, text="Dictation Exercise", command=self.show_dictation).pack(pady=10)
        ttk.Button(frame, text="Read Words", command=self.show_read_words).pack(pady=10)
        
        if self.is_admin:
            ttk.Button(frame, text="Admin Panel", command=self.show_admin).pack(pady=10)
        
        ttk.Button(frame, text="View Progress", command=self.show_progress).pack(pady=10)
        ttk.Button(frame, text="Logout", command=self.logout).pack(pady=10)
    
    def logout(self):
        """Logout and return to login screen"""
        self.current_user_id = None
        self.current_username = "Guest"
        self.is_admin = False
        self.show_login()
    
    def save_progress(self, activity, score):
        """Save user progress to database"""
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("INSERT INTO progress (user_id, activity, score) VALUES (?, ?, ?)",
                     (self.current_user_id, activity, score))
            conn.commit()
            conn.close()
        except sqlite3.Error as e:
            print(f"Error saving progress: {e}")
    
    def show_progress(self):
        """Display user progress"""
        self.clear_window()
        self.configure(bg=COLOR_PALETTE["menu"])
        
        frame = tk.Frame(self, bg=COLOR_PALETTE["menu"])
        frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        
        tk.Label(frame, text="Your Progress", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["menu"], fg="#006400").pack(pady=20)
        
        # Create a text widget to display progress
        text_widget = tk.Text(frame, font=("Arial", 16), height=15, width=60)
        text_widget.pack(pady=10)
        
        # Fetch and display progress
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("""SELECT activity, score, timestamp 
                        FROM progress 
                        WHERE user_id=? 
                        ORDER BY timestamp DESC 
                        LIMIT 20""", (self.current_user_id,))
            results = c.fetchall()
            conn.close()
            
            if results:
                for activity, score, timestamp in results:
                    text_widget.insert(tk.END, f"{activity}: {score} - {timestamp}\n")
            else:
                text_widget.insert(tk.END, "No progress recorded yet.")
        except sqlite3.Error as e:
            text_widget.insert(tk.END, f"Error loading progress: {e}")
        
        text_widget.config(state=tk.DISABLED)
        
        ttk.Button(frame, text="Back to Menu", command=self.show_menu).pack(pady=10)
    
    def show_typing(self):
        """Typing practice screen"""
        TypingPractice(self)
    
    def show_spell_check(self):
        """Spell check quiz screen"""
        SpellCheckQuiz(self)
    
    def show_math_quiz(self):
        """Math quiz screen"""
        MathQuiz(self)
    
    def show_dictation(self):
        """Dictation exercise screen"""
        DictationExercise(self)
    
    def show_read_words(self):
        """Read words screen"""
        ReadWords(self)
    
    def show_admin(self):
        """Admin panel"""
        AdminPanel(self)