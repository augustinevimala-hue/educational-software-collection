import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3
import random
import pygame
import threading
import platform
import os
import numpy as np
from gtts import gTTS
import io
import tempfile
from datetime import datetime
import time

# 1. GLOBAL WORDS LIST
GLOBAL_WORDS = []

# --- ENHANCED COLOR PALETTE for Different Windows ---
COLOR_PALETTE = {
    "welcome": "#ffeb3b",       # Bright Yellow - cheerful
    "menu": "#e3f2fd",          # Light Blue - not faded
    "typing": "#f3e5f5",        # Light Purple
    "spellcheck": "#fff3e0",    # Light Orange
    "math": "#e8f5e8",          # Light Green
    "dictation": "#fce4ec",     # Light Pink
    "readwords": "#e0f2f1",     # Light Teal
    "admin": "#f1f8e9",         # Light Lime
    "result": "#fff8e1",        # Light Amber
}

# ===== IMPROVED INDIAN ENGLISH TTS SETUP =====
class IndianEnglishTTS:
    def __init__(self):
        self.sound_initialized = False
        try:
            pygame.mixer.pre_init(frequency=22050, size=-16, channels=2, buffer=512)
            pygame.mixer.init()
            self.sound_initialized = True
        except:
            print("Warning: Pygame mixer initialization failed")
        
        self.is_speaking = False
        self.tts_enabled = True
    
    def speak(self, text, wait_for_completion=True, repeat=1):
        """Speak text with Indian English accent - improved version"""
        if not self.tts_enabled:
            return
            
        def _speak_internal():
            try:
                for i in range(repeat):
                    if i > 0:  # Add pause between repetitions
                        time.sleep(0.8)
                    
                    self.is_speaking = True
                    print(f"Speaking: {text}")  # Debug print
                    
                    # Create gTTS object with Indian English
                    tts = gTTS(text=text, lang='en', tld='co.in', slow=False)
                    
                    # Save to temporary file
                    with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as tmp_file:
                        tts.save(tmp_file.name)
                        tmp_filename = tmp_file.name
                    
                    try:
                        if self.sound_initialized:
                            # Stop any currently playing sound first
                            pygame.mixer.music.stop()
                            
                            pygame.mixer.music.load(tmp_filename)
                            pygame.mixer.music.play()
                            
                            # Wait for playback to complete
                            while pygame.mixer.music.get_busy():
                                pygame.time.wait(100)
                    finally:
                        # Clean up temporary file
                        try:
                            os.unlink(tmp_filename)
                        except:
                            pass
                        
            except Exception as e:
                print(f"TTS Error: {e}")
            finally:
                self.is_speaking = False
        
        # Stop any current speech first
        self.stop()
        
        if wait_for_completion:
            _speak_internal()
        else:
            # Run in thread for non-blocking speech
            thread = threading.Thread(target=_speak_internal, daemon=True)
            thread.start()
    
    def stop(self):
        """Stop any ongoing speech"""
        try:
            if self.sound_initialized:
                pygame.mixer.music.stop()
            self.is_speaking = False
        except Exception as e:
            print(f"Stop speech error: {e}")

# Initialize global TTS engine
tts_engine = IndianEnglishTTS()

def speak_indian(text, wait=True, repeat=1):
    """Speak English text with Indian accent"""
    if text and text.strip():  # Only speak if text is not empty
        tts_engine.speak(text, wait_for_completion=wait, repeat=repeat)

def stop_speech():
    """Stop any ongoing speech"""
    tts_engine.stop()

# ============================================
class GameMaxApp(tk.Tk):
    def __init__(self):
        super().__init__()
        
        # Cross-platform DPI awareness
        try:
            if platform.system() == "Windows":
                from ctypes import windll
                windll.shcore.SetProcessDpiAwareness(1)
        except:
            pass
        
        self.title("GameMax Kids Learning Adventure - By Augustine Anbananthan")
        self.state('zoomed')
        self.geometry("800x600")
        self.configure(bg=COLOR_PALETTE["welcome"])
        
        self.speech_enabled = True
        
        # Enhanced sound initialization
        try:
            pygame.mixer.pre_init(frequency=22050, size=-16, channels=2, buffer=512)
            pygame.mixer.init()
            self.sound_enabled = True
            print("Sound system initialized successfully")
            self.create_default_sounds()
        except pygame.error as e:
            print(f"Warning: Pygame sound mixer failed to initialize: {e}")
            self.sound_enabled = False
        
        self.child_name = "Child"  # Default name
        self.init_database()
        self.update_global_words()
        
        # Enhanced style configuration
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure("TButton", font=("Arial", 20, "bold"), padding=10)
        self.style.configure("TRadiobutton", font=("Arial", 24))
        self.style.configure("TEntry", font=("Arial", 24))
        self.style.configure("TLabel", font=("Arial", 30, "bold"))
        
        # Start with welcome screen (no login required)
        self.show_welcome()
    
    def create_default_sounds(self):
        """Create simple beep sounds if sound files don't exist"""
        if not os.path.exists("success.wav"):
            self.create_beep_sound("success.wav", 800, 0.2)
        
        if not os.path.exists("wrong.wav"):
            self.create_beep_sound("wrong.wav", 400, 0.3)
        
        if not os.path.exists("result.wav"):
            self.create_beep_sound("result.wav", 600, 0.4)
    
    def create_beep_sound(self, filename, frequency, duration):
        """Create a simple beep sound using pygame"""
        try:
            sample_rate = 22050
            frames = int(duration * sample_rate)
            arr = np.zeros((frames, 2))
            
            for i in range(frames):
                wave = np.sin(2 * np.pi * frequency * i / sample_rate)
                arr[i] = [wave, wave]
            
            arr = (arr * 32767).astype(np.int16)
            
            # Create a simple WAV file header and data
            with open(filename, 'wb') as f:
                # WAV header
                f.write(b'RIFF')
                f.write((36 + len(arr.tobytes())).to_bytes(4, 'little'))
                f.write(b'WAVEfmt ')
                f.write((16).to_bytes(4, 'little'))  # Chunk size
                f.write((1).to_bytes(2, 'little'))   # Audio format
                f.write((2).to_bytes(2, 'little'))   # Number of channels
                f.write((sample_rate).to_bytes(4, 'little'))  # Sample rate
                f.write((sample_rate * 4).to_bytes(4, 'little'))  # Byte rate
                f.write((4).to_bytes(2, 'little'))   # Block align
                f.write((16).to_bytes(2, 'little'))  # Bits per sample
                f.write(b'data')
                f.write((len(arr.tobytes())).to_bytes(4, 'little'))
                f.write(arr.tobytes())
        except Exception as e:
            print(f"Error creating sound file {filename}: {e}")
            # Create a silent file as fallback
            with open(filename, 'wb') as f:
                f.write(b'RIFF$\x00\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x01\x00D\xac\x00\x00\x88X\x01\x00\x02\x00\x10\x00data\x00\x00\x00\x00')
    
    def play_sound(self, sound_file):
        """Play sound with better error handling"""
        if self.sound_enabled:
            try:
                def run_sound():
                    if os.path.exists(sound_file):
                        pygame.mixer.music.load(sound_file)
                        pygame.mixer.music.play()
                        print(f"Playing sound: {sound_file}")
                    else:
                        print(f"Sound file not found: {sound_file}")
                        # Create a simple beep if file doesn't exist
                        frequency = 600 if 'success' in sound_file else 400
                        self.create_beep_sound(sound_file, frequency, 0.2)
                        if os.path.exists(sound_file):
                            pygame.mixer.music.load(sound_file)
                            pygame.mixer.music.play()
                
                threading.Thread(target=run_sound, daemon=True).start()
            except (pygame.error, FileNotFoundError) as e:
                print(f"Sound error: {e}")
    
    def speak(self, text, block=False, repeat=1):
        """Speak text with Indian English TTS"""
        if not self.speech_enabled:
            return
        
        speak_indian(text, wait=block, repeat=repeat)
    
    def show_time_date(self, parent_frame):
        """Show British time and date in corners - FIXED positioning"""
        def update_time():
            current_time = datetime.now().strftime("%H:%M:%S")
            current_date = datetime.now().strftime("%d/%m/%Y")
            
            # Top right corner - FIXED positioning to avoid overlap
            time_label.config(text=f"{current_date} {current_time}")
            
            # Schedule next update
            parent_frame.after(1000, update_time)
        
        # Top right corner time/date - positioned to avoid credit overlap
        time_label = tk.Label(parent_frame, text="", font=("Arial", 12),
                             bg=COLOR_PALETTE["welcome"], fg="#333333", relief="raised", bd=2,
                             padx=10, pady=5)
        time_label.place(relx=1.0, rely=0, anchor="ne", x=-10, y=10)
        
        update_time()
    
    def show_welcome(self):
        """Welcome screen - colorful and full window usage"""
        self.clear_window()
        self.configure(bg=COLOR_PALETTE["welcome"])
        
        # Main frame with padding
        main_frame = tk.Frame(self, bg=COLOR_PALETTE["welcome"])
        main_frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        
        # Title with gradient-like effect using multiple colors
        title_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["welcome"])
        title_frame.pack(pady=30)
        
        tk.Label(title_frame, text="🌟 Welcome to GameMax Adventure! 🌟", 
                font=("Arial", 48, "bold"), bg=COLOR_PALETTE["welcome"], 
                fg="#ff6b35").pack()
        
        tk.Label(title_frame, text="By Augustine Anbananthan", 
                font=("Arial", 18, "italic"), bg=COLOR_PALETTE["welcome"], 
                fg="#333333").pack(pady=10)
        
        # Decorative frame for name entry
        name_frame = tk.LabelFrame(main_frame, text="Enter Your Name", 
                                  font=("Arial", 24, "bold"),
                                  bg=COLOR_PALETTE["welcome"], fg="#8b4513",
                                  relief="groove", bd=5)
        name_frame.pack(pady=40, padx=50, fill="x")
        
        tk.Label(name_frame, text="What's your name?", font=("Arial", 28, "bold"),
                bg=COLOR_PALETTE["welcome"], fg="#006400").pack(pady=20)
        
        self.name_entry = ttk.Entry(name_frame, font=("Arial", 30), width=25)
        self.name_entry.pack(pady=20)
        self.name_entry.focus()
        
        # Fun buttons frame
        button_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["welcome"])
        button_frame.pack(pady=30)
        
        # Start button with fun styling
        start_btn = tk.Button(button_frame, text="🚀 START LEARNING! 🚀", 
                             font=("Arial", 32, "bold"), bg="#4CAF50", fg="white",
                             relief="raised", bd=5, command=self.start_learning,
                             cursor="hand2", width=20, height=2)
        start_btn.pack(pady=10)
        
        # Quit button
        quit_btn = tk.Button(button_frame, text="❌ Quit", 
                            font=("Arial", 24, "bold"), bg="#f44336", fg="white",
                            relief="raised", bd=5, command=self.quit_app,
                            cursor="hand2", width=15, height=2)
        quit_btn.pack(pady=10)
        
        # Show time and date - PASS THE CORRECT FRAME
        self.show_time_date(main_frame)
        
        # Bind Enter key to start
        self.bind('<Return>', lambda e: self.start_learning())
    
    def start_learning(self):
        """Start the learning journey"""
        name = self.name_entry.get().strip()
        if name:
            self.child_name = name.title()
        else:
            self.child_name = "Learner"
        
        self.show_menu()
    
    def show_menu(self):
        """Main menu screen with enhanced colors - FIXED fading issue"""
        self.clear_window()
        self.configure(bg=COLOR_PALETTE["menu"])
        
        # Main frame with proper background
        main_frame = tk.Frame(self, bg=COLOR_PALETTE["menu"])
        main_frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        
        # Welcome message with bright colors
        welcome_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["menu"])
        welcome_frame.pack(pady=20)
        
        tk.Label(welcome_frame, text=f"Hello {self.child_name}! 🎉", 
                font=("Arial", 42, "bold"), bg=COLOR_PALETTE["menu"],
                fg="#1976d2").pack()
        
        tk.Label(welcome_frame, text="Choose your learning adventure:", 
                font=("Arial", 24, "bold"), bg=COLOR_PALETTE["menu"],
                fg="#333333").pack(pady=10)
        
        # Menu buttons in a grid with bright colors
        menu_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["menu"])
        menu_frame.pack(pady=30, expand=True)
        
        # Create colorful buttons with better styling
        buttons_info = [
            ("⌨️ Typing Practice", "#8e24aa", self.show_typing),
            ("📝 Spell Check Quiz", "#fb8c00", self.show_spell_check),
            ("🔢 Math Quiz", "#43a047", self.show_math_quiz),
            ("👂 Dictation Exercise", "#e91e63", self.show_dictation),
            ("📖 Read Words", "#0097a7", self.show_read_words),
            ("⚙️ Admin Panel", "#689f38", self.show_admin),
        ]
        
        for i, (text, color, command) in enumerate(buttons_info):
            btn = tk.Button(menu_frame, text=text, font=("Arial", 22, "bold"),
                           bg=color, fg="white", relief="raised", bd=5,
                           command=command, cursor="hand2", width=18, height=2,
                           activebackground=color, activeforeground="white")
            btn.grid(row=i//2, column=i%2, padx=15, pady=15, sticky="ew")
        
        # Configure grid weights for responsive layout
        menu_frame.grid_columnconfigure(0, weight=1)
        menu_frame.grid_columnconfigure(1, weight=1)
        
        # Bottom frame with proper styling - FIXED positioning
        bottom_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["menu"])
        bottom_frame.pack(side=tk.BOTTOM, pady=20, fill=tk.X)
        
        # Credit positioned at bottom left, not overlapping
        tk.Label(bottom_frame, text="Developed by Augustine Anbananthan", 
                font=("Arial", 14, "italic"), bg=COLOR_PALETTE["menu"],
                fg="#666666").pack(side=tk.LEFT, padx=20)
        
        quit_btn = tk.Button(bottom_frame, text="🚪 Quit", 
                            font=("Arial", 20, "bold"), bg="#ff5722", fg="white",
                            relief="raised", bd=5, command=self.quit_app,
                            cursor="hand2", width=12, height=2,
                            activebackground="#ff5722", activeforeground="white")
        quit_btn.pack(side=tk.RIGHT, padx=20)
        
        # Show time and date
        self.show_time_date(main_frame)
    
    def quit_app(self):
        """Quit with nice goodbye message - FIXED to actually quit"""
        try:
            self.play_sound("result.wav")
            # Give a moment for sound to play
            self.after(1000, self._actually_quit)
            
            # Show goodbye message
            self.speak(f"Goodbye {self.child_name}! Hope you had a nice time. See you again!", wait=True, repeat=1)
            
            messagebox.showinfo("Goodbye!", 
                               f"Thank you {self.child_name}!\n\nHope you had a nice time.\nGood bye! See you again! 👋")
        except:
            pass
        
        self._actually_quit()
    
    def _actually_quit(self):
        """Actually quit the application"""
        try:
            self.quit()
            self.destroy()
        except:
            pass
    
    def clear_window(self):
        """Clear all widgets from the window"""
        for widget in self.winfo_children():
            widget.destroy()
    
    def init_database(self):
        """Initialize database with only words table"""
        conn = sqlite3.connect("learning.db")
        c = conn.cursor()
        
        # Only words table now - no user/progress tables needed
        c.execute("""CREATE TABLE IF NOT EXISTS words (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        word TEXT UNIQUE NOT NULL
                     )""")
        
        # Insert default words
        default_words = [
            "cat", "dog", "mom", "dad", "ball", "apple", "book", "sun", "tree", "milk",
            "cup", "car", "house", "pen", "bird", "fish", "hat", "shoe", "door", "bed",
            "run", "jump", "play", "love", "happy", "water", "food", "home", "school", "friend",
            "nice", "good", "big", "small", "red", "blue", "green", "yellow", "white", "black"
        ]
        
        c.execute("SELECT COUNT(*) FROM words")
        if c.fetchone()[0] == 0:
            for word in default_words:
                try:
                    c.execute("INSERT INTO words (word) VALUES (?)", (word,))
                except sqlite3.IntegrityError:
                    pass
            conn.commit()
        
        conn.close()
    
    def update_global_words(self):
        """Update the GLOBAL_WORDS list from the database"""
        global GLOBAL_WORDS
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("SELECT word FROM words ORDER BY word")
            GLOBAL_WORDS = [row[0] for row in c.fetchall()]
            conn.close()
            print(f"Loaded {len(GLOBAL_WORDS)} words from database")
        except sqlite3.Error as e:
            print(f"Database error loading global words: {e}")
            GLOBAL_WORDS = []
    
    def show_typing(self):
        """Typing practice screen"""
        TypingPractice(self)
    
    def show_spell_check(self):
        """Spell check quiz screen"""
        SpellCheckQuiz(self)
    
    def show_math_quiz(self):
        """Math quiz screen"""
        MathQuiz(self)
    
    def show_dictation(self):
        """Dictation exercise screen"""
        DictationExercise(self)
    
    def show_read_words(self):
        """Read words screen"""
        ReadWords(self)
    
    def show_admin(self):
        """Admin panel"""
        AdminPanel(self)


# ============================================
# Typing Practice Screen - Enhanced with Virtual Keyboard and Letter Highlighting
# ============================================
class TypingPractice:
    def __init__(self, app):
        self.app = app
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["typing"])
        
        self.score = 0
        self.total_words = 10
        self.current_word_index = 0
        self.current_word = ""
        self.current_letter_index = 0
        self.key_buttons = {}
        
        if len(GLOBAL_WORDS) < self.total_words:
            messagebox.showwarning("Warning", "Not enough words in database. Please add more words.")
            self.app.show_menu()
            return
        
        self.words = random.sample(GLOBAL_WORDS, self.total_words)
        
        self.setup_ui()
        self.next_word()
    
    def setup_ui(self):
        """Setup typing practice UI with LARGER virtual keyboard and letter highlighting"""
        main_frame = tk.Frame(self.app, bg=COLOR_PALETTE["typing"])
        main_frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        
        # Header with developer credit - FIXED positioning
        header_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["typing"])
        header_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(header_frame, text="⌨️ Typing Practice", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["typing"], fg="#6a1b9a").pack(side=tk.LEFT)
        
        tk.Label(header_frame, text="By Augustine Anbananthan", font=("Arial", 12),
                bg=COLOR_PALETTE["typing"], fg="#666666").pack(side=tk.RIGHT)
        
        # Main content frame
        content_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["typing"])
        content_frame.pack(expand=True, fill=tk.BOTH, pady=20)
        
        # Word display with highlighting
        word_frame = tk.Frame(content_frame, bg=COLOR_PALETTE["typing"])
        word_frame.pack(pady=20)
        
        tk.Label(word_frame, text="Type this word:", font=("Arial", 24, "bold"),
                bg=COLOR_PALETTE["typing"]).pack(pady=10)
        
        self.word_label = tk.Label(word_frame, text="", font=("Arial", 70, "bold"),
                                   bg=COLOR_PALETTE["typing"], fg="#1565c0")
        self.word_label.pack(pady=20)
        
        # Input frame
        input_frame = tk.Frame(content_frame, bg=COLOR_PALETTE["typing"])
        input_frame.pack(pady=20)
        
        tk.Label(input_frame, text="Type here:", font=("Arial", 24, "bold"),
                bg=COLOR_PALETTE["typing"]).pack()
        
        self.entry = ttk.Entry(input_frame, font=("Arial", 32), width=25)
        self.entry.pack(pady=15)
        self.entry.focus()
        
        # Keyboard shortcut bindings - FIXED Enter key handling
        self.entry.bind("<Return>", lambda e: self.check_word())
        self.entry.bind("<Tab>", lambda e: self.check_word())
        self.entry.bind("<space>", lambda e: self.check_word())
        self.entry.bind("<Key>", self.on_key_press)
        
        # Button frame
        button_frame = tk.Frame(content_frame, bg=COLOR_PALETTE["typing"])
        button_frame.pack(pady=20)
        
        submit_btn = tk.Button(button_frame, text="✅ Submit", font=("Arial", 20, "bold"),
                              bg="#4CAF50", fg="white", command=self.check_word, width=12)
        submit_btn.pack(side=tk.LEFT, padx=10)
        
        quit_btn = tk.Button(button_frame, text="🚪 Quit", font=("Arial", 20, "bold"),
                            bg="#ff5722", fg="white", command=self.back_to_menu, width=12)
        quit_btn.pack(side=tk.LEFT, padx=10)
        
        self.score_label = tk.Label(content_frame, text=f"Score: {self.score}/{self.total_words}",
                                    font=("Arial", 24, "bold"), bg=COLOR_PALETTE["typing"], fg="#d32f2f")
        self.score_label.pack(pady=15)
        
        # LARGER Virtual Keyboard display
        keyboard_frame = tk.LabelFrame(content_frame, text="Virtual Keyboard", font=("Arial", 16, "bold"),
                                      bg=COLOR_PALETTE["typing"], fg="#6a1b9a")
        keyboard_frame.pack(pady=20, fill=tk.X)
        
        self.setup_large_virtual_keyboard(keyboard_frame)
        
        # Show time and date
        self.app.show_time_date(main_frame)
    
    def setup_large_virtual_keyboard(self, parent):
        """Setup LARGER virtual keyboard display with letter highlighting"""
        # Keyboard layout
        rows = [
            "qwertyuiop",
            "asdfghjkl",
            "zxcvbnm"
        ]
        
        self.key_buttons = {}
        
        for row_idx, row in enumerate(rows):
            row_frame = tk.Frame(parent, bg=COLOR_PALETTE["typing"])
            row_frame.pack(pady=8)
            
            # Add spacing for QWERTY layout
            if row_idx == 0:
                tk.Frame(row_frame, width=40, bg=COLOR_PALETTE["typing"]).pack(side=tk.LEFT)
            elif row_idx == 1:
                tk.Frame(row_frame, width=55, bg=COLOR_PALETTE["typing"]).pack(side=tk.LEFT)
            elif row_idx == 2:
                tk.Frame(row_frame, width=70, bg=COLOR_PALETTE["typing"]).pack(side=tk.LEFT)
            
            for char in row:
                btn = tk.Label(row_frame, text=char.upper(), font=("Arial", 20, "bold"),  # LARGER font
                              width=5, height=3, relief="raised", borderwidth=3,  # LARGER keys
                              bg="lightgray", fg="black", cursor="hand2")
                btn.pack(side=tk.LEFT, padx=3, pady=3)  # MORE spacing
                self.key_buttons[char] = btn
    
    def highlight_next_letter(self):
        """Highlight the NEXT letter to be typed"""
        if not self.current_word:
            return
        
        # Reset all keys to default
        for key_btn in self.key_buttons.values():
            key_btn.config(bg="lightgray", fg="black")
        
        # Highlight the NEXT letter to type (BEFORE it's typed)
        if self.current_letter_index < len(self.current_word):
            next_char = self.current_word[self.current_letter_index].lower()
            if next_char in self.key_buttons:
                self.key_buttons[next_char].config(bg="#ffeb3b", fg="black")  # Yellow highlight
        
        # Schedule next highlight update
        self.app.after(200, self.highlight_next_letter)
    
    def on_key_press(self, event):
        """Handle key press and update highlighting - FIXED double letter issue"""
        if event.char and event.char.lower() == self.current_word.lower()[self.current_letter_index:self.current_letter_index+1]:
            # Correct key pressed - move to next letter
            self.current_letter_index += 1
            if self.current_letter_index >= len(self.current_word):
                # Word complete, auto-fill
                self.entry.delete(0, tk.END)
                self.entry.insert(0, self.current_word)
                # Reset highlighting
                for key_btn in self.key_buttons.values():
                    key_btn.config(bg="lightgray", fg="black")
                self.word_label.config(text=self.current_word)
    
    def next_word(self):
        """Display next word with enhanced speech and keyboard highlighting"""
        if self.current_word_index < self.total_words:
            self.current_word = self.words[self.current_word_index]
            self.current_letter_index = 0
            
            # Start letter highlighting for NEXT letter
            self.highlight_next_letter()
            
            # Show the word first
            self.word_label.config(text=self.current_word)
            
            # Speak the word twice for clarity
            self.app.speak(f"Type the word: {self.current_word}", wait=False, repeat=2)
            
            self.entry.delete(0, tk.END)
            self.entry.focus()
        else:
            self.show_result()
    
    def check_word(self):
        """Check typed word with enhanced feedback - FIXED advancement"""
        typed_word = self.entry.get().strip().lower()
        
        if typed_word == self.current_word.lower():
            self.score += 1
            self.app.play_sound("success.wav")
            self.app.speak("Excellent! Correct!", wait=False)
        else:
            self.app.play_sound("wrong.wav")
            self.app.speak(f"Oops! The correct word is {self.current_word}", wait=False)
        
        self.score_label.config(text=f"Score: {self.score}/{self.total_words}")
        
        # Move to next word with delay
        self.current_word_index += 1
        self.app.after(2000, self.next_word)
    
    def show_result(self):
        """Display final result with enhanced celebration"""
        self.app.play_sound("result.wav")
        percentage = (self.score / self.total_words) * 100
        
        result_text = f"🎉 Typing Complete! 🎉\n\nYour Score: {self.score}/{self.total_words}\nPercentage: {percentage:.0f}%"
        
        if percentage >= 90:
            feedback = "🌟 Amazing typing skills! 🌟"
            color = "#4CAF50"
        elif percentage >= 70:
            feedback = "👏 Great job! Keep practicing! 👏"
            color = "#2196F3"
        elif percentage >= 50:
            feedback = "👍 Good effort! You're improving! 👍"
            color = "#FF9800"
        else:
            feedback = "💪 Keep practicing! You can do it! 💪"
            color = "#f44336"
        
        # Enhanced result window
        result_window = tk.Toplevel(self.app)
        result_window.title("Typing Results")
        result_window.geometry("600x400")
        result_window.configure(bg=COLOR_PALETTE["result"])
        result_window.grab_set()  # Modal window
        
        # Center the result window
        result_window.transient(self.app)
        result_window.geometry("+%d+%d" % (self.app.winfo_rootx() + 100, self.app.winfo_rooty() + 100))
        
        tk.Label(result_window, text="🌟 Typing Results 🌟", font=("Arial", 32, "bold"),
                bg=COLOR_PALETTE["result"], fg=color).pack(pady=30)
        
        tk.Label(result_window, text=result_text, font=("Arial", 20),
                bg=COLOR_PALETTE["result"]).pack(pady=20)
        
        tk.Label(result_window, text=feedback, font=("Arial", 24, "bold"),
                bg=COLOR_PALETTE["result"], fg=color).pack(pady=20)
        
        tk.Label(result_window, text=f"Great work {self.app.child_name}!", 
                font=("Arial", 18), bg=COLOR_PALETTE["result"], fg="#666666").pack(pady=10)
        
        close_btn = tk.Button(result_window, text="🎊 Continue", font=("Arial", 20, "bold"),
                             bg="#4CAF50", fg="white", command=result_window.destroy, width=15)
        close_btn.pack(pady=20)
        
        self.app.speak(f"{result_text} {feedback}", wait=False)
    
    def back_to_menu(self):
        """Return to main menu"""
        self.app.show_menu()


# ============================================
# Spell Check Quiz Screen - Enhanced with Full Keyboard Support
# ============================================
class SpellCheckQuiz:
    def __init__(self, app):
        self.app = app
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["spellcheck"])
        
        self.score = 0
        self.total_questions = 10
        self.current_question = 0
        
        if len(GLOBAL_WORDS) < self.total_questions:
            messagebox.showwarning("Warning", "Not enough words in database.")
            self.app.show_menu()
            return
        
        self.words = random.sample(GLOBAL_WORDS, self.total_questions)
        
        self.setup_ui()
        self.next_question()
    
    def setup_ui(self):
        """Setup spell check UI with enhanced keyboard support"""
        main_frame = tk.Frame(self.app, bg=COLOR_PALETTE["spellcheck"])
        main_frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        
        # Header
        header_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["spellcheck"])
        header_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(header_frame, text="📝 Spell Check Quiz", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["spellcheck"], fg="#e65100").pack(side=tk.LEFT)
        
        tk.Label(header_frame, text="By Augustine Anbananthan", font=("Arial", 12),
                bg=COLOR_PALETTE["spellcheck"], fg="#666666").pack(side=tk.RIGHT)
        
        # Question frame
        question_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["spellcheck"])
        question_frame.pack(pady=30)
        
        self.question_label = tk.Label(question_frame, text="", font=("Arial", 28, "bold"),
                                       bg=COLOR_PALETTE["spellcheck"], fg="#bf360c")
        self.question_label.pack(pady=20)
        
        self.word_display = tk.Label(question_frame, text="", font=("Arial", 60, "bold"),
                                     bg=COLOR_PALETTE["spellcheck"], fg="#1565c0")
        self.word_display.pack(pady=20)
        
        # Options frame with enhanced styling
        self.radio_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["spellcheck"])
        self.radio_frame.pack(pady=20)
        
        self.var = tk.IntVar()
        self.radio_buttons = []
        self.option_entries = []
        
        for i in range(4):
            option_frame = tk.Frame(self.radio_frame, bg=COLOR_PALETTE["spellcheck"])
            option_frame.pack(pady=10, fill=tk.X)
            
            rb = tk.Radiobutton(option_frame, text=f"Option {i+1}", variable=self.var, value=i,
                              font=("Arial", 20, "bold"), bg=COLOR_PALETTE["spellcheck"],
                              fg="#333333", selectcolor="#fff3e0", indicatoron=0,
                              relief="raised", bd=3, width=15, height=2)
            rb.pack(side=tk.LEFT, padx=10)
            
            entry = tk.Entry(option_frame, font=("Arial", 18), width=20, state='readonly',
                           bg="#f5f5f5", relief="sunken", bd=2)
            entry.pack(side=tk.LEFT, padx=10)
            
            # Enhanced keyboard shortcuts - FIXED advancement
            entry.bind("<Return>", lambda e, idx=i: self.check_answer(idx))
            entry.bind("<Tab>", lambda e, idx=i: self.check_answer(idx))
            entry.bind("<space>", lambda e, idx=i: self.check_answer(idx))
            
            self.radio_buttons.append(rb)
            self.option_entries.append(entry)
        
        # Button frame
        button_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["spellcheck"])
        button_frame.pack(pady=20)
        
        submit_btn = tk.Button(button_frame, text="✅ Submit", font=("Arial", 20, "bold"),
                              bg="#4CAF50", fg="white", command=self.check_answer, width=12)
        submit_btn.pack(side=tk.LEFT, padx=10)
        
        quit_btn = tk.Button(button_frame, text="🚪 Quit", font=("Arial", 20, "bold"),
                            bg="#ff5722", fg="white", command=self.back_to_menu, width=12)
        quit_btn.pack(side=tk.LEFT, padx=10)
        
        self.score_label = tk.Label(main_frame, text=f"Score: {self.score}/{self.total_questions}",
                                    font=("Arial", 24, "bold"), bg=COLOR_PALETTE["spellcheck"], fg="#d32f2f")
        self.score_label.pack(pady=15)
        
        # Show time and date
        self.app.show_time_date(main_frame)
        
        # Bind global keyboard shortcuts for full keyboard navigation - FIXED advancement
        self.app.bind('<Return>', lambda e: self.check_answer())
        self.app.bind('<Tab>', lambda e: self.check_answer())
        self.app.bind('<space>', lambda e: self.check_answer())
    
    def next_question(self):
        """Display next question with enhanced speech"""
        if self.current_question < self.total_questions:
            self.current_word = self.words[self.current_question]
            self.question_label.config(text=f"Question {self.current_question + 1}: Which spelling is correct?")
            self.word_display.config(text=f"Word: {self.current_word}")
            
            # Create options
            options = [self.current_word]
            options.extend(self.create_wrong_spellings(self.current_word, 3))
            random.shuffle(options)
            
            # Update radio buttons and entries
            for i, (rb, entry) in enumerate(zip(self.radio_buttons, self.option_entries)):
                rb.config(text=f"Option {i+1}")
                entry.config(state='normal')
                entry.delete(0, tk.END)
                entry.insert(0, options[i])
                entry.config(state='readonly')
            
            self.var.set(-1)  # Clear selection
            
            # Focus on first option
            self.option_entries[0].focus()
            
            # Speak the word twice for clarity
            self.app.speak(f"Which spelling is correct for the word {self.current_word}?", wait=False, repeat=2)
        else:
            self.show_result()
    
    def create_wrong_spellings(self, word, count):
        """Create incorrect spellings"""
        wrong = []
        for _ in range(count):
            if len(word) > 2:
                modification = random.choice(['swap', 'replace', 'double'])
                if modification == 'swap' and len(word) > 3:
                    idx = random.randint(0, len(word) - 2)
                    wrong_word = list(word)
                    wrong_word[idx], wrong_word[idx + 1] = wrong_word[idx + 1], wrong_word[idx]
                    wrong.append(''.join(wrong_word))
                elif modification == 'replace':
                    idx = random.randint(0, len(word) - 1)
                    wrong_word = list(word)
                    wrong_word[idx] = random.choice('abcdefghijklmnopqrstuvwxyz')
                    wrong.append(''.join(wrong_word))
                else:  # double
                    idx = random.randint(0, len(word) - 1)
                    wrong_word = list(word)
                    wrong_word.insert(idx, word[idx])
                    wrong.append(''.join(wrong_word))
            else:
                wrong.append(word + random.choice('xyz'))
        
        return wrong[:count]
    
    def check_answer(self, selected_index=None):
        """Check selected answer with enhanced feedback - FIXED advancement"""
        if selected_index is None:
            selected_index = self.var.get()
        
        if selected_index == -1:
            messagebox.showwarning("Warning", "Please select an option!")
            self.option_entries[0].focus()
            return
        
        # Find the correct option
        correct_option = None
        for i, entry in enumerate(self.option_entries):
            if entry.get() == self.current_word:
                correct_option = i
                break
        
        if selected_index == correct_option:
            self.score += 1
            self.app.play_sound("success.wav")
            self.app.speak("Excellent! Correct!", wait=False)
        else:
            self.app.play_sound("wrong.wav")
            self.app.speak(f"Oops! The correct spelling is {self.current_word}", wait=False)
        
        self.score_label.config(text=f"Score: {self.score}/{self.total_questions}")
        self.current_question += 1
        
        # Move to next question with delay
        self.app.after(2000, self.next_question)
    
    def show_result(self):
        """Display final result"""
        self.app.play_sound("result.wav")
        percentage = (self.score / self.total_questions) * 100
        
        result_text = f"🎯 Spell Check Complete! 🎯\n\nYour Score: {self.score}/{self.total_questions}\nPercentage: {percentage:.0f}%"
        
        if percentage >= 90:
            feedback = "🏆 Spelling Champion! 🏆"
            color = "#4CAF50"
        elif percentage >= 70:
            feedback = "⭐ Great spelling skills! ⭐"
            color = "#2196F3"
        elif percentage >= 50:
            feedback = "👍 Good job! Keep practicing! 👍"
            color = "#FF9800"
        else:
            feedback = "💪 Keep studying spelling! 💪"
            color = "#f44336"
        
        # Enhanced result window
        result_window = tk.Toplevel(self.app)
        result_window.title("Spell Check Results")
        result_window.geometry("600x400")
        result_window.configure(bg=COLOR_PALETTE["result"])
        result_window.grab_set()
        result_window.transient(self.app)
        result_window.geometry("+%d+%d" % (self.app.winfo_rootx() + 100, self.app.winfo_rooty() + 100))
        
        tk.Label(result_window, text="🌟 Spell Check Results 🌟", font=("Arial", 32, "bold"),
                bg=COLOR_PALETTE["result"], fg=color).pack(pady=30)
        
        tk.Label(result_window, text=result_text, font=("Arial", 20),
                bg=COLOR_PALETTE["result"]).pack(pady=20)
        
        tk.Label(result_window, text=feedback, font=("Arial", 24, "bold"),
                bg=COLOR_PALETTE["result"], fg=color).pack(pady=20)
        
        tk.Label(result_window, text=f"Excellent work {self.app.child_name}!", 
                font=("Arial", 18), bg=COLOR_PALETTE["result"], fg="#666666").pack(pady=10)
        
        close_btn = tk.Button(result_window, text="🎊 Continue", font=("Arial", 20, "bold"),
                             bg="#4CAF50", fg="white", command=result_window.destroy, width=15)
        close_btn.pack(pady=20)
        
        self.app.speak(f"{result_text} {feedback}", wait=False)
    
    def back_to_menu(self):
        """Return to main menu"""
        self.app.show_menu()


# ============================================
# Math Quiz Screen - Enhanced with Better Sound
# ============================================
class MathQuiz:
    def __init__(self, app):
        self.app = app
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["math"])
        
        self.score = 0
        self.total_questions = 10
        self.current_question = 0
        
        self.setup_ui()
        self.next_question()
    
    def setup_ui(self):
        """Setup math quiz UI with enhanced features"""
        main_frame = tk.Frame(self.app, bg=COLOR_PALETTE["math"])
        main_frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        
        # Header
        header_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["math"])
        header_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(header_frame, text="🔢 Math Quiz", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["math"], fg="#2e7d32").pack(side=tk.LEFT)
        
        tk.Label(header_frame, text="By Augustine Anbananthan", font=("Arial", 12),
                bg=COLOR_PALETTE["math"], fg="#666666").pack(side=tk.RIGHT)
        
        # Question frame
        question_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["math"])
        question_frame.pack(expand=True, pady=30)
        
        self.question_label = tk.Label(question_frame, text="", font=("Arial", 60, "bold"),
                                       bg=COLOR_PALETTE["math"], fg="#1565c0")
        self.question_label.pack(pady=40)
        
        tk.Label(question_frame, text="Enter your answer:", font=("Arial", 28, "bold"),
                bg=COLOR_PALETTE["math"]).pack(pady=20)
        
        self.entry = ttk.Entry(question_frame, font=("Arial", 40), width=15)
        self.entry.pack(pady=20)
        self.entry.bind("<Return>", lambda e: self.check_answer())
        self.entry.bind("<Tab>", lambda e: self.check_answer())
        self.entry.bind("<space>", lambda e: self.check_answer())
        self.entry.focus()
        
        # Button frame
        button_frame = tk.Frame(question_frame, bg=COLOR_PALETTE["math"])
        button_frame.pack(pady=30)
        
        submit_btn = tk.Button(button_frame, text="✅ Submit", font=("Arial", 24, "bold"),
                              bg="#4CAF50", fg="white", command=self.check_answer, width=15)
        submit_btn.pack(side=tk.LEFT, padx=15)
        
        quit_btn = tk.Button(button_frame, text="🚪 Quit", font=("Arial", 24, "bold"),
                            bg="#ff5722", fg="white", command=self.back_to_menu, width=15)
        quit_btn.pack(side=tk.LEFT, padx=15)
        
        self.score_label = tk.Label(question_frame, text=f"Score: {self.score}/{self.total_questions}",
                                    font=("Arial", 28, "bold"), bg=COLOR_PALETTE["math"], fg="#d32f2f")
        self.score_label.pack(pady=20)
        
        # Show time and date
        self.app.show_time_date(main_frame)
    
    def next_question(self):
        """Generate and display next question with enhanced speech"""
        if self.current_question < self.total_questions:
            num1 = random.randint(1, 20)
            num2 = random.randint(1, 20)
            operation = random.choice(['+', '-', '*'])
            
            if operation == '+':
                self.answer = num1 + num2
                question_text = f"{num1} + {num2} = ?"
                speak_text = f"What is {num1} plus {num2}?"
            elif operation == '-':
                if num1 < num2:
                    num1, num2 = num2, num1
                self.answer = num1 - num2
                question_text = f"{num1} - {num2} = ?"
                speak_text = f"What is {num1} minus {num2}?"
            else:  # multiplication
                num1 = random.randint(1, 10)
                num2 = random.randint(1, 10)
                self.answer = num1 * num2
                question_text = f"{num1} × {num2} = ?"
                speak_text = f"What is {num1} times {num2}?"
            
            self.question_label.config(text=question_text)
            
            # Speak the question clearly and twice
            self.app.speak(speak_text, wait=False, repeat=2)
            
            self.entry.delete(0, tk.END)
            self.entry.focus()
        else:
            self.show_result()
    
    def check_answer(self):
        """Check the answer with enhanced feedback - FIXED advancement"""
        try:
            user_answer = int(self.entry.get().strip())
            
            if user_answer == self.answer:
                self.score += 1
                self.app.play_sound("success.wav")
                self.app.speak("Excellent! Correct!", wait=False)
            else:
                self.app.play_sound("wrong.wav")
                self.app.speak(f"Oops! The correct answer is {self.answer}", wait=False)
            
            self.score_label.config(text=f"Score: {self.score}/{self.total_questions}")
            self.current_question += 1
            
            # Move to next question with delay
            self.app.after(2000, self.next_question)
        except ValueError:
            self.entry.delete(0, tk.END)
            self.entry.focus()
            self.app.speak("Please enter a valid number!", wait=False)
    
    def show_result(self):
        """Display final result with enhanced celebration"""
        self.app.play_sound("result.wav")
        percentage = (self.score / self.total_questions) * 100
        
        result_text = f"🧮 Math Quiz Complete! 🧮\n\nYour Score: {self.score}/{self.total_questions}\nPercentage: {percentage:.0f}%"
        
        if percentage >= 90:
            feedback = "🧠 Math Wizard! 🧠"
            color = "#4CAF50"
        elif percentage >= 70:
            feedback = "🔢 Great math skills! 🔢"
            color = "#2196F3"
        elif percentage >= 50:
            feedback = "➕ Good effort! Keep practicing! ➕"
            color = "#FF9800"
        else:
            feedback = "🔢 Keep practicing math! 🔢"
            color = "#f44336"
        
        # Enhanced result window
        result_window = tk.Toplevel(self.app)
        result_window.title("Math Quiz Results")
        result_window.geometry("600x400")
        result_window.configure(bg=COLOR_PALETTE["result"])
        result_window.grab_set()
        result_window.transient(self.app)
        result_window.geometry("+%d+%d" % (self.app.winfo_rootx() + 100, self.app.winfo_rooty() + 100))
        
        tk.Label(result_window, text="🌟 Math Quiz Results 🌟", font=("Arial", 32, "bold"),
                bg=COLOR_PALETTE["result"], fg=color).pack(pady=30)
        
        tk.Label(result_window, text=result_text, font=("Arial", 20),
                bg=COLOR_PALETTE["result"]).pack(pady=20)
        
        tk.Label(result_window, text=feedback, font=("Arial", 24, "bold"),
                bg=COLOR_PALETTE["result"], fg=color).pack(pady=20)
        
        tk.Label(result_window, text=f"Well done {self.app.child_name}!", 
                font=("Arial", 18), bg=COLOR_PALETTE["result"], fg="#666666").pack(pady=10)
        
        close_btn = tk.Button(result_window, text="🎊 Continue", font=("Arial", 20, "bold"),
                             bg="#4CAF50", fg="white", command=result_window.destroy, width=15)
        close_btn.pack(pady=20)
        
        self.app.speak(f"{result_text} {feedback}", wait=False)
    
    def back_to_menu(self):
        """Return to main menu"""
        self.app.show_menu()


# ============================================
# Dictation Exercise Screen - Enhanced with Double Reading and Cursor Focus
# ============================================
class DictationExercise:
    def __init__(self, app):
        self.app = app
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["dictation"])
        
        self.score = 0
        self.total_words = 10
        self.current_word_index = 0
        
        if len(GLOBAL_WORDS) < self.total_words:
            messagebox.showwarning("Warning", "Not enough words in database.")
            self.app.show_menu()
            return
        
        self.words = random.sample(GLOBAL_WORDS, self.total_words)
        
        self.setup_ui()
        self.next_word()
    
    def setup_ui(self):
        """Setup dictation UI with enhanced features"""
        main_frame = tk.Frame(self.app, bg=COLOR_PALETTE["dictation"])
        main_frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        
        # Header
        header_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["dictation"])
        header_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(header_frame, text="👂 Dictation Exercise", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["dictation"], fg="#c2185b").pack(side=tk.LEFT)
        
        tk.Label(header_frame, text="By Augustine Anbananthan", font=("Arial", 12),
                bg=COLOR_PALETTE["dictation"], fg="#666666").pack(side=tk.RIGHT)
        
        # Instruction frame
        instruction_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["dictation"])
        instruction_frame.pack(pady=30)
        
        tk.Label(instruction_frame, text="Listen carefully and type the word:", 
                font=("Arial", 28, "bold"), bg=COLOR_PALETTE["dictation"], fg="#7b1fa2").pack(pady=20)
        
        # Word counter
        self.word_counter = tk.Label(instruction_frame, text="", font=("Arial", 20),
                                     bg=COLOR_PALETTE["dictation"], fg="#666666")
        self.word_counter.pack(pady=10)
        
        # Input frame
        input_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["dictation"])
        input_frame.pack(pady=30)
        
        tk.Label(input_frame, text="Type here:", font=("Arial", 24, "bold"),
                bg=COLOR_PALETTE["dictation"]).pack()
        
        self.entry = ttk.Entry(input_frame, font=("Arial", 32), width=25)
        self.entry.pack(pady=20)
        
        # Enhanced keyboard shortcuts
        self.entry.bind("<Return>", lambda e: self.check_word())
        self.entry.bind("<Tab>", lambda e: self.check_word())
        self.entry.bind("<space>", lambda e: self.check_word())
        self.entry.focus()
        
        # Button frame
        button_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["dictation"])
        button_frame.pack(pady=20)
        
        repeat_btn = tk.Button(button_frame, text="🔄 Repeat Word", font=("Arial", 20, "bold"),
                              bg="#9c27b0", fg="white", command=self.repeat_word, width=15)
        repeat_btn.pack(side=tk.LEFT, padx=10)
        
        submit_btn = tk.Button(button_frame, text="✅ Submit", font=("Arial", 20, "bold"),
                              bg="#4CAF50", fg="white", command=self.check_word, width=12)
        submit_btn.pack(side=tk.LEFT, padx=10)
        
        quit_btn = tk.Button(button_frame, text="🚪 Quit", font=("Arial", 20, "bold"),
                            bg="#ff5722", fg="white", command=self.back_to_menu, width=12)
        quit_btn.pack(side=tk.LEFT, padx=10)
        
        self.score_label = tk.Label(main_frame, text=f"Score: {self.score}/{self.total_words}",
                                    font=("Arial", 24, "bold"), bg=COLOR_PALETTE["dictation"], fg="#d32f2f")
        self.score_label.pack(pady=15)
        
        # Show time and date
        self.app.show_time_date(main_frame)
    
    def next_word(self):
        """Speak the next word twice for clarity with cursor focus"""
        if self.current_word_index < self.total_words:
            self.current_word = self.words[self.current_word_index]
            
            # Update word counter
            self.word_counter.config(text=f"Word {self.current_word_index + 1} of {self.total_words}")
            
            # Clear entry and focus immediately
            self.entry.delete(0, tk.END)
            self.entry.focus()
            
            # Speak the word twice after a short delay - FIXED TTS
            def speak_word():
                print(f"Speaking dictation word: {self.current_word}")  # Debug print
                self.app.speak(self.current_word, wait=False, repeat=2)
            
            self.app.after(1000, speak_word)
        else:
            self.show_result()
    
    def repeat_word(self):
        """Repeat the current word twice and move cursor to input"""
        if hasattr(self, 'current_word') and self.current_word:
            stop_speech()
            self.app.after(100, lambda: self.app.speak(self.current_word, wait=False, repeat=2))
            self.entry.focus()  # Ensure cursor is in input field
    
    def check_word(self):
        """Check the typed word with enhanced feedback - FIXED validation"""
        typed_word = self.entry.get().strip().lower()
        
        if not typed_word:
            self.entry.focus()
            return
        
        if typed_word == self.current_word.lower():
            self.score += 1
            self.app.play_sound("success.wav")
            self.app.speak("Excellent! Correct!", wait=False)
            self.score_label.config(text=f"Score: {self.score}/{self.total_words}")
            self.current_word_index += 1
            # Wait before next word
            self.app.after(2000, self.next_word)
        else:
            self.app.play_sound("wrong.wav")
            # Speak the correct word twice for learning
            def speak_correction():
                self.app.speak(f"Oops! The word is {self.current_word}", wait=False, repeat=2)
            self.app.after(1000, speak_correction)
            
            self.entry.delete(0, tk.END)
            self.entry.focus()  # Move cursor back to input
    
    def show_result(self):
        """Display final result"""
        self.app.play_sound("result.wav")
        percentage = (self.score / self.total_words) * 100
        
        result_text = f"📝 Dictation Complete! 📝\n\nYour Score: {self.score}/{self.total_words}\nPercentage: {percentage:.0f}%"
        
        if percentage >= 90:
            feedback = "👂 Listening Champion! 👂"
            color = "#4CAF50"
        elif percentage >= 70:
            feedback = "🎯 Great listening skills! 🎯"
            color = "#2196F3"
        elif percentage >= 50:
            feedback = "👍 Good effort! Keep listening! 👍"
            color = "#FF9800"
        else:
            feedback = "👂 Keep practicing listening! 👂"
            color = "#f44336"
        
        # Enhanced result window
        result_window = tk.Toplevel(self.app)
        result_window.title("Dictation Results")
        result_window.geometry("600x400")
        result_window.configure(bg=COLOR_PALETTE["result"])
        result_window.grab_set()
        result_window.transient(self.app)
        result_window.geometry("+%d+%d" % (self.app.winfo_rootx() + 100, self.app.winfo_rooty() + 100))
        
        tk.Label(result_window, text="🌟 Dictation Results 🌟", font=("Arial", 32, "bold"),
                bg=COLOR_PALETTE["result"], fg=color).pack(pady=30)
        
        tk.Label(result_window, text=result_text, font=("Arial", 20),
                bg=COLOR_PALETTE["result"]).pack(pady=20)
        
        tk.Label(result_window, text=feedback, font=("Arial", 24, "bold"),
                bg=COLOR_PALETTE["result"], fg=color).pack(pady=20)
        
        tk.Label(result_window, text=f"Well done {self.app.child_name}!", 
                font=("Arial", 18), bg=COLOR_PALETTE["result"], fg="#666666").pack(pady=10)
        
        close_btn = tk.Button(result_window, text="🎊 Continue", font=("Arial", 20, "bold"),
                             bg="#4CAF50", fg="white", command=result_window.destroy, width=15)
        close_btn.pack(pady=20)
        
        self.app.speak(f"{result_text} {feedback}", wait=False)
    
    def back_to_menu(self):
        """Return to main menu"""
        self.app.show_menu()


# ============================================
# Read Words Screen - Enhanced with Double Reading and Cursor Focus
# ============================================
class ReadWords:
    def __init__(self, app):
        self.app = app
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["readwords"])
        
        if not GLOBAL_WORDS:
            messagebox.showwarning("Warning", "No words available in database.")
            self.app.show_menu()
            return
        
        self.words = GLOBAL_WORDS.copy()
        self.current_index = 0
        
        self.setup_ui()
        self.app.after(500, self.read_word_twice)
    
    def setup_ui(self):
        """Setup read words UI with enhanced features"""
        main_frame = tk.Frame(self.app, bg=COLOR_PALETTE["readwords"])
        main_frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        
        # Header
        header_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["readwords"])
        header_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(header_frame, text="📖 Read Words", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["readwords"], fg="#00695c").pack(side=tk.LEFT)
        
        tk.Label(header_frame, text="By Augustine Anbananthan", font=("Arial", 12),
                bg=COLOR_PALETTE["readwords"], fg="#666666").pack(side=tk.RIGHT)
        
        # Word display frame
        display_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["readwords"])
        display_frame.pack(expand=True, pady=30)
        
        # Word label with large font
        self.word_label = tk.Label(display_frame, text="", font=("Arial", 100, "bold"),
                                   bg=COLOR_PALETTE["readwords"], fg="#1565c0")
        self.word_label.pack(pady=40)
        
        # Position label
        self.position_label = tk.Label(display_frame, text="", font=("Arial", 24),
                                       bg=COLOR_PALETTE["readwords"], fg="#666666")
        self.position_label.pack(pady=20)
        
        # Button frame
        button_frame = tk.Frame(display_frame, bg=COLOR_PALETTE["readwords"])
        button_frame.pack(pady=30)
        
        prev_btn = tk.Button(button_frame, text="⬅️ Previous", font=("Arial", 20, "bold"),
                            bg="#607d8b", fg="white", command=self.previous_word, width=12)
        prev_btn.pack(side=tk.LEFT, padx=10)
        
        read_btn = tk.Button(button_frame, text="🔊 Read Again", font=("Arial", 20, "bold"),
                            bg="#9c27b0", fg="white", command=self.read_word_twice, width=12)
        read_btn.pack(side=tk.LEFT, padx=10)
        
        next_btn = tk.Button(button_frame, text="➡️ Next", font=("Arial", 20, "bold"),
                            bg="#4CAF50", fg="white", command=self.next_word, width=12)
        next_btn.pack(side=tk.LEFT, padx=10)
        
        quit_btn = tk.Button(button_frame, text="🚪 Quit", font=("Arial", 20, "bold"),
                            bg="#ff5722", fg="white", command=self.back_to_menu, width=12)
        quit_btn.pack(side=tk.LEFT, padx=10)
        
        # Show time and date
        self.app.show_time_date(main_frame)
        
        # Display the first word
        self.display_word()
    
    def display_word(self):
        """Display the current word"""
        if self.words:
            self.current_word = self.words[self.current_index]
            self.word_label.config(text=self.current_word)
            self.position_label.config(text=f"Word {self.current_index + 1} of {len(self.words)}")
    
    def read_word_twice(self):
        """Read the current word aloud twice for clarity"""
        if self.words and hasattr(self, 'current_word'):
            stop_speech()
            print(f"Reading word: {self.current_word}")  # Debug print
            self.app.after(100, lambda: self.app.speak(self.current_word, wait=False, repeat=2))
    
    def next_word(self):
        """Move to next word"""
        if self.words:
            stop_speech()
            self.current_index = (self.current_index + 1) % len(self.words)
            self.display_word()
            self.app.after(300, self.read_word_twice)
    
    def previous_word(self):
        """Move to previous word"""
        if self.words:
            stop_speech()
            self.current_index = (self.current_index - 1) % len(self.words)
            self.display_word()
            self.app.after(300, self.read_word_twice)
    
    def back_to_menu(self):
        """Return to main menu"""
        self.app.show_menu()


# ============================================
# Admin Panel Screen - Enhanced with Import/Delete Duplicates
# ============================================
class AdminPanel:
    def __init__(self, app):
        self.app = app
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["admin"])
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup admin panel UI with enhanced features"""
        main_frame = tk.Frame(self.app, bg=COLOR_PALETTE["admin"])
        main_frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        
        # Header
        header_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["admin"])
        header_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(header_frame, text="⚙️ Admin Panel", font=("Arial", 40, "bold"),
                bg=COLOR_PALETTE["admin"], fg="#33691e").pack(side=tk.LEFT)
        
        tk.Label(header_frame, text="By Augustine Anbananthan", font=("Arial", 12),
                bg=COLOR_PALETTE["admin"], fg="#666666").pack(side=tk.RIGHT)
        
        # Add word section
        add_frame = tk.LabelFrame(main_frame, text="Add New Word", font=("Arial", 20, "bold"),
                                 bg=COLOR_PALETTE["admin"], fg="#1b5e20")
        add_frame.pack(pady=15, padx=20, fill=tk.X)
        
        word_frame = tk.Frame(add_frame, bg=COLOR_PALETTE["admin"])
        word_frame.pack(pady=15, padx=20)
        
        tk.Label(word_frame, text="Word:", font=("Arial", 18),
                bg=COLOR_PALETTE["admin"]).pack(side=tk.LEFT, padx=10)
        
        self.word_entry = ttk.Entry(word_frame, font=("Arial", 18), width=20)
        self.word_entry.pack(side=tk.LEFT, padx=10)
        self.word_entry.bind("<Return>", lambda e: self.add_word())
        
        add_btn = tk.Button(word_frame, text="➕ Add Word", font=("Arial", 16, "bold"),
                           bg="#4CAF50", fg="white", command=self.add_word, width=12)
        add_btn.pack(side=tk.LEFT, padx=10)
        
        # Import/Manage section
        manage_frame = tk.LabelFrame(main_frame, text="Manage Words", font=("Arial", 20, "bold"),
                                   bg=COLOR_PALETTE["admin"], fg="#1b5e20")
        manage_frame.pack(pady=15, padx=20, fill=tk.BOTH, expand=True)
        
        # Buttons frame
        manage_buttons_frame = tk.Frame(manage_frame, bg=COLOR_PALETTE["admin"])
        manage_buttons_frame.pack(pady=10, padx=20, fill=tk.X)
        
        import_btn = tk.Button(manage_buttons_frame, text="📁 Import Words", font=("Arial", 16, "bold"),
                              bg="#2196F3", fg="white", command=self.import_words, width=15)
        import_btn.pack(side=tk.LEFT, padx=5)
        
        delete_dup_btn = tk.Button(manage_buttons_frame, text="🗑️ Delete Duplicates", font=("Arial", 16, "bold"),
                                  bg="#FF9800", fg="white", command=self.delete_duplicates, width=15)
        delete_dup_btn.pack(side=tk.LEFT, padx=5)
        
        refresh_btn = tk.Button(manage_buttons_frame, text="🔄 Refresh List", font=("Arial", 16, "bold"),
                               bg="#9C27B0", fg="white", command=self.refresh_word_list, width=15)
        refresh_btn.pack(side=tk.LEFT, padx=5)
        
        # Listbox with scrollbar
        list_frame = tk.Frame(manage_frame, bg=COLOR_PALETTE["admin"])
        list_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.word_listbox = tk.Listbox(list_frame, font=("Arial", 16),
                                       yscrollcommand=scrollbar.set, height=12)
        self.word_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.word_listbox.yview)
        
        # Delete buttons frame
        delete_frame = tk.Frame(manage_frame, bg=COLOR_PALETTE["admin"])
        delete_frame.pack(pady=15, padx=20)
        
        delete_btn = tk.Button(delete_frame, text="🗑️ Delete Selected", font=("Arial", 16, "bold"),
                              bg="#f44336", fg="white", command=self.delete_word, width=15)
        delete_btn.pack(side=tk.LEFT, padx=10)
        
        delete_all_btn = tk.Button(delete_frame, text="🗑️ Delete All", font=("Arial", 16, "bold"),
                                  bg="#d32f2f", fg="white", command=self.delete_all_words, width=15)
        delete_all_btn.pack(side=tk.LEFT, padx=10)
        
        # Bottom buttons
        bottom_frame = tk.Frame(main_frame, bg=COLOR_PALETTE["admin"])
        bottom_frame.pack(side=tk.BOTTOM, pady=20)
        
        back_btn = tk.Button(bottom_frame, text="⬅️ Back to Menu", font=("Arial", 20, "bold"),
                            bg="#607d8b", fg="white", command=self.back_to_menu, width=15)
        back_btn.pack(side=tk.LEFT, padx=20)
        
        # Show time and date
        self.app.show_time_date(main_frame)
        
        # Load words
        self.refresh_word_list()
    
    def add_word(self):
        """Add a new word to the database"""
        word = self.word_entry.get().strip().lower()
        
        if not word:
            messagebox.showerror("Error", "Please enter a word!")
            return
        
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("INSERT INTO words (word) VALUES (?)", (word,))
            conn.commit()
            conn.close()
            
            self.app.update_global_words()
            self.refresh_word_list()
            self.word_entry.delete(0, tk.END)
            messagebox.showinfo("Success", f"Word '{word}' added successfully!")
        except sqlite3.IntegrityError:
            messagebox.showerror("Error", "Word already exists!")
    
    def import_words(self):
        """Import words from a text file"""
        file_path = filedialog.askopenfilename(
            title="Select text file with words",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        
        if not file_path:
            return
        
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                words = file.read().split()
            
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            
            added_count = 0
            duplicate_count = 0
            
            for word in words:
                word = word.strip().lower()
                if word:  # Skip empty words
                    try:
                        c.execute("INSERT INTO words (word) VALUES (?)", (word,))
                        added_count += 1
                    except sqlite3.IntegrityError:
                        duplicate_count += 1
            
            conn.commit()
            conn.close()
            
            self.app.update_global_words()
            self.refresh_word_list()
            
            messagebox.showinfo("Import Complete", 
                              f"Import completed!\nAdded: {added_count} words\nDuplicates skipped: {duplicate_count}")
        
        except Exception as e:
            messagebox.showerror("Error", f"Failed to import words: {e}")
    
    def delete_duplicates(self):
        """Delete duplicate words from the database"""
        conn = sqlite3.connect("learning.db")
        c = conn.cursor()
        
        # Get all unique words and delete duplicates
        c.execute("DELETE FROM words WHERE id NOT IN (SELECT MIN(id) FROM words GROUP BY word)")
        deleted_count = c.rowcount
        
        conn.commit()
        conn.close()
        
        self.app.update_global_words()
        self.refresh_word_list()
        
        messagebox.showinfo("Cleanup Complete", f"Deleted {deleted_count} duplicate entries!")
    
    def delete_word(self):
        """Delete selected word from database"""
        selection = self.word_listbox.curselection()
        
        if not selection:
            messagebox.showwarning("Warning", "Please select a word to delete!")
            return
        
        word = self.word_listbox.get(selection[0])
        
        confirm = messagebox.askyesno("Confirm", f"Are you sure you want to delete '{word}'?")
        if confirm:
            try:
                conn = sqlite3.connect("learning.db")
                c = conn.cursor()
                c.execute("DELETE FROM words WHERE word=?", (word,))
                conn.commit()
                conn.close()
                
                self.app.update_global_words()
                self.refresh_word_list()
                messagebox.showinfo("Success", f"Word '{word}' deleted successfully!")
            except sqlite3.Error as e:
                messagebox.showerror("Error", f"Database error: {e}")
    
    def delete_all_words(self):
        """Delete all words from database"""
        confirm = messagebox.askyesno("Confirm", "Are you sure you want to delete ALL words?")
        if confirm:
            try:
                conn = sqlite3.connect("learning.db")
                c = conn.cursor()
                c.execute("DELETE FROM words")
                conn.commit()
                conn.close()
                
                self.app.update_global_words()
                self.refresh_word_list()
                messagebox.showinfo("Success", "All words deleted successfully!")
            except sqlite3.Error as e:
                messagebox.showerror("Error", f"Database error: {e}")
    
    def refresh_word_list(self):
        """Refresh the word list"""
        self.word_listbox.delete(0, tk.END)
        
        try:
            conn = sqlite3.connect("learning.db")
            c = conn.cursor()
            c.execute("SELECT word FROM words ORDER BY word")
            words = c.fetchall()
            conn.close()
            
            for word in words:
                self.word_listbox.insert(tk.END, word[0])
        except sqlite3.Error as e:
            messagebox.showerror("Error", f"Database error: {e}")
    
    def back_to_menu(self):
        """Return to main menu"""
        self.app.show_menu()


# ============================================
# Main Application Entry Point
# ============================================
if __name__ == "__main__":
    print("Starting GameMax Kids Learning Adventure App...")
    print(f"TTS Engine initialized: {tts_engine.tts_enabled}")
    print(f"Sound enabled: {tts_engine.sound_initialized}")
    
    app = GameMaxApp()
    print("App started successfully!")
    app.mainloop()