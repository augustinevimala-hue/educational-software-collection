import sqlite3
from dbfread import DBF

# ---- Configuration ----
dbf_files = {
    "staff": "staff.DBF",
    
}
sqlite_file = "staff.db"

# ---- Create SQLite DB ----
conn = sqlite3.connect(sqlite_file)
cursor = conn.cursor()

# Drop old tables if exist
for table in dbf_files.keys():
    cursor.execute(f"DROP TABLE IF EXISTS {table}")

# ---- Import DBF files ----
for table, file in dbf_files.items():
    print(f"Importing {file} -> {table}")

    dbf = DBF(file, load=True, encoding="latin1")

    # Build CREATE TABLE dynamically
    fields = [f'"{field.name}" TEXT' for field in dbf.fields]  # store all as TEXT first
    cursor.execute(f'CREATE TABLE {table} ({", ".join(fields)})')

    # Insert rows
    for record in dbf:
        columns = ", ".join([f'"{field}"' for field in record.keys()])
        placeholders = ", ".join(["?" for _ in record.keys()])
        values = [str(v).strip() if v is not None else None for v in record.values()]
        cursor.execute(f'INSERT INTO {table} ({columns}) VALUES ({placeholders})', values)

conn.commit()
conn.close()

print("? Migration complete. Data saved in library.db")
