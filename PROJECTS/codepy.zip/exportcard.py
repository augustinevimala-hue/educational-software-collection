import os
import time
import win32com.client as win32

# === SETTINGS YOU CAN EDIT ===

# Full path to your Excel file
EXCEL_FILE = r"D:\anbu files\school library\staff1.xlsx"   # <- CHANGE THIS

# Sheet names (as in your workbook)
INPUT_SHEET_NAME = "Input_sheet"
PRINT_SHEET_NAME = "Print_Layout"

# Cell where you type main MNO (currently A3 in your description)
MNO_CELL = "A3"

# List of MNOs to generate pages for (8 cards per page for each MNO)
MNO_LIST = [5001, 5009, 5017]  # <- EDIT AS NEEDED

# Output folder for PDFs
OUTPUT_FOLDER = r"D:\anbu files\school libraray\image"   # <- CHANGE THIS


def export_id_cards():
    # Create output folder if it does not exist
    if not os.path.exists(OUTPUT_FOLDER):
        os.makedirs(OUTPUT_FOLDER)

    # Start Excel
    excel = win32.Dispatch("Excel.Application")
    excel.Visible = False  # Set True for debugging

    try:
        # Open workbook
        wb = excel.Workbooks.Open(EXCEL_FILE)

        input_sheet = wb.Worksheets(INPUT_SHEET_NAME)
        print_sheet = wb.Worksheets(PRINT_SHEET_NAME)

        for mno in MNO_LIST:
            # Put MNO into Input_sheet A3 (or your chosen cell)
            input_sheet.Range(MNO_CELL).Value = mno

            # Force recalculation
            excel.Calculate()
            time.sleep(1)  # Small delay to ensure formulas update

            # Build PDF file name
            pdf_name = f"IDCards_{mno}.pdf"
            pdf_path = os.path.join(OUTPUT_FOLDER, pdf_name)

            # Export Print_Layout sheet to PDF using its print area
            print_sheet.ExportAsFixedFormat(
                Type=0,              # 0 = PDF
                Filename=pdf_path,
                Quality=0,           # 0 = Standard, 1 = Minimum
                IncludeDocProperties=True,
                IgnorePrintAreas=False,
                OpenAfterPublish=False
            )

            print(f"Exported {pdf_path}")

        wb.Close(SaveChanges=False)

    finally:
        excel.Quit()


if __name__ == "__main__":
    export_id_cards()
py