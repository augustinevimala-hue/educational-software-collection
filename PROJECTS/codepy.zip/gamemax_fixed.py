# gamemax_fixed.py
"""
Fun With Words — by Augustine Anbananthan
Simplified, child-friendly version: Typing, Dictation, Read Aloud
Features:
 - Greeting chime + "Hello! Welcome, my little friend. Let's begin learning together."
 - Indian English TTS via gTTS (tld='co.in'), reliably played with pygame.mixer
 - Each learning word spoken twice
 - Keyboard handling fixed: no double letters, stable focus in window
 - Bright colours and readable fonts (not smaller)
"""
import tkinter as tk
from tkinter import ttk, messagebox
import random
import sqlite3
import threading
import tempfile
import os
import time
import pygame
import numpy as np
from gtts import gTTS

# ---------- Configuration ----------
WINDOW_TITLE = "🎯 Fun With Words — by Augustine Anbananthan"
LANG = 'en'          # gTTS language
TLD = 'co.in'        # Indian English accent via Google TTS
CHIME_FILE = "chime.wav"
DB_FILE = "learning.db"

# Bright friendly palette (kept from your original)
COLOR_PALETTE = {
    "welcome": "#ffeb3b",
    "menu": "#e3f2fd",
    "typing": "#f3e5f5",
    "dictation": "#fce4ec",
    "readwords": "#e0f2f1",
    "result": "#fff8e1",
}

# ---------- Initialize pygame mixer (for sound playback) ----------
# Pre-init with modest buffer for responsiveness
try:
    pygame.mixer.pre_init(frequency=22050, size=-16, channels=2, buffer=512)
    pygame.mixer.init()
    SOUND_OK = True
except Exception as e:
    print("Warning: pygame.mixer init failed:", e)
    SOUND_OK = False

# ---------- Small helper to create a short chime if not present ----------
def create_simple_chime(filename=CHIME_FILE, freq=880, duration=0.18):
    """Create a short WAV-like file using simple PCM (mono -> stereo)"""
    try:
        sample_rate = 22050
        frames = int(duration * sample_rate)
        arr = np.zeros((frames, 2), dtype=np.int16)
        for i in range(frames):
            v = int(32767 * 0.4 * np.sin(2 * np.pi * freq * i / sample_rate))
            arr[i, 0] = v
            arr[i, 1] = v
        # Write basic WAV file
        with open(filename, "wb") as f:
            # RIFF header
            f.write(b"RIFF")
            f.write((36 + arr.nbytes).to_bytes(4, "little"))
            f.write(b"WAVEfmt ")
            f.write((16).to_bytes(4, "little"))  # Subchunk1Size
            f.write((1).to_bytes(2, "little"))   # AudioFormat PCM
            f.write((2).to_bytes(2, "little"))   # NumChannels
            f.write((sample_rate).to_bytes(4, "little"))
            f.write((sample_rate * 4).to_bytes(4, "little"))
            f.write((4).to_bytes(2, "little"))
            f.write((16).to_bytes(2, "little"))
            f.write(b"data")
            f.write((arr.nbytes).to_bytes(4, "little"))
            f.write(arr.tobytes())
    except Exception as e:
        print("Could not create chime:", e)

if not os.path.exists(CHIME_FILE):
    create_simple_chime(CHIME_FILE)

# ---------- TTS manager: ensures serial playback and safe background threading ----------
class TTSManager:
    def __init__(self, lang=LANG, tld=TLD):
        self.lang = lang
        self.tld = tld
        self.lock = threading.Lock()  # Serialize speeches
        self._enabled = True
        self._last_tmpfiles = []

    def speak(self, text, repeat=1, block=False):
        """Speak text using gTTS (Indian accent). repeat=number of times to say the text.
           If block is True, this call blocks until playback finishes.
           Otherwise it runs in a background daemon thread."""
        if not text or not text.strip() or not self._enabled:
            return

        if block:
            self._do_speak(text, repeat)
        else:
            thread = threading.Thread(target=self._do_speak, args=(text, repeat), daemon=True)
            thread.start()

    def _do_speak(self, text, repeat):
        # Acquire lock so speeches are serialized
        with self.lock:
            for _ in range(repeat):
                try:
                    # create temp mp3
                    tmp = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
                    tmp.close()
                    tts = gTTS(text=text, lang=self.lang, tld=self.tld)
                    tts.save(tmp.name)
                    # play via pygame mixer
                    if SOUND_OK:
                        try:
                            # ensure previous music is stopped
                            pygame.mixer.music.stop()
                            pygame.mixer.music.load(tmp.name)
                            pygame.mixer.music.play()
                            while pygame.mixer.music.get_busy():
                                pygame.time.wait(50)
                        except Exception as e:
                            print("Playback error:", e)
                    else:
                        print("Sound disabled, would speak:", text)
                except Exception as e:
                    print("TTS generation/playback error:", e)
                finally:
                    # cleanup temp file
                    try:
                        if os.path.exists(tmp.name):
                            os.unlink(tmp.name)
                    except Exception:
                        pass
                # small pause between repeats so it is comfortable
                time.sleep(0.35)

    def stop(self):
        """Stop any playing audio"""
        try:
            if SOUND_OK:
                pygame.mixer.music.stop()
        except Exception:
            pass

tts_manager = TTSManager()

# helper wrapper
def speak_indian(text, repeat=1, block=False):
    tts_manager.speak(text, repeat=repeat, block=block)

# ---------- Database: ensure words exist ----------
def init_database():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS words (
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   word TEXT UNIQUE NOT NULL
                 )""")
    # insert defaults if empty
    c.execute("SELECT COUNT(*) FROM words")
    if c.fetchone()[0] == 0:
        defaults = [
            "apple", "banana", "mango", "cat", "dog", "mom", "dad",
            "ball", "book", "sun", "tree", "milk", "cup", "car",
            "house", "pen", "bird", "fish", "hat", "shoe"
        ]
        for w in defaults:
            try:
                c.execute("INSERT INTO words (word) VALUES (?)", (w,))
            except:
                pass
        conn.commit()
    conn.close()

def load_words():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT word FROM words ORDER BY word")
    rows = c.fetchall()
    conn.close()
    return [r[0] for r in rows]

# ---------- Main App ----------
class FunWithWordsApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(WINDOW_TITLE)
        self.state('zoomed')
        self.configure(bg=COLOR_PALETTE["welcome"])
        # keep large readable font family (prefer Segoe UI)
        if "Segoe UI" in tk.font.families() if hasattr(tk, "font") else False:
            self.base_font = ("Segoe UI", 20)
        else:
            self.base_font = ("Arial", 20)

        self.child_name = "Learner"
        self.words = []
        init_database()
        self.words = load_words()

        # ensure pygame has grab focus for keyboard while app active (helpful)
        try:
            pygame.event.set_grab(True)
        except Exception:
            pass

        # show welcome and start greeting
        self.show_welcome_screen()
        # play chime + greeting in background
        threading.Thread(target=self._play_startup_greeting, daemon=True).start()

    def _play_startup_greeting(self):
        # play chime (non-blocking)
        if SOUND_OK and os.path.exists(CHIME_FILE):
            try:
                pygame.mixer.music.load(CHIME_FILE)
                pygame.mixer.music.play()
                while pygame.mixer.music.get_busy():
                    pygame.time.wait(50)
            except Exception as e:
                print("Chime playback issue:", e)
        # greeting text
        speak_indian("Hello! Welcome, my little friend. Let's begin learning together.", repeat=1, block=False)

    def clear_window(self):
        for w in self.winfo_children():
            w.destroy()

    def show_welcome_screen(self):
        self.clear_window()
        self.configure(bg=COLOR_PALETTE["welcome"])
        frame = tk.Frame(self, bg=COLOR_PALETTE["welcome"])
        frame.pack(expand=True, fill=tk.BOTH)
        tk.Label(frame, text="🌟 Welcome to Fun With Words! 🌟", font=(self.base_font[0], 44, "bold"),
                 bg=COLOR_PALETTE["welcome"], fg="#ff6b35").pack(pady=20)
        tk.Label(frame, text="By Augustine Anbananthan", font=(self.base_font[0], 18, "italic"),
                 bg=COLOR_PALETTE["welcome"], fg="#333333").pack()
        name_frame = tk.Frame(frame, bg=COLOR_PALETTE["welcome"])
        name_frame.pack(pady=30)
        tk.Label(name_frame, text="Child's name:", font=(self.base_font[0], 26), bg=COLOR_PALETTE["welcome"]).pack(side=tk.LEFT, padx=10)
        self.name_entry = ttk.Entry(name_frame, font=(self.base_font[0], 26), width=20)
        self.name_entry.pack(side=tk.LEFT, padx=10)
        self.name_entry.insert(0, "")
        self.name_entry.focus()
        tk.Button(frame, text="🚀 Start", font=(self.base_font[0], 28, "bold"),
                  bg="#4CAF50", fg="white", command=self.start_main_menu, width=18, height=2).pack(pady=20)
        tk.Button(frame, text="❌ Quit", font=(self.base_font[0], 20, "bold"),
                  bg="#f44336", fg="white", command=self.quit_app, width=12, height=2).pack()

    def start_main_menu(self):
        name = self.name_entry.get().strip()
        if name:
            self.child_name = name.title()
        self.show_main_menu()

    def show_main_menu(self):
        self.clear_window()
        self.configure(bg=COLOR_PALETTE["menu"])
        frame = tk.Frame(self, bg=COLOR_PALETTE["menu"])
        frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        tk.Label(frame, text=f"Hello {self.child_name}! 🎉", font=(self.base_font[0], 40, "bold"),
                 bg=COLOR_PALETTE["menu"], fg="#1976d2").pack(pady=10)
        tk.Label(frame, text="Choose your learning adventure:", font=(self.base_font[0], 24, "bold"),
                 bg=COLOR_PALETTE["menu"], fg="#333333").pack(pady=6)

        btn_frame = tk.Frame(frame, bg=COLOR_PALETTE["menu"])
        btn_frame.pack(pady=30)
        tk.Button(btn_frame, text="⌨️ Typing Practice", font=(self.base_font[0], 24, "bold"),
                  bg="#8e24aa", fg="white", width=22, height=2, command=self.open_typing).grid(row=0, column=0, padx=12, pady=12)
        tk.Button(btn_frame, text="👂 Dictation Exercise", font=(self.base_font[0], 24, "bold"),
                  bg="#e91e63", fg="white", width=22, height=2, command=self.open_dictation).grid(row=0, column=1, padx=12, pady=12)
        tk.Button(btn_frame, text="📖 Read Words", font=(self.base_font[0], 24, "bold"),
                  bg="#0097a7", fg="white", width=22, height=2, command=self.open_readwords).grid(row=1, column=0, padx=12, pady=12)
        tk.Button(btn_frame, text="🚪 Quit", font=(self.base_font[0], 20, "bold"),
                  bg="#ff5722", fg="white", width=22, height=2, command=self.quit_app).grid(row=1, column=1, padx=12, pady=12)

    def quit_app(self):
        # polite goodbye and exit
        speak_indian(f"Goodbye {self.child_name}! See you again!", block=False)
        self.after(800, self._actually_quit)

    def _actually_quit(self):
        try:
            tts_manager.stop()
            pygame.mixer.quit()
        except:
            pass
        try:
            self.destroy()
        except:
            pass

    # ---------- Section openers ----------
    def open_typing(self):
        TypingScreen(self, self.words)

    def open_dictation(self):
        DictationScreen(self, self.words)

    def open_readwords(self):
        ReadWordsScreen(self, self.words)

# ---------- Typing Screen ----------
class TypingScreen:
    def __init__(self, app, words):
        self.app = app
        self.words = words.copy()
        if len(self.words) < 1:
            messagebox.showwarning("No words", "No words available.")
            return
        random.shuffle(self.words)
        self.total = min(10, len(self.words))
        self.index = 0
        self.score = 0
        self.current = ""
        self.build_ui()
        self.next_word()

    def build_ui(self):
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["typing"])
        main = tk.Frame(self.app, bg=COLOR_PALETTE["typing"])
        main.pack(expand=True, fill=tk.BOTH)
        tk.Label(main, text="⌨️ Typing Practice", font=(self.app.base_font[0], 36, "bold"),
                 bg=COLOR_PALETTE["typing"], fg="#6a1b9a").pack(pady=12)
        self.word_label = tk.Label(main, text="", font=(self.app.base_font[0], 72, "bold"),
                                   bg=COLOR_PALETTE["typing"], fg="#1565c0")
        self.word_label.pack(pady=20)
        entry_frame = tk.Frame(main, bg=COLOR_PALETTE["typing"])
        entry_frame.pack(pady=12)
        tk.Label(entry_frame, text="Type here:", font=(self.app.base_font[0], 24), bg=COLOR_PALETTE["typing"]).pack()
        self.entry = ttk.Entry(entry_frame, font=(self.app.base_font[0], 36), width=18)
        self.entry.pack(pady=8)
        self.entry.focus()
        # use KeyRelease to inspect typed text length (prevents double count)
        self.entry.bind("<KeyRelease>", self.on_key_release)
        btn_frame = tk.Frame(main, bg=COLOR_PALETTE["typing"])
        btn_frame.pack(pady=18)
        tk.Button(btn_frame, text="✅ Submit", font=(self.app.base_font[0], 22, "bold"),
                  bg="#4CAF50", fg="white", command=self.check_word, width=12).pack(side=tk.LEFT, padx=8)
        tk.Button(btn_frame, text="⬅️ Back", font=(self.app.base_font[0], 20, "bold"),
                  bg="#607d8b", fg="white", command=self.app.show_main_menu, width=12).pack(side=tk.LEFT, padx=8)
        self.score_label = tk.Label(main, text=f"Score: {self.score}/{self.total}", font=(self.app.base_font[0], 22),
                                    bg=COLOR_PALETTE["typing"], fg="#d32f2f")
        self.score_label.pack(pady=8)

    def next_word(self):
        if self.index >= self.total:
            self.show_result()
            return
        self.current = self.words[self.index]
        self.word_label.config(text=self.current)
        self.entry.delete(0, tk.END)
        self.entry.focus()
        # speak instruction + word twice
        speak_indian(f"Type the word: {self.current}", repeat=1, block=False)
        # small pause and say the word twice (we do two separate speak calls to ensure sequencing)
        threading.Thread(target=lambda: speak_indian(self.current, repeat=2, block=False), daemon=True).start()

    def on_key_release(self, event):
        # update highlighting or other live feedback if needed; avoid doubling by using entry length
        typed = self.entry.get()
        if typed.lower() == self.current.lower():
            # auto-submit
            self.check_word()

    def check_word(self):
        typed = self.entry.get().strip().lower()
        if not typed:
            self.entry.focus()
            return
        if typed == self.current.lower():
            self.score += 1
            # success sound
            if SOUND_OK:
                try:
                    pygame.mixer.Sound(CHIME_FILE).play()
                except:
                    pass
            speak_indian("Excellent! Correct!", repeat=1, block=False)
        else:
            speak_indian(f"Oops! The correct word is {self.current}", repeat=1, block=False)
        self.score_label.config(text=f"Score: {self.score}/{self.total}")
        self.index += 1
        # proceed next word after short pause so child can hear feedback
        self.app.after(1400, self.next_word)

    def show_result(self):
        percent = int((self.score / self.total) * 100)
        msg = f"Typing Complete! Score: {self.score}/{self.total} ({percent}%)"
        messagebox.showinfo("Result", msg)
        speak_indian(f"{msg} Well done!", repeat=1, block=False)
        self.app.show_main_menu()

# ---------- Dictation Screen ----------
class DictationScreen:
    def __init__(self, app, words):
        self.app = app
        self.words = words.copy()
        random.shuffle(self.words)
        self.total = min(10, len(self.words))
        self.index = 0
        self.score = 0
        self.current = ""
        self.build_ui()
        self.next_word()

    def build_ui(self):
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["dictation"])
        main = tk.Frame(self.app, bg=COLOR_PALETTE["dictation"])
        main.pack(expand=True, fill=tk.BOTH)
        tk.Label(main, text="👂 Dictation Exercise", font=(self.app.base_font[0], 36, "bold"),
                 bg=COLOR_PALETTE["dictation"], fg="#c2185b").pack(pady=12)
        self.counter_label = tk.Label(main, text="", font=(self.app.base_font[0], 20),
                                      bg=COLOR_PALETTE["dictation"])
        self.counter_label.pack()
        self.entry = ttk.Entry(main, font=(self.app.base_font[0], 36), width=24)
        self.entry.pack(pady=20)
        self.entry.bind("<Return>", lambda e: self.check_answer())
        tk.Button(main, text="🔄 Repeat", font=(self.app.base_font[0], 20, "bold"),
                  bg="#9c27b0", fg="white", command=self.repeat_word, width=12).pack(pady=6)
        tk.Button(main, text="⬅️ Back", font=(self.app.base_font[0], 20, "bold"),
                  bg="#607d8b", fg="white", command=self.app.show_main_menu, width=12).pack(pady=6)
        self.score_label = tk.Label(main, text=f"Score: {self.score}/{self.total}", font=(self.app.base_font[0], 20),
                                    bg=COLOR_PALETTE["dictation"], fg="#d32f2f")
        self.score_label.pack(pady=6)

    def next_word(self):
        if self.index >= self.total:
            self.show_result()
            return
        self.current = self.words[self.index]
        self.counter_label.config(text=f"Word {self.index+1} of {self.total}")
        self.entry.delete(0, tk.END)
        self.entry.focus()
        # instruction then say word twice
        speak_indian("Listen carefully and write the word", repeat=1, block=False)
        # speak the word twice (non-blocking queued)
        threading.Thread(target=lambda: speak_indian(self.current, repeat=2, block=False), daemon=True).start()

    def repeat_word(self):
        if self.current:
            speak_indian(self.current, repeat=2, block=False)
            self.entry.focus()

    def check_answer(self):
        answer = self.entry.get().strip().lower()
        if not answer:
            self.entry.focus()
            return
        if answer == self.current.lower():
            self.score += 1
            speak_indian("Excellent! Correct!", repeat=1, block=False)
        else:
            speak_indian(f"Oops! The correct word is {self.current}", repeat=2, block=False)
        self.score_label.config(text=f"Score: {self.score}/{self.total}")
        self.index += 1
        self.app.after(1200, self.next_word)

    def show_result(self):
        percent = int((self.score / self.total) * 100)
        msg = f"Dictation Complete! Score: {self.score}/{self.total} ({percent}%)"
        messagebox.showinfo("Result", msg)
        speak_indian(msg, repeat=1, block=False)
        self.app.show_main_menu()

# ---------- Read Words Screen ----------
class ReadWordsScreen:
    def __init__(self, app, words):
        self.app = app
        self.words = words.copy()
        if not self.words:
            messagebox.showwarning("No words", "No words available.")
            self.app.show_main_menu()
            return
        self.index = 0
        self.build_ui()
        self.read_current_twice()

    def build_ui(self):
        self.app.clear_window()
        self.app.configure(bg=COLOR_PALETTE["readwords"])
        main = tk.Frame(self.app, bg=COLOR_PALETTE["readwords"])
        main.pack(expand=True, fill=tk.BOTH)
        tk.Label(main, text="📖 Read Words", font=(self.app.base_font[0], 36, "bold"),
                 bg=COLOR_PALETTE["readwords"], fg="#00695c").pack(pady=12)
        self.word_label = tk.Label(main, text="", font=(self.app.base_font[0], 72, "bold"),
                                   bg=COLOR_PALETTE["readwords"], fg="#1565c0")
        self.word_label.pack(pady=20)
        btn_frame = tk.Frame(main, bg=COLOR_PALETTE["readwords"])
        btn_frame.pack()
        tk.Button(btn_frame, text="⬅️ Prev", font=(self.app.base_font[0], 20, "bold"),
                  bg="#607d8b", fg="white", command=self.prev_word, width=14).pack(side=tk.LEFT, padx=6)
        tk.Button(btn_frame, text="🔊 Read Again", font=(self.app.base_font[0], 20, "bold"),
                  bg="#9c27b0", fg="white", command=self.read_current_twice, width=14).pack(side=tk.LEFT, padx=6)
        tk.Button(btn_frame, text="➡️ Next", font=(self.app.base_font[0], 20, "bold"),
                  bg="#4CAF50", fg="white", command=self.next_word, width=14).pack(side=tk.LEFT, padx=6)
        tk.Button(main, text="⬅️ Back to Menu", font=(self.app.base_font[0], 20, "bold"),
                  bg="#ff5722", fg="white", command=self.app.show_main_menu, width=18).pack(pady=12)

    def read_current_twice(self):
        if not self.words:
            return
        word = self.words[self.index]
        self.word_label.config(text=word)
        speak_indian("Read the word aloud", repeat=1, block=False)
        # read word twice
        threading.Thread(target=lambda: speak_indian(word, repeat=2, block=False), daemon=True).start()

    def next_word(self):
        self.index = (self.index + 1) % len(self.words)
        self.read_current_twice()

    def prev_word(self):
        self.index = (self.index - 1) % len(self.words)
        self.read_current_twice()

# ---------- Entry point ----------
if __name__ == "__main__":
    print("Starting Fun With Words app...")
    app = FunWithWordsApp()
    app.mainloop()
