import tkinter as tk
from tkinter import ttk
from pathlib import Path
import json
import datetime
import threading
import time
import os

APP_DIR = Path(__file__).parent
WORDS_FILE = APP_DIR / "words_global.json"
RESULT_WAV = APP_DIR / "result.wav"

# --- AppContext: shared runtime state (insert after imports) ---
from pathlib import Path
import json

APP_DIR = Path(__file__).parent
WORDS_FILE = APP_DIR / "words_global.json"
RESULT_WAV = APP_DIR / "wavs" / "result.wav"

class AppContext:
    def __init__(self):
        self.global_words = self.load_words()
        self.credits = "Augustine Anbananthan"

    def load_words(self):
        if WORDS_FILE.exists():
            try:
                with open(WORDS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        return data
            except Exception:
                pass
        # fallback default words
        return ["start", "apple", "learning", "kids"]

    def save_words(self):
        try:
            WORDS_FILE.parent.mkdir(parents=True, exist_ok=True)
            with open(WORDS_FILE, "w", encoding="utf-8") as f:
                json.dump(self.global_words, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print("Error saving words:", e)
class AppContext:
    def __init__(self):
        self.global_words = self.load_words()
        self.credits = "Augustine Anbananthan"

    def load_words(self):
        if WORDS_FILE.exists():
            try:
                with open(WORDS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        return data
            except Exception:
                pass
        return ["example", "word", "education"]

    def save_words(self):
        with open(WORDS_FILE, "w", encoding="utf-8") as f:
            json.dump(self.global_words, f, ensure_ascii=False, indent=2)

class App(tk.Tk):
    def __init__(self, ctx: AppContext):
        super().__init__()
        self.ctx = ctx
        self.title("EduApp - Tkinter")
        self.geometry("800x600")
        self.protocol("WM_DELETE_WINDOW", self.quit_app)

        # Time/date in corners
        self._time_var = tk.StringVar()
        self._date_var = tk.StringVar()

        self.configure_gui()
        self.create_menu()
        self.show_welcome()

        # Start clock
        self._running = True
        self.update_clock()

    def configure_gui(self):
        self.configure(bg="#f0f8ff")

    def create_menu(self):
        menubar = tk.Menu(self)
        admin_menu = tk.Menu(menubar, tearoff=0)
        admin_menu.add_command(label="Word Admin", command=self.open_admin)
        menubar.add_cascade(label="Admin", menu=admin_menu)
        menubar.add_command(label="Quit", command=self.quit_app)
        self.config(menu=menubar)

    def show_welcome(self):
        frame = tk.Frame(self, bg="#4a90e2")
        frame.pack(fill="both", expand=True)

        title = tk.Label(frame, text="Welcome to EduApp", font=("Arial", 28, "bold"), bg="#4a90e2", fg="white")
        title.pack(pady=40)

        subtitle = tk.Label(frame, text="Learning made fun. Indian English voice: Heera (if configured).",
                            font=("Arial", 14), bg="#4a90e2", fg="white")
        subtitle.pack(pady=10)

        start_btn = ttk.Button(frame, text="Start", command=lambda: self.start_session(frame))
        start_btn.pack(pady=20)

        cred = tk.Label(frame, text=f"Developed by {self.ctx.credits}", bg="#4a90e2", fg="white")
        cred.pack(side="bottom", anchor="se", padx=10, pady=10)

        # time/date corners
        self._time_label = tk.Label(frame, textvariable=self._time_var, bg="#4a90e2", fg="white")
        self._date_label = tk.Label(frame, textvariable=self._date_var, bg="#4a90e2", fg="white")
        self._time_label.place(relx=0.0, rely=0.0, anchor="nw")
        self._date_label.place(relx=1.0, rely=0.0, anchor="ne")

        # ensure quit on this window as well
        for wname in ("Frame", "Toplevel"):
            frame.bind_all("<Escape>", lambda e: self.quit_app())

        # store for removal later
        self._welcome_frame = frame

    def update_clock(self):
        now = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=0)))  # utc placeholder
        # British time (Europe/London)
        try:
            import pytz
            london = datetime.datetime.now(pytz.timezone("Europe/London"))
        except Exception:
            london = now
        self._time_var.set(london.strftime("%H:%M:%S"))
        self._date_var.set(london.strftime("%d %B %Y"))
        if self._running:
            self.after(1000, self.update_clock)

    def start_session(self, frame):
        frame.destroy()
        # placeholder for actual modules
        self._session_frame = tk.Frame(self, bg="#ffffff")
        self._session_frame.pack(fill="both", expand=True)
        tk.Label(self._session_frame, text="Typing exercise goes here...", font=("Arial", 16)).pack(pady=20)

        # add per-window quit and credits
        quit_btn = ttk.Button(self._session_frame, text="Quit", command=self.quit_app)
        quit_btn.pack(side="bottom", pady=20)

        cred = tk.Label(self._session_frame, text=f"Developed by {self.ctx.credits}", bg="#ffffff")
        cred.pack(side="bottom", pady=4)

    def open_admin(self):
        admin = tk.Toplevel(self)
        admin.title("Word Admin")
        admin.geometry("600x400")
        frame = tk.Frame(admin)
        frame.pack(fill="both", expand=True, padx=10, pady=10)

        listbox = tk.Listbox(frame, height=12, width=40)
        listbox.pack(side="left", fill="y")
        for w in self.ctx.global_words:
            listbox.insert("end", w)

        scrollbar = tk.Scrollbar(frame, orient="vertical")
        scrollbar.config(command=listbox.yview)
        listbox.config(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="left", fill="y")

        btn_frame = tk.Frame(frame)
        btn_frame.pack(side="right", fill="both", expand=True)

        def add_word():
            w = simpledialog.askstring("Add word", "Enter new word:")
            if w:
                self.ctx.global_words.append(w.strip())
                listbox.insert("end", w.strip())

        def save_changes():
            self.ctx.save_words()
            tk.messagebox.showinfo("Saved", "Words saved to global file.")

        def dedupe():
            uniq = sorted(set(self.ctx.global_words), key=self.ctx.global_words.index)
            self.ctx.global_words = uniq
            listbox.delete(0, "end")
            for w in uniq:
                listbox.insert("end", w)

        ttk.Button(btn_frame, text="Add Word", command=add_word).pack(pady=4)
        ttk.Button(btn_frame, text="Save", command=save_changes).pack(pady=4)
        ttk.Button(btn_frame, text="Deduplicate", command=dedupe).pack(pady=4)

        ttk.Button(btn_frame, text="Close", command=admin.destroy).pack(pady=20)

    def quit_app(self, *args):
        # play Result.wav if available
        try:
            import simpleaudio as sa
            if Path(RESULT_WAV).exists():
                wave = sa.WaveObject.from_wave_file(str(RESULT_WAV))
                wave.play().wait_done()
        except Exception:
            pass
        # nice goodbye
        tk.messagebox.showinfo("Goodbye", "Hope you had a nice time. Good bye. See you again!")
        self._running = False
        self.destroy()

def main():
    ctx = AppContext()
    app = App(ctx)
    app.mainloop()

if __name__ == "__main__":
    main()