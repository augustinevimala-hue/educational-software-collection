import pyttsx3

# Explicitly initialize the SAPI5 engine, which can sometimes load voices better
try:
    engine = pyttsx3.init('sapi5') # Specify the SAPI5 driver
    voices = engine.getProperty('voices')
    print("--- Available TTS Voices ---")
    for voice in voices:
        print(f"Name: {voice.name}, ID: {voice.id}")
        if 'Heera' in voice.name:
            print(">>> FOUND HEERA! <<<")
            
    engine.runAndWait()

except Exception as e:
    print(f"Error during pyttsx3 initialization: {e}")