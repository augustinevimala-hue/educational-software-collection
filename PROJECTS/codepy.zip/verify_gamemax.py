#!/usr/bin/env python3
"""
File verification script - Run this to check if you have the correct fixed version
"""

import sys

def verify_file_version():
    """Verify if this is the fixed version of gamemax.py"""
    
    print("🔍 VERIFYING GAMEMAX.PY VERSION...")
    print("=" * 50)
    
    # Read the file
    try:
        with open('gamemax.py', 'r') as f:
            content = f.read()
    except FileNotFoundError:
        print("❌ gamemax.py file not found!")
        return False
    
    # Check for key indicators of the fixed version
    checks = []
    
    # Check 1: Larger keyboard
    if 'width=5, height=3' in content:
        checks.append(("✅", "Virtual keyboard increased to 5×3"))
    else:
        checks.append(("❌", "Virtual keyboard NOT increased"))
    
    # Check 2: Larger font
    if content.count('font=("Arial", 20, "bold")') >= 10:
        checks.append(("✅", f"Font size 20px found ({content.count('font=(\"Arial\", 20, \"bold\")')} times)"))
    else:
        checks.append(("❌", "Font size 20px not properly implemented"))
    
    # Check 3: Enter key bindings
    return_bindings = content.count('bind("<Return>"')
    if return_bindings >= 4:
        checks.append(("✅", f"Enter key advancement ({return_bindings} bindings found)"))
    else:
        checks.append(("❌", "Enter key advancement missing"))
    
    # Check 4: Time positioning
    if 'time_label.place(relx=1.0, rely=0, anchor="ne"' in content:
        checks.append(("✅", "Time/date positioned to top-right"))
    else:
        checks.append(("❌", "Time/date positioning NOT fixed"))
    
    # Check 5: Dictation validation
    if 'typed_word == self.current_word.lower()' in content:
        checks.append(("✅", "Dictation validation fixed"))
    else:
        checks.append(("❌", "Dictation validation NOT fixed"))
    
    # Check 6: Indian TTS class
    if 'class IndianEnglishTTS:' in content:
        checks.append(("✅", "Indian English TTS class present"))
    else:
        checks.append(("❌", "Indian English TTS class missing"))
    
    # Check 7: File size
    lines = content.split('\n')
    if len(lines) >= 1700:
        checks.append(("✅", f"File size correct ({len(lines)} lines)"))
    else:
        checks.append(("❌", f"File size incorrect ({len(lines)} lines)"))
    
    # Display results
    print("VERIFICATION RESULTS:")
    print("-" * 30)
    
    all_passed = True
    for status, message in checks:
        print(f"{status} {message}")
        if status == "❌":
            all_passed = False
    
    print("-" * 30)
    
    if all_passed:
        print("🎉 SUCCESS! This is the CORRECT fixed version of gamemax.py")
        print("✅ All major fixes have been implemented")
        return True
    else:
        print("❌ WARNING! This appears to be the OLD version")
        print("❗ Please download the correct version from the workspace")
        return False

def main():
    verify_file_version()

if __name__ == "__main__":
    main()