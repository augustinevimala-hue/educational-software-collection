class MainMenu(tk.Frame):
    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.pack(fill=tk.BOTH, expand=True)
        
        # Menu navigation variables
        self.current_selection = 0
        self.buttons = []
        self.button_commands = []
        self.is_selected = False  # Track if item is selected (red state)
        
        self.create_widgets()
        self.setup_navigation()

    def create_widgets(self):
        tk.Label(self, text=f"Hello, {self.username}!", 
                font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=20)
        tk.Label(self, text="Choose an activity!", 
                font=("Arial", 24), bg="#e6f3ff", fg="#ff4081").pack(pady=10)
        
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=20)
        
        # Define button configurations
        button_configs = [
            ("Typing Exercise", self.open_typing),
            ("Spell Check Quiz", self.open_spellcheck),
            ("Math Practice", self.open_math),
            ("View Scores", self.view_scores),
            ("Read Words", self.read_words),
            ("Switch User", self.switch_user),
            ("Admin", self.open_admin),
            ("Quit", self.parent.exit_app)
        ]
        
        # Create enhanced buttons with highlighting
        for i, (text, cmd) in enumerate(button_configs):
            btn = tk.Button(btn_frame, text=text, 
                          font=("Arial", 18, "bold"),
                          width=18, height=2,
                          bg="#bbdefb",  # Default background
                          fg="black",
                          relief="raised",
                          borderwidth=2,
                          command=lambda c=cmd, idx=i: self.button_clicked(c, idx))
            
            btn.grid(row=i//2, column=i%2, padx=15, pady=15, sticky="ew")
            
            # Bind mouse events for highlighting
            btn.bind("<Enter>", lambda e, idx=i: self.on_hover_enter(idx))
            btn.bind("<Leave>", lambda e, idx=i: self.on_hover_leave(idx))
            btn.bind("<Button-1>", lambda e, idx=i: self.on_mouse_click(idx))
            
            self.buttons.append(btn)
            self.button_commands.append(cmd)
        
        # Configure grid weights for equal button sizes
        btn_frame.grid_columnconfigure(0, weight=1)
        btn_frame.grid_columnconfigure(1, weight=1)
        
        # Initial highlighting
        self.update_button_highlighting()
        
        tk.Label(self, text="Created by Augustine Anbananthan\nDeveloper Note: Have fun learning!", 
                font=("Arial", 12), bg="#e6f3ff").pack(side=tk.BOTTOM, pady=10)

    def setup_navigation(self):
        """Setup keyboard navigation"""
        self.parent.bind("<Up>", self.navigate_up)
        self.parent.bind("<Down>", self.navigate_down)
        self.parent.bind("<Left>", self.navigate_left)
        self.parent.bind("<Right>", self.navigate_right)
        self.parent.bind("<Return>", self.select_current)
        self.parent.bind("<space>", self.select_current)
        self.parent.bind("<Escape>", self.deselect_current)
        
        # Set focus to enable keyboard navigation
        self.focus_set()

    def navigate_up(self, event):
        """Navigate up in the menu"""
        if not self.is_selected:
            if self.current_selection >= 2:
                self.current_selection -= 2
                self.update_button_highlighting()
                self.speak_current_option()
        return "break"

    def navigate_down(self, event):
        """Navigate down in the menu"""
        if not self.is_selected:
            if self.current_selection < len(self.buttons) - 2:
                self.current_selection += 2
                self.update_button_highlighting()
                self.speak_current_option()
        return "break"

    def navigate_left(self, event):
        """Navigate left in the menu"""
        if not self.is_selected:
            if self.current_selection % 2 == 1:  # If on right column
                self.current_selection -= 1
                self.update_button_highlighting()
                self.speak_current_option()
        return "break"

    def navigate_right(self, event):
        """Navigate right in the menu"""
        if not self.is_selected:
            if self.current_selection % 2 == 0 and self.current_selection < len(self.buttons) - 1:  # If on left column
                self.current_selection += 1
                self.update_button_highlighting()
                self.speak_current_option()
        return "break"

    def select_current(self, event):
        """Select current option (red highlighting)"""
        if not self.is_selected:
            self.is_selected = True
            self.update_button_highlighting()
            self.parent.speak(f"Selected: {self.buttons[self.current_selection].cget('text')}. Press Enter again to confirm or Escape to cancel.")
        else:
            # Execute the command
            self.execute_current_command()
        return "break"

    def deselect_current(self, event):
        """Deselect current option (back to grey highlighting)"""
        if self.is_selected:
            self.is_selected = False
            self.update_button_highlighting()
            self.parent.speak("Selection cancelled.")
        return "break"

    def execute_current_command(self):
        """Execute the currently selected command"""
        command = self.button_commands[self.current_selection]
        button_text = self.buttons[self.current_selection].cget('text')
        self.parent.speak(f"Opening {button_text}")
        
        # Cleanup key bindings before switching screens
        self.cleanup_navigation()
        command()

    def button_clicked(self, command, index):
        """Handle button click"""
        self.current_selection = index
        self.is_selected = True
        self.update_button_highlighting()
        
        # Execute after a short delay to show the red highlighting
        self.after(200, lambda: (self.cleanup_navigation(), command()))

    def on_hover_enter(self, index):
        """Handle mouse hover enter"""
        if not self.is_selected:
            self.current_selection = index
            self.update_button_highlighting()

    def on_hover_leave(self, index):
        """Handle mouse hover leave"""
        if not self.is_selected:
            self.update_button_highlighting()

    def on_mouse_click(self, index):
        """Handle mouse click for selection"""
        self.current_selection = index
        self.is_selected = True
        self.update_button_highlighting()

    def update_button_highlighting(self):
        """Update button colors based on current state"""
        for i, button in enumerate(self.buttons):
            if i == self.current_selection:
                if self.is_selected:
                    # Red highlighting for selected state
                    button.config(bg="#f44336", fg="white", relief="sunken")
                else:
                    # Grey highlighting for navigation
                    button.config(bg="#9e9e9e", fg="white", relief="raised")
            else:
                # Default state
                button.config(bg="#bbdefb", fg="black", relief="raised")

    def speak_current_option(self):
        """Speak the currently highlighted option"""
        if hasattr(self.parent, 'speak'):
            button_text = self.buttons[self.current_selection].cget('text')
            self.parent.speak(button_text)

    def cleanup_navigation(self):
        """Clean up keyboard bindings when leaving the menu"""
        try:
            self.parent.unbind("<Up>")
            self.parent.unbind("<Down>")
            self.parent.unbind("<Left>")
            self.parent.unbind("<Right>")
            self.parent.unbind("<Return>")
            self.parent.unbind("<space>")
            self.parent.unbind("<Escape>")
        except:
            pass

    # Keep all the existing methods (open_typing, open_spellcheck, etc.)
    def open_typing(self): 
        self.destroy()
        TypingExercise(self.parent, self.username, self.user_id)
        
    def open_spellcheck(self): 
        self.destroy()
        SpellCheckQuiz(self.parent, self.username, self.user_id)
        
    def open_math(self): 
        self.destroy()
        MathExercise(self.parent, self.username, self.user_id)
        
    def view_scores(self):
        # Your existing view_scores method here
        pass
        
    def read_words(self): 
        self.destroy()
        ReadWords(self.parent, self.username, self.user_id)
        
    def switch_user(self): 
        self.destroy()
        self.parent.show_login()
        
    def open_admin(self): 
        self.destroy()
        AdminPanel(self.parent, self.username, self.user_id)


# ALTERNATIVE: If you want a simpler version that just adds highlighting to existing buttons:

def add_button_highlighting(self):
    """Add this method to your existing MainMenu class"""
    
    # Convert existing ttk buttons to tk buttons with highlighting
    for widget in self.winfo_children():
        if isinstance(widget, ttk.Frame):
            for child in widget.winfo_children():
                if isinstance(child, ttk.Button):
                    # Get button properties
                    text = child.cget("text")
                    command = child.cget("command")
                    
                    # Create new enhanced button
                    new_btn = tk.Button(widget, text=text,
                                      font=("Arial", 18, "bold"),
                                      width=18, height=2,
                                      bg="#bbdefb",
                                      fg="black",
                                      command=command)
                    
                    # Add hover effects
                    def on_enter(e, btn=new_btn):
                        btn.config(bg="#9e9e9e", fg="white")
                        
                    def on_leave(e, btn=new_btn):
                        btn.config(bg="#bbdefb", fg="black")
                        
                    def on_click(e, btn=new_btn):
                        btn.config(bg="#f44336", fg="white")
                        btn.after(200, lambda: btn.config(bg="#bbdefb", fg="black"))
                    
                    new_btn.bind("<Enter>", on_enter)
                    new_btn.bind("<Leave>", on_leave)
                    new_btn.bind("<Button-1>", on_click)
                    
                    # Replace old button
                    grid_info = child.grid_info()
                    child.destroy()
                    new_btn.grid(**grid_info)


# USAGE INSTRUCTIONS:
# 1. Replace your existing MainMenu class with the enhanced version above
# 2. Or add the add_button_highlighting() method to your existing class and call it in create_widgets()
# 3. The navigation works with:
#    - Arrow keys to navigate (grey highlighting)
#    - Enter/Space to select (red highlighting)
#    - Enter again to confirm and execute
#    - Escape to cancel selection
#    - Mouse hover and click also work