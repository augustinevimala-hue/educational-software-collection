import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3
import re
import os

class WordAdminTool(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Kids Game Word Administration Tool")
        self.geometry("800x600")
        self.configure(bg="#f0f8ff")
        
        self.db_path = None
        self.current_user_id = None
        self.current_username = None
        self.word_map = {}
        self.db_schema = {} 

        self.style = ttk.Style()
        self.style.configure("TButton", font=("Arial", 12), padding=5)
        self.style.configure("TLabel", font=("Arial", 14))

        # FIX: Define a custom style for the red button text
        self.style.configure("Red.TButton", foreground="red", font=("Arial", 12, "bold"))

        self.show_db_selection()

    def db_connect(self):
        if not self.db_path or not os.path.exists(self.db_path):
            raise FileNotFoundError(f"Database file not found at: {self.db_path}")
        return sqlite3.connect(self.db_path)

    def init_database_schema(self):
        try:
            conn = self.db_connect()
            c = conn.cursor()
            
            c.execute('''CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT NOT NULL UNIQUE,
                level TEXT DEFAULT 'KG'
            )''')
            c.execute('''CREATE TABLE IF NOT EXISTS words (
                id INTEGER PRIMARY KEY,
                word TEXT NOT NULL,
                user_id INTEGER,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )''')
            c.execute('''CREATE TABLE IF NOT EXISTS scores (
                id INTEGER PRIMARY KEY,
                user_id INTEGER,
                exercise TEXT,
                score INTEGER,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )''')
            conn.commit()

            self.db_schema = {}
            c.execute("SELECT name FROM sqlite_master WHERE type='table';")
            for row in c.fetchall():
                table_name = row[0]
                c.execute(f"PRAGMA table_info({table_name});")
                self.db_schema[table_name] = [col[1] for col in c.fetchall()]
            
            conn.close()
            return True
        except Exception as e:
            messagebox.showerror("DB Initialization Error", f"Failed to initialize database schema: {e}")
            self.db_path = None
            return False

    # --- DB SELECTION INTERFACE ---

    def show_db_selection(self):
        for widget in self.winfo_children():
            widget.destroy()

        frame = ttk.Frame(self, padding="20 20 20 20")
        frame.pack(expand=True, fill=tk.BOTH)

        tk.Label(frame, text="1. Select Learning Database", font=("Arial", 18, "bold")).pack(pady=10)
        
        self.path_label = tk.Label(frame, text="No file selected.", font=("Arial", 12), fg="red")
        self.path_label.pack(pady=10)

        ttk.Button(frame, text="Browse for learning.db", command=self.select_db_file).pack(pady=20)
        
        self.structure_frame = ttk.LabelFrame(frame, text="Database Structure (for verification)")
        self.structure_frame.pack(pady=10, padx=10, fill=tk.X)
        
        tk.Label(self.structure_frame, text="Tables: None loaded.", font=("Arial", 10)).pack(padx=5, pady=5)
        
        self.continue_btn = ttk.Button(frame, text="2. Continue to User Selection", command=self.show_user_selection, state=tk.DISABLED)
        self.continue_btn.pack(pady=10)
        
        ttk.Button(frame, text="Quit Tool", command=self.quit).pack(pady=20)

    def select_db_file(self):
        initial_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = filedialog.askopenfilename(
            initialdir=initial_dir,
            title="Select the learning.db file",
            filetypes=[("Database files", "learning.db")]
        )
        if file_path:
            self.db_path = file_path
            
            if self.init_database_schema():
                self.path_label.config(text=f"Database Loaded: {os.path.basename(file_path)}", fg="green")
                self.continue_btn.config(state=tk.NORMAL)
                
                for widget in self.structure_frame.winfo_children():
                    widget.destroy()
                
                tables_text = "Tables Found:\n"
                for table, cols in self.db_schema.items():
                    tables_text += f" - {table} (Cols: {', '.join(cols)})\n"
                
                tk.Label(self.structure_frame, text=tables_text, justify=tk.LEFT, font=("Arial", 10)).pack(padx=5, pady=5)
                
            else:
                self.db_path = None
                self.path_label.config(text="File failed validation.", fg="red")
                self.continue_btn.config(state=tk.DISABLED)
        else:
            self.db_path = None
            self.path_label.config(text="No file selected.", fg="red")
            self.continue_btn.config(state=tk.DISABLED)

    # --- USER SELECTION INTERFACE ---

    def get_all_users(self):
        try:
            conn = self.db_connect()
            c = conn.cursor()
            c.execute("SELECT id, username FROM users ORDER BY username")
            users = c.fetchall()
            conn.close()
            return users
        except Exception as e:
            messagebox.showerror("DB Error", f"Cannot access USERS table. Error: {e}")
            return []

    def show_user_selection(self):
        if not self.db_path or 'words' not in self.db_schema:
            messagebox.showerror("Error", "Please select a valid database file and ensure it has a 'words' table.")
            self.show_db_selection()
            return
            
        for widget in self.winfo_children():
            widget.destroy()

        frame = ttk.Frame(self, padding="20 20 20 20")
        frame.pack(expand=True, fill=tk.BOTH)

        users = self.get_all_users()
        user_list = [f"{u[1]} (ID: {u[0]})" for u in users]
        
        tk.Label(frame, text="2. Select User for Word Management", font=("Arial", 18, "bold")).pack(pady=10)
        
        if not user_list:
            user_list = ["No Users Found - Run Main Game to Register"]
            default_value = user_list[0]
            start_state = tk.DISABLED
        else:
            default_value = user_list[0]
            start_state = tk.NORMAL

        self.user_var = tk.StringVar(value=default_value)
        self.user_combo = ttk.Combobox(frame, textvariable=self.user_var, values=user_list, state="readonly", font=("Arial", 14), width=40)
        self.user_combo.pack(pady=10)
        
        ttk.Button(frame, text="3. Start Word Admin", command=self.start_admin_session, state=start_state).pack(pady=20)
        
        ttk.Button(frame, text="Back to DB Selection", command=self.show_db_selection).pack(pady=10)
        ttk.Button(frame, text="Quit Tool", command=self.quit).pack(pady=10)

    def start_admin_session(self):
        selected_user = self.user_combo.get()
        
        if "No Users Found" in selected_user or selected_user.startswith("--"):
            messagebox.showerror("Error", "Please select a valid user to start administration.")
            return

        match = re.search(r'\(ID: (\d+)\)', selected_user)
        if match:
            self.current_user_id = int(match.group(1))
            self.current_username = selected_user.split(" (ID:")[0].strip()
            self.show_admin_interface()
        else:
            messagebox.showerror("Error", "Could not parse user ID from selection. Please ensure you have clicked on a user name.")

    # --- ADMIN INTERFACE (CRUD & CLEANUP) ---

    def show_admin_interface(self):
        for widget in self.winfo_children():
            widget.destroy()

        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        
        # --- Header ---
        tk.Label(self, text=f"Words for: {self.current_username} (Table: words)", font=("Arial", 20, "bold"), bg="#f0f8ff").grid(row=0, column=0, columnspan=2, pady=10)

        # --- Left Panel: Word List (Read) ---
        list_frame = ttk.LabelFrame(self, text="Existing Words", padding="10")
        list_frame.grid(row=1, column=0, padx=10, pady=10, sticky="nsew")
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(0, weight=1)
        
        self.word_listbox = tk.Listbox(list_frame, font=("Arial", 12), height=20)
        self.word_listbox.grid(row=0, column=0, sticky="nsew")
        self.word_listbox.bind("<<ListboxSelect>>", self.on_word_select)

        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.word_listbox.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.word_listbox.config(yscrollcommand=scrollbar.set)
        
        ttk.Button(list_frame, text="Delete Selected Word", command=self.delete_word).grid(row=1, column=0, columnspan=2, pady=5)
        ttk.Button(list_frame, text="Import Words from File", command=self.import_words).grid(row=2, column=0, columnspan=2, pady=5)
        
        # FIX: Apply the custom Red.TButton style
        ttk.Button(list_frame, text="CLEAN UP DUPLICATES", command=self.cleanup_duplicates, style="Red.TButton").grid(row=3, column=0, columnspan=2, pady=10)


        # --- Right Panel: Add/Edit/Spellcheck ---
        edit_frame = ttk.LabelFrame(self, text="Add / Edit Word (Pasting allowed)", padding="10")
        edit_frame.grid(row=1, column=1, padx=10, pady=10, sticky="n")

        tk.Label(edit_frame, text="Word:", style="TLabel").pack(pady=5)
        self.word_entry = tk.Entry(edit_frame, font=("Arial", 14), width=30) 
        self.word_entry.pack(pady=5)
        self.word_entry.bind("<KeyRelease>", lambda e: self.status_label.config(text="Paste complete. Check spelling/format."))
        
        self.status_label = tk.Label(edit_frame, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        ttk.Button(edit_frame, text="Check Spelling/Format", command=self.check_spelling).pack(pady=5)
        tk.Label(edit_frame, text="(Checks for single, alphabetic word)", font=("Arial", 8)).pack()
        
        ttk.Button(edit_frame, text="Add New Word", command=self.add_word).pack(pady=10)
        self.edit_btn = ttk.Button(edit_frame, text="Update Edited Word", command=self.update_word, state=tk.DISABLED)
        self.edit_btn.pack(pady=5)

        # --- Footer: Back/Quit Buttons ---
        footer_frame = ttk.Frame(self)
        footer_frame.grid(row=2, column=0, columnspan=2, pady=10) 
        
        ttk.Button(footer_frame, text="Back to User Select", command=self.show_user_selection).pack(side=tk.LEFT, padx=10)
        ttk.Button(footer_frame, text="Quit Tool", command=self.quit).pack(side=tk.LEFT, padx=10)


        self.load_words()

    def load_words(self):
        self.word_listbox.delete(0, tk.END)
        self.word_map = {}
        
        try:
            conn = self.db_connect()
            c = conn.cursor()
            
            c.execute("SELECT id, word FROM words WHERE user_id = ? ORDER BY word", (self.current_user_id,))
            
            for i, row in enumerate(c.fetchall()):
                word_id, word = row
                self.word_listbox.insert(tk.END, word)
                self.word_map[i] = word_id
            conn.close()
            self.word_entry.delete(0, tk.END)
            self.edit_btn.config(state=tk.DISABLED)
            
        except Exception as e:
            messagebox.showerror("DB Load Error", f"Could not load words for user ID {self.current_user_id}. Error: {e}")

    # --- CLEANUP FUNCTION ---

    def cleanup_duplicates(self):
        if not messagebox.askyesno("CONFIRM CLEANUP", "Are you sure you want to delete ALL duplicate words for this user? Only one copy of each unique word will remain."):
            return

        try:
            conn = self.db_connect()
            c = conn.cursor()
            
            delete_query = f"""
            DELETE FROM words
            WHERE id NOT IN (
                SELECT MIN(id)
                FROM words
                WHERE user_id = ?
                GROUP BY word
            ) AND user_id = ?;
            """
            
            c.execute(delete_query, (self.current_user_id, self.current_user_id))
            count = c.rowcount
            conn.commit()
            conn.close()
            
            messagebox.showinfo("Cleanup Complete", f"Successfully deleted {count} duplicate words for {self.current_username}.")
            self.load_words()
            
        except Exception as e:
            messagebox.showerror("Cleanup Error", f"Failed to clean up duplicates: {e}")

    # --- CRUD Operations (Rest remain the same) ---

    def on_word_select(self, event):
        try:
            selection = self.word_listbox.curselection()
            if selection:
                word_text = self.word_listbox.get(selection[0])
                self.word_entry.delete(0, tk.END)
                self.word_entry.insert(0, word_text)
                self.edit_btn.config(state=tk.NORMAL)
                self.status_label.config(text=f"Ready to edit ID: {self.word_map[selection[0]]}", fg="blue")
            else:
                self.word_entry.delete(0, tk.END)
                self.edit_btn.config(state=tk.DISABLED)
                self.status_label.config(text="")
        except Exception as e:
            messagebox.showerror("Error", f"Error selecting word: {e}")

    def check_spelling(self):
        word = self.word_entry.get().strip().lower()
        if not word:
            self.status_label.config(text="Enter a word first.", fg="red")
            return
            
        if not re.match(r'^[a-z]+$', word):
            self.status_label.config(text="FAIL: Word contains non-alphabetic characters (numbers, symbols).", fg="red")
            return

        self.status_label.config(text="PASS: Basic validation successful (alphabetic only). Ready to Add/Update).", fg="green")


    def add_word(self):
        word = self.word_entry.get().strip().lower()
        if not word or not re.match(r'^[a-z]+$', word):
            messagebox.showerror("Error", "Please enter a valid word (alphabetic characters only).")
            return
            
        conn = self.db_connect()
        c = conn.cursor()
        try:
            c.execute("INSERT INTO words (word, user_id) VALUES (?, ?)", (word, self.current_user_id))
            conn.commit()
            self.status_label.config(text=f"Added: '{word}'", fg="green")
            self.word_entry.delete(0, tk.END)
            self.load_words()
        except Exception as e:
            messagebox.showerror("DB Error", f"Could not add word: {e}")
        finally:
            conn.close()

    def update_word(self):
        try:
            selection = self.word_listbox.curselection()
            if not selection:
                messagebox.showerror("Error", "Please select a word to update.")
                return

            word_id = self.word_map.get(selection[0])
            new_word = self.word_entry.get().strip().lower()
            
            if not new_word or not re.match(r'^[a-z]+$', new_word):
                messagebox.showerror("Error", "Please enter a valid word (alphabetic characters only).")
                return

            conn = self.db_connect()
            c = conn.cursor()
            c.execute("UPDATE words SET word = ? WHERE id = ?", (new_word, word_id))
            conn.commit()
            self.status_label.config(text=f"Updated ID {word_id} to '{new_word}'", fg="green")
            self.load_words()
        except Exception as e:
            messagebox.showerror("DB Error", f"Could not update word: {e}")
        finally:
            conn.close()

    def delete_word(self):
        try:
            selection = self.word_listbox.curselection()
            if not selection:
                messagebox.showerror("Error", "Please select a word to delete.")
                return
            
            listbox_index = selection[0]
            word_id_to_delete = self.word_map.get(listbox_index)
            word_text = self.word_listbox.get(listbox_index)

            if not messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete '{word_text}' (ID: {word_id_to_delete})?"):
                return

            conn = self.db_connect()
            c = conn.cursor()
            c.execute("DELETE FROM words WHERE id = ?", (word_id_to_delete,))
            conn.commit()
            self.status_label.config(text=f"Deleted: '{word_text}'", fg="orange")
            self.load_words()
        except Exception as e:
            messagebox.showerror("DB Error", f"Could not delete word: {e}")
        finally:
            conn.close()

    def import_words(self):
        initial_dir = os.path.dirname(self.db_path) if self.db_path else os.path.dirname(os.path.abspath(__file__))
        
        file_path = filedialog.askopenfilename(
            initialdir=initial_dir,
            title="Select a text (.txt) file to import words",
            filetypes=[("Text files", "*.txt")]
        )
        if not file_path:
            return

        words_to_import = []
        try:
            with open(file_path, 'r') as f:
                for line in f:
                    word = line.strip().lower()
                    if re.match(r'^[a-z]+$', word):
                        words_to_import.append((word, self.current_user_id))
        except Exception as e:
            messagebox.showerror("File Error", f"Could not read file: {e}")
            return

        if not words_to_import:
            messagebox.showinfo("Import", "No valid words found in the file (must be one word per line, alphabetic only).")
            return

        conn = self.db_connect()
        c = conn.cursor()
        try:
            c.executemany("INSERT INTO words (word, user_id) VALUES (?, ?)", words_to_import)
            conn.commit()
            self.status_label.config(text=f"Successfully imported {len(words_to_import)} words.", fg="green")
            self.load_words()
        except Exception as e:
            messagebox.showerror("DB Error", f"Could not import words: {e}")
        finally:
            conn.close()


if __name__ == "__main__":
    app = WordAdminTool()
    app.mainloop()