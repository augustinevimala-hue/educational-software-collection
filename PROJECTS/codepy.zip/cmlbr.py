import tkinter as tk
from tkinter import messagebox
import trans
import staff
import stud

def open_transactions():
    # Call transaction module main GUI or function
    messagebox.showinfo("Transactions", "Opening Transactions Module...")
    trans.mainmenu()  # Adjust if function renamed for GUI

def open_staff():
    messagebox.showinfo("Staff", "Opening Staff Module...")
    staff.staffmenu()  # Adjust if function renamed for GUI

def open_students():
    messagebox.showinfo("Students", "Opening Students Module...")
    stud.mainmenu()  # Adjust if function renamed for GUI

root = tk.Tk()
root.title("Library System")

tk.Label(root, text="Library System Main Menu", font=("Arial", 16)).pack(pady=10)

tk.Button(root, text="1. Transactions", width=30, command=open_transactions).pack(pady=5)
tk.Button(root, text="2. Staff", width=30, command=open_staff).pack(pady=5)
tk.Button(root, text="3. Students", width=30, command=open_students).pack(pady=5)
tk.Button(root, text="4. Exit", width=30, command=root.quit).pack(pady=20)

root.mainloop()
