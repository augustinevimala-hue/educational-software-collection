import os
from pypdf import PdfWriter  # PdfWriter is used for merging in new pypdf

# === SETTINGS ===
OUTPUT_FOLDER = r"D:\Anbu files\school library\ID_Cards_Output"
FINAL_PDF_NAME = "All_Staff_IDCards.pdf"

# List the PDF files (names) you want to merge, in order
PDF_FILES = [
    "_temp_IDCards_5001.pdf",
    "_temp_IDCards_5009.pdf",
    # Add more names here if you generate more temp PDFs
]

CLEANUP_TEMP = True  # Delete temp PDFs after merging?


def merge_existing_pdfs():
    """Merge existing PDF files in the output folder."""
    pdf_list = []
    for pdf_name in PDF_FILES:
        pdf_path = os.path.join(OUTPUT_FOLDER, pdf_name)
        if os.path.exists(pdf_path):
            pdf_list.append(pdf_path)
            print(f"Found: {pdf_name}")
        else:
            print(f"Not found: {pdf_name}")

    if not pdf_list:
        print("ERROR: No PDF files found to merge!")
        return False

    try:
        print(f"\nMerging {len(pdf_list)} PDFs...")
        print("=" * 60)

        merger = PdfWriter()

        for pdf_path in pdf_list:
            merger.append(pdf_path)
            print(f"Added: {os.path.basename(pdf_path)}")

        final_path = os.path.join(OUTPUT_FOLDER, FINAL_PDF_NAME)
        with open(final_path, "wb") as f_out:
            merger.write(f_out)
        merger.close()

        print("=" * 60)
        print("\n✓ SUCCESS: Merged PDF created!")
        print(f"  Location: {final_path}")

        if CLEANUP_TEMP:
            print("\nCleaning up temporary files...")
            for pdf_path in pdf_list:
                try:
                    os.remove(pdf_path)
                    print(f"  Removed: {os.path.basename(pdf_path)}")
                except Exception as e:
                    print(f"  Could not delete {os.path.basename(pdf_path)}: {e}")

        return True

    except Exception as e:
        print(f"ERROR during merge: {e}")
        return False


if __name__ == "__main__":
    success = merge_existing_pdfs()
    if success:
        print("\nMerge completed!")
    else:
        print("\nMerge failed!")
