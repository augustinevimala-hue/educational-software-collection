# gamemax_advance.py
"""
Fun With Words — Advanced Edition
- Adds on-screen QWERTY keyboard with per-letter highlighting for Typing Practice.
- Retains Indian English gTTS (tld='co.in'), chime, greeting, repeated word playback.
- Includes Read Aloud, Maths Quiz (simple), Admin Panel (simple).
"""
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import random
import sqlite3
import threading
import tempfile
import os
import time
import pygame
import numpy as np
from gtts import gTTS

# ---------- Configuration ----------
WINDOW_TITLE = "🎯 Fun With Words — Advanced — by Augustine Anbananthan"
LANG = 'en'
TLD = 'co.in'
CHIME_FILE = "chime.wav"
DB_FILE = "learning.db"

COLOR_PALETTE = {
    "welcome": "#ffeb3b",
    "menu": "#e3f2fd",
    "typing": "#f3e5f5",
    "dictation": "#fce4ec",
    "readwords": "#e0f2f1",
    "math": "#e8f5e8",
    "admin": "#f1f8e9",
    "result": "#fff8e1",
}

# ---------- Initialize pygame mixer ----------
try:
    pygame.mixer.pre_init(frequency=22050, size=-16, channels=2, buffer=512)
    pygame.mixer.init()
    SOUND_OK = True
except Exception as e:
    print("Warning: pygame.mixer init failed:", e)
    SOUND_OK = False

# Create simple chime if missing
def create_simple_chime(filename=CHIME_FILE, freq=880, duration=0.18):
    try:
        sample_rate = 22050
        frames = int(duration * sample_rate)
        arr = np.zeros((frames, 2), dtype=np.int16)
        for i in range(frames):
            v = int(32767 * 0.4 * np.sin(2 * np.pi * freq * i / sample_rate))
            arr[i, 0] = v
            arr[i, 1] = v
        with open(filename, "wb") as f:
            f.write(b"RIFF")
            f.write((36 + arr.nbytes).to_bytes(4, "little"))
            f.write(b"WAVEfmt ")
            f.write((16).to_bytes(4, "little"))
            f.write((1).to_bytes(2, "little"))
            f.write((2).to_bytes(2, "little"))
            f.write((sample_rate).to_bytes(4, "little"))
            f.write((sample_rate * 4).to_bytes(4, "little"))
            f.write((4).to_bytes(2, "little"))
            f.write((16).to_bytes(2, "little"))
            f.write(b"data")
            f.write((arr.nbytes).to_bytes(4, "little"))
            f.write(arr.tobytes())
    except Exception as e:
        print("Could not create chime:", e)

if not os.path.exists(CHIME_FILE):
    create_simple_chime(CHIME_FILE)

# ---------- TTS Manager (serializes speech) ----------
class TTSManager:
    def __init__(self, lang=LANG, tld=TLD):
        self.lang = lang
        self.tld = tld
        self.lock = threading.Lock()
        self.enabled = True

    def speak(self, text, repeat=1, block=False):
        if not text or not self.enabled:
            return
        if block:
            self._speak_internal(text, repeat)
        else:
            threading.Thread(target=self._speak_internal, args=(text, repeat), daemon=True).start()

    def _speak_internal(self, text, repeat):
        with self.lock:
            for _ in range(repeat):
                tmp = None
                try:
                    tmp = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
                    tmp.close()
                    tts = gTTS(text=text, lang=self.lang, tld=self.tld)
                    tts.save(tmp.name)
                    if SOUND_OK:
                        try:
                            pygame.mixer.music.stop()
                            pygame.mixer.music.load(tmp.name)
                            pygame.mixer.music.play()
                            while pygame.mixer.music.get_busy():
                                pygame.time.wait(50)
                        except Exception as e:
                            print("Playback error:", e)
                    else:
                        print("Would speak:", text)
                except Exception as e:
                    print("TTS error:", e)
                finally:
                    if tmp and os.path.exists(tmp.name):
                        try:
                            os.unlink(tmp.name)
                        except:
                            pass
                time.sleep(0.3)

    def stop(self):
        try:
            if SOUND_OK:
                pygame.mixer.music.stop()
        except:
            pass

tts = TTSManager()

def speak_indian(text, repeat=1, block=False):
    tts.speak(text, repeat=repeat, block=block)

# ---------- Database helpers ----------
def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS words (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    word TEXT UNIQUE NOT NULL
                )""")
    c.execute("SELECT COUNT(*) FROM words")
    if c.fetchone()[0] == 0:
        defaults = ["apple","banana","mango","cat","dog","mom","dad","ball","book","sun",
                    "tree","milk","cup","car","house","pen","bird","fish","hat","shoe"]
        for w in defaults:
            try:
                c.execute("INSERT INTO words (word) VALUES (?)", (w,))
            except:
                pass
        conn.commit()
    conn.close()

def load_words():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT word FROM words ORDER BY word")
    data = [r[0] for r in c.fetchall()]
    conn.close()
    return data

# ---------- Main App ----------
class FunWithWordsAdvanced(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(WINDOW_TITLE)
        self.state('zoomed')
        self.configure(bg=COLOR_PALETTE["welcome"])
        self.base_font = ("Segoe UI", 20)
        init_db()
        self.words = load_words()
        self.child_name = "Learner"
        # Play chime + greeting
        threading.Thread(target=self.startup_audio, daemon=True).start()
        self.show_welcome()

    def startup_audio(self):
        if SOUND_OK and os.path.exists(CHIME_FILE):
            try:
                pygame.mixer.music.load(CHIME_FILE)
                pygame.mixer.music.play()
                while pygame.mixer.music.get_busy():
                    pygame.time.wait(50)
            except Exception:
                pass
        speak_indian("Hello! Welcome, my little friend. Let's begin learning together.", repeat=1, block=False)

    def clear(self):
        for w in self.winfo_children():
            w.destroy()

    def show_welcome(self):
        self.clear()
        frame = tk.Frame(self, bg=COLOR_PALETTE["welcome"])
        frame.pack(expand=True, fill=tk.BOTH)
        tk.Label(frame, text="🌟 Welcome to Fun With Words — Advanced! 🌟",
                 font=(self.base_font[0], 44, "bold"), bg=COLOR_PALETTE["welcome"], fg="#ff6b35").pack(pady=10)
        tk.Label(frame, text="By Augustine Anbananthan", font=(self.base_font[0], 18, "italic"),
                 bg=COLOR_PALETTE["welcome"], fg="#333333").pack()
        name_frame = tk.Frame(frame, bg=COLOR_PALETTE["welcome"])
        name_frame.pack(pady=30)
        tk.Label(name_frame, text="Child's Name:", font=(self.base_font[0], 24), bg=COLOR_PALETTE["welcome"]).pack(side=tk.LEFT, padx=6)
        self.name_entry = ttk.Entry(name_frame, font=(self.base_font[0], 24), width=20)
        self.name_entry.pack(side=tk.LEFT, padx=6)
        self.name_entry.focus()
        tk.Button(frame, text="🚀 Start", font=(self.base_font[0], 26, "bold"), bg="#4CAF50", fg="white",
                  command=self.start_menu, width=18, height=2).pack(pady=12)
        tk.Button(frame, text="❌ Quit", font=(self.base_font[0], 18, "bold"), bg="#f44336", fg="white",
                  command=self.quit_app, width=12, height=2).pack()

    def start_menu(self):
        name = self.name_entry.get().strip()
        if name:
            self.child_name = name.title()
        self.show_menu()

    def show_menu(self):
        self.clear()
        frame = tk.Frame(self, bg=COLOR_PALETTE["menu"])
        frame.pack(expand=True, fill=tk.BOTH)
        tk.Label(frame, text=f"Hello {self.child_name}! 🎉", font=(self.base_font[0], 40, "bold"),
                 bg=COLOR_PALETTE["menu"], fg="#1976d2").pack(pady=6)
        tk.Label(frame, text="Choose your learning adventure:", font=(self.base_font[0], 24, "bold"),
                 bg=COLOR_PALETTE["menu"], fg="#333333").pack(pady=6)
        btnf = tk.Frame(frame, bg=COLOR_PALETTE["menu"])
        btnf.pack(pady=18)
        tk.Button(btnf, text="⌨️ Typing Practice (QWERTY)", font=(self.base_font[0], 20, "bold"),
                  bg="#8e24aa", fg="white", command=self.open_typing, width=26, height=2).grid(row=0, column=0, padx=12, pady=8)
        tk.Button(btnf, text="👂 Dictation Exercise", font=(self.base_font[0], 20, "bold"),
                  bg="#e91e63", fg="white", command=self.open_dictation, width=26, height=2).grid(row=0, column=1, padx=12, pady=8)
        tk.Button(btnf, text="📖 Read Words", font=(self.base_font[0], 20, "bold"),
                  bg="#0097a7", fg="white", command=self.open_read, width=26, height=2).grid(row=1, column=0, padx=12, pady=8)
        tk.Button(btnf, text="🔢 Maths Quiz", font=(self.base_font[0], 20, "bold"),
                  bg="#43a047", fg="white", command=self.open_math, width=26, height=2).grid(row=1, column=1, padx=12, pady=8)
        tk.Button(btnf, text="⚙️ Admin Panel", font=(self.base_font[0], 18, "bold"),
                  bg="#689f38", fg="white", command=self.open_admin, width=26, height=2).grid(row=2, column=0, columnspan=2, pady=12)

    def quit_app(self):
        speak_indian(f"Goodbye {self.child_name}! See you again!", block=False)
        self.after(800, self._quit)

    def _quit(self):
        try:
            tts.stop()
        except:
            pass
        try:
            pygame.mixer.quit()
        except:
            pass
        try:
            self.destroy()
        except:
            pass

    # ---------- open screens ----------
    def open_typing(self):
        TypingAdvanced(self, self.words)

    def open_dictation(self):
        DictationScreen(self, self.words)

    def open_read(self):
        ReadWordsScreen(self, self.words)

    def open_math(self):
        MathQuizScreen(self, self.words)

    def open_admin(self):
        AdminPanel(self)

# ---------- Typing with QWERTY on-screen keyboard ----------
class TypingAdvanced:
    QWERTY_ROWS = ["qwertyuiop", "asdfghjkl;", "zxcvbnm,./"]  # semicolon/comma kept for keys layout
    # We'll normalize ; , . / to letters when matching (ignore punctuation in words)

    def __init__(self, app, words):
        self.app = app
        self.words = [w for w in words if w.isalpha()]  # only alphabetic words for typing practice
        if len(self.words) < 1:
            messagebox.showwarning("No words", "Not enough words for typing practice.")
            return
        random.shuffle(self.words)
        self.total = min(10, len(self.words))
        self.index = 0
        self.current = ""
        self.letter_index = 0
        self.key_widgets = {}  # map char -> widget
        self.build_ui()
        self.next_word()

    def build_ui(self):
        self.app.clear()
        self.app.configure(bg=COLOR_PALETTE["typing"])
        frame = tk.Frame(self.app, bg=COLOR_PALETTE["typing"])
        frame.pack(expand=True, fill=tk.BOTH)
        tk.Label(frame, text="⌨️ Typing Practice (QWERTY)", font=(self.app.base_font[0], 34, "bold"),
                 bg=COLOR_PALETTE["typing"], fg="#6a1b9a").pack(pady=8)
        self.word_label = tk.Label(frame, text="", font=(self.app.base_font[0], 72, "bold"),
                                   bg=COLOR_PALETTE["typing"], fg="#1565c0")
        self.word_label.pack(pady=6)
        self.entry = ttk.Entry(frame, font=(self.app.base_font[0], 36), width=20)
        self.entry.pack(pady=8)
        self.entry.focus()
        self.entry.bind("<KeyRelease>", self.on_key_release)
        # QWERTY keyboard visual
        keyboard_frame = tk.Frame(frame, bg=COLOR_PALETTE["typing"])
        keyboard_frame.pack(pady=14)
        self.key_widgets.clear()
        for r, row in enumerate(self.QWERTY_ROWS):
            row_frame = tk.Frame(keyboard_frame, bg=COLOR_PALETTE["typing"])
            row_frame.pack(pady=6)
            # indent second row
            if r == 1:
                tk.Frame(row_frame, width=25, bg=COLOR_PALETTE["typing"]).pack(side=tk.LEFT)
            if r == 2:
                tk.Frame(row_frame, width=55, bg=COLOR_PALETTE["typing"]).pack(side=tk.LEFT)
            for ch in row:
                display = ch.upper()
                btn = tk.Label(row_frame, text=display, font=(self.app.base_font[0], 20, "bold"),
                               width=4, height=2, bd=3, relief="raised", bg="lightgray", cursor="hand2")
                btn.pack(side=tk.LEFT, padx=4)
                # bind click to simulate key press
                btn.bind("<Button-1>", lambda e, c=ch: self.on_virtual_key(c))
                self.key_widgets[ch] = btn

        # hint & controls
        control_frame = tk.Frame(frame, bg=COLOR_PALETTE["typing"])
        control_frame.pack(pady=10)
        tk.Button(control_frame, text="✅ Submit", font=(self.app.base_font[0], 20, "bold"),
                  bg="#4CAF50", fg="white", command=self.check_word, width=14).pack(side=tk.LEFT, padx=8)
        tk.Button(control_frame, text="⬅️ Back", font=(self.app.base_font[0], 18, "bold"),
                  bg="#607d8b", fg="white", command=self.app.show_menu, width=14).pack(side=tk.LEFT, padx=8)
        self.status_label = tk.Label(frame, text=f"Progress: 0/{self.total}", font=(self.app.base_font[0], 20),
                                     bg=COLOR_PALETTE["typing"])
        self.status_label.pack(pady=8)

    def normalize_char(self, ch):
        # map punctuation keys to letters where appropriate or ignore
        return ch.lower()

    def highlight_next(self):
        # clear all
        for ch, w in self.key_widgets.items():
            w.config(bg="lightgray")
        # highlight expected letter
        if self.letter_index < len(self.current):
            expected = self.current[self.letter_index].lower()
            # find matching key widget - if not present (like letters with accents), skip
            # find first widget whose normalized char matches expected
            found = None
            for k in self.key_widgets:
                if k.isalpha() and k.lower() == expected:
                    found = self.key_widgets[k]
                    break
            if found:
                found.config(bg="#ffeb3b")  # yellow highlight

    def on_virtual_key(self, ch):
        # simulate typing char into entry and handle it
        # only accept alpha characters
        if not ch:
            return
        # Convert to the letter expected; if punctuation, ignore
        char = ch.lower()
        # Insert char at end
        current_text = self.entry.get()
        self.entry.insert(tk.END, char)
        # After insertion, call key release handler to process
        self.on_key_release(None)

    def on_key_release(self, event):
        typed = self.entry.get().strip()
        # Prevent doubling: accept progress only when typed matches prefix of required word
        # If user types more than needed, trim to expected length
        if len(typed) > len(self.current):
            typed = typed[:len(self.current)]
            self.entry.delete(0, tk.END)
            self.entry.insert(0, typed)
        # If the typed prefix doesn't match current prefix, flash the wrong key
        if not self.current.lower().startswith(typed.lower()):
            # flash red on last key if possible
            if typed:
                last = typed[-1].lower()
                widget = None
                for k, w in self.key_widgets.items():
                    if k.lower() == last:
                        widget = w
                        break
                if widget:
                    orig = widget.cget("bg")
                    widget.config(bg="#ff8a80")  # red
                    self.app.after(220, lambda w=widget, o=orig: w.config(bg=o))
            # remove the wrong char
            if typed:
                self.entry.delete(len(typed)-1, tk.END)
            return
        # If typed matches entire current word, auto-check
        if typed.lower() == self.current.lower():
            self.check_word()
            return
        # update letter_index and highlight next
        self.letter_index = len(typed)
        self.highlight_next()

    def next_word(self):
        if self.index >= self.total:
            messagebox.showinfo("Done", "Typing practice complete!")
            self.app.show_menu()
            return
        self.current = self.words[self.index]
        self.letter_index = 0
        self.word_label.config(text=self.current)
        self.entry.delete(0, tk.END)
        self.entry.focus()
        self.status_label.config(text=f"Progress: {self.index}/{self.total}")
        # speak instruction + word twice
        speak_indian(f"Type the word: {self.current}", repeat=1, block=False)
        threading.Thread(target=lambda: speak_indian(self.current, repeat=2, block=False), daemon=True).start()
        # highlight next
        self.highlight_next()

    def check_word(self):
        typed = self.entry.get().strip().lower()
        if not typed:
            self.entry.focus()
            return
        if typed == self.current.lower():
            # success chime
            if SOUND_OK:
                try:
                    pygame.mixer.Sound(CHIME_FILE).play()
                except:
                    pass
            speak_indian("Excellent! Correct!", repeat=1, block=False)
        else:
            speak_indian(f"Oops! The correct word is {self.current}", repeat=2, block=False)
        self.index += 1
        self.app.after(800, self.next_word)

# ---------- Dictation Screen (keeps from stable version) ----------
class DictationScreen:
    def __init__(self, app, words):
        self.app = app
        self.words = words.copy()
        random.shuffle(self.words)
        self.total = min(10, len(self.words))
        self.index = 0
        self.score = 0
        self.current = ""
        self.build_ui()
        self.next_word()

    def build_ui(self):
        self.app.clear()
        self.app.configure(bg=COLOR_PALETTE["dictation"])
        main = tk.Frame(self.app, bg=COLOR_PALETTE["dictation"])
        main.pack(expand=True, fill=tk.BOTH)
        tk.Label(main, text="👂 Dictation Exercise", font=(self.app.base_font[0], 36, "bold"),
                 bg=COLOR_PALETTE["dictation"], fg="#c2185b").pack(pady=8)
        self.counter_label = tk.Label(main, text="", font=(self.app.base_font[0], 20), bg=COLOR_PALETTE["dictation"])
        self.counter_label.pack()
        self.entry = ttk.Entry(main, font=(self.app.base_font[0], 36), width=24)
        self.entry.pack(pady=10)
        self.entry.bind("<Return>", lambda e: self.check_answer())
        tk.Button(main, text="🔄 Repeat", font=(self.app.base_font[0], 20, "bold"),
                  bg="#9c27b0", fg="white", command=self.repeat_word, width=14).pack(pady=6)
        tk.Button(main, text="⬅️ Back", font=(self.app.base_font[0], 20, "bold"),
                  bg="#607d8b", fg="white", command=self.app.show_menu, width=14).pack(pady=6)
        self.score_label = tk.Label(main, text=f"Score: {self.score}/{self.total}", font=(self.app.base_font[0], 20),
                                    bg=COLOR_PALETTE["dictation"], fg="#d32f2f")
        self.score_label.pack(pady=6)

    def next_word(self):
        if self.index >= self.total:
            messagebox.showinfo("Result", f"Dictation complete! Score: {self.score}/{self.total}")
            self.app.show_menu()
            return
        self.current = self.words[self.index]
        self.counter_label.config(text=f"Word {self.index+1} of {self.total}")
        self.entry.delete(0, tk.END)
        self.entry.focus()
        speak_indian("Listen carefully and write the word", block=False)
        threading.Thread(target=lambda: speak_indian(self.current, repeat=2, block=False), daemon=True).start()

    def repeat_word(self):
        if self.current:
            speak_indian(self.current, repeat=2, block=False)
            self.entry.focus()

    def check_answer(self):
        ans = self.entry.get().strip().lower()
        if not ans:
            self.entry.focus()
            return
        if ans == self.current.lower():
            self.score += 1
            speak_indian("Excellent! Correct!", repeat=1, block=False)
        else:
            speak_indian(f"Oops! The correct word is {self.current}", repeat=2, block=False)
        self.score_label.config(text=f"Score: {self.score}/{self.total}")
        self.index += 1
        self.app.after(900, self.next_word)

# ---------- Read Words ----------
class ReadWordsScreen:
    def __init__(self, app, words):
        self.app = app
        self.words = words.copy()
        if not self.words:
            messagebox.showwarning("No words", "No words available.")
            self.app.show_menu()
            return
        self.index = 0
        self.build_ui()
        self.read_current()

    def build_ui(self):
        self.app.clear()
        self.app.configure(bg=COLOR_PALETTE["readwords"])
        main = tk.Frame(self.app, bg=COLOR_PALETTE["readwords"])
        main.pack(expand=True, fill=tk.BOTH)
        tk.Label(main, text="📖 Read Words", font=(self.app.base_font[0], 36, "bold"),
                 bg=COLOR_PALETTE["readwords"], fg="#00695c").pack(pady=8)
        self.word_label = tk.Label(main, text="", font=(self.app.base_font[0], 72, "bold"),
                                   bg=COLOR_PALETTE["readwords"], fg="#1565c0")
        self.word_label.pack(pady=12)
        btnf = tk.Frame(main, bg=COLOR_PALETTE["readwords"])
        btnf.pack()
        tk.Button(btnf, text="⬅️ Prev", font=(self.app.base_font[0], 20, "bold"),
                  bg="#607d8b", fg="white", command=self.prev_word, width=14).pack(side=tk.LEFT, padx=6)
        tk.Button(btnf, text="🔊 Read Again", font=(self.app.base_font[0], 20, "bold"),
                  bg="#9c27b0", fg="white", command=self.read_current, width=14).pack(side=tk.LEFT, padx=6)
        tk.Button(btnf, text="➡️ Next", font=(self.app.base_font[0], 20, "bold"),
                  bg="#4CAF50", fg="white", command=self.next_word, width=14).pack(side=tk.LEFT, padx=6)
        tk.Button(main, text="⬅️ Back to Menu", font=(self.app.base_font[0], 20, "bold"),
                  bg="#ff5722", fg="white", command=self.app.show_menu, width=18).pack(pady=10)

    def read_current(self):
        word = self.words[self.index]
        self.word_label.config(text=word)
        speak_indian("Read the word aloud", block=False)
        threading.Thread(target=lambda: speak_indian(word, repeat=2, block=False), daemon=True).start()

    def next_word(self):
        self.index = (self.index + 1) % len(self.words)
        self.read_current()

    def prev_word(self):
        self.index = (self.index - 1) % len(self.words)
        self.read_current()

# ---------- Simple Maths Quiz ----------
class MathQuizScreen:
    def __init__(self, app, words):
        self.app = app
        self.num_questions = 8
        self.current = 0
        self.score = 0
        self.build_ui()
        self.next_question()

    def build_ui(self):
        self.app.clear()
        self.app.configure(bg=COLOR_PALETTE["math"])
        main = tk.Frame(self.app, bg=COLOR_PALETTE["math"])
        main.pack(expand=True, fill=tk.BOTH)
        tk.Label(main, text="🔢 Maths Quiz", font=(self.app.base_font[0], 36, "bold"),
                 bg=COLOR_PALETTE["math"], fg="#2e7d32").pack(pady=10)
        self.question_label = tk.Label(main, text="", font=(self.app.base_font[0], 48, "bold"),
                                      bg=COLOR_PALETTE["math"], fg="#1565c0")
        self.question_label.pack(pady=8)
        self.entry = ttk.Entry(main, font=(self.app.base_font[0], 36), width=10)
        self.entry.pack(pady=8)
        self.entry.bind("<Return>", lambda e: self.check_answer())
        tk.Button(main, text="✅ Submit", font=(self.app.base_font[0], 20, "bold"),
                  bg="#4CAF50", fg="white", command=self.check_answer, width=14).pack(pady=6)
        tk.Button(main, text="⬅️ Back", font=(self.app.base_font[0], 18, "bold"),
                  bg="#607d8b", fg="white", command=self.app.show_menu, width=14).pack(pady=6)
        self.score_label = tk.Label(main, text=f"Score: {self.score}/{self.num_questions}", font=(self.app.base_font[0], 20),
                                    bg=COLOR_PALETTE["math"])
        self.score_label.pack(pady=6)

    def next_question(self):
        if self.current >= self.num_questions:
            messagebox.showinfo("Result", f"Maths complete! Score: {self.score}/{self.num_questions}")
            self.app.show_menu()
            return
        op = random.choice(['+', '-', '*'])
        if op == '+':
            a = random.randint(1, 20); b = random.randint(1, 20); ans = a + b
            text = f"What is {a} plus {b}?"
            label = f"{a} + {b} = ?"
        elif op == '-':
            a = random.randint(1, 20); b = random.randint(1, a); ans = a - b
            text = f"What is {a} minus {b}?"
            label = f"{a} - {b} = ?"
        else:
            a = random.randint(1, 12); b = random.randint(1, 12); ans = a * b
            text = f"What is {a} times {b}?"
            label = f"{a} × {b} = ?"
        self.answer = ans
        self.question_label.config(text=label)
        speak_indian(text, repeat=1, block=False)
        self.entry.delete(0, tk.END)
        self.entry.focus()

    def check_answer(self):
        try:
            val = int(self.entry.get().strip())
        except:
            self.entry.delete(0, tk.END)
            self.entry.focus()
            speak_indian("Please enter a valid number", repeat=1, block=False)
            return
        if val == self.answer:
            self.score += 1
            speak_indian("Correct! Well done!", repeat=1, block=False)
        else:
            speak_indian(f"Oops! The correct answer is {self.answer}", repeat=1, block=False)
        self.current += 1
        self.score_label.config(text=f"Score: {self.score}/{self.num_questions}")
        self.app.after(900, self.next_question)

# ---------- Simple Admin Panel ----------
class AdminPanel:
    def __init__(self, app):
        self.app = app
        pwd = simpledialog.askstring("Admin Password", "Enter admin password:", show='*')
        # For demo, default password 'admin'
        if pwd != "admin":
            messagebox.showwarning("Access Denied", "Incorrect password.")
            return
        self.build_ui()

    def build_ui(self):
        self.app.clear()
        self.app.configure(bg=COLOR_PALETTE["admin"])
        main = tk.Frame(self.app, bg=COLOR_PALETTE["admin"])
        main.pack(expand=True, fill=tk.BOTH)
        tk.Label(main, text="⚙️ Admin Panel", font=(self.app.base_font[0], 36, "bold"),
                 bg=COLOR_PALETTE["admin"], fg="#33691e").pack(pady=8)
        addf = tk.Frame(main, bg=COLOR_PALETTE["admin"])
        addf.pack(pady=6)
        tk.Label(addf, text="Add word:", font=(self.app.base_font[0], 18), bg=COLOR_PALETTE["admin"]).pack(side=tk.LEFT, padx=6)
        self.add_entry = ttk.Entry(addf, font=(self.app.base_font[0], 18), width=20)
        self.add_entry.pack(side=tk.LEFT, padx=6)
        tk.Button(addf, text="➕ Add", font=(self.app.base_font[0], 16, "bold"),
                  bg="#4CAF50", fg="white", command=self.add_word).pack(side=tk.LEFT, padx=6)
        tk.Button(main, text="⬅️ Back to Menu", font=(self.app.base_font[0], 18, "bold"),
                  bg="#607d8b", fg="white", command=self.app.show_menu, width=18).pack(pady=12)
        self.load_list(main)

    def load_list(self, parent):
        frame = tk.Frame(parent, bg=COLOR_PALETTE["admin"])
        frame.pack(pady=8, fill=tk.BOTH, expand=True)
        self.listbox = tk.Listbox(frame, font=(self.app.base_font[0], 16))
        self.listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(frame, command=self.listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.listbox.config(yscrollcommand=scrollbar.set)
        self.refresh_words()

    def refresh_words(self):
        self.listbox.delete(0, tk.END)
        words = load_words()
        for w in words:
            self.listbox.insert(tk.END, w)

    def add_word(self):
        word = self.add_entry.get().strip().lower()
        if not word.isalpha():
            messagebox.showerror("Invalid", "Please enter alphabetic word only.")
            return
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        try:
            c.execute("INSERT INTO words (word) VALUES (?)", (word,))
            conn.commit()
            messagebox.showinfo("Added", f"Word '{word}' added.")
        except sqlite3.IntegrityError:
            messagebox.showwarning("Exists", "Word already present.")
        conn.close()
        self.add_entry.delete(0, tk.END)
        self.refresh_words()

# ---------- Run App ----------
if __name__ == "__main__":
    print("Starting Fun With Words — Advanced")
    app = FunWithWordsAdvanced()
    app.mainloop()
