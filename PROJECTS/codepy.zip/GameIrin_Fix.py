import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import random
import pyttsx3
import pygame
import threading
import platform
import os

class KidsLearningApp(tk.Tk):
    def __init__(self):
        super().__init__()
        
        # FIX: Cross-platform DPI awareness
        try:
            if platform.system() == "Windows":
                from ctypes import windll
                windll.shcore.SetProcessDpiAwareness(1)
        except:
            pass
            
        self.title("Kids Typing Adventure")
        self.geometry("800x600")
        self.configure(bg="#e6f3ff")
        
        # FIX: Better speech engine initialization with error handling
        try:
            self.engine = pyttsx3.init()
            self.engine.setProperty('rate', 140)
            self.speech_enabled = True
        except Exception as e:
            print(f"Warning: Speech engine failed to initialize: {e}")
            self.speech_enabled = False
        
        # FIX: Better sound initialization
        try:
            pygame.mixer.pre_init(frequency=22050, size=-16, channels=2, buffer=512)
            pygame.mixer.init()
            self.sound_enabled = True
            # Create default sounds programmatically if files don't exist
            self.create_default_sounds()
        except pygame.error as e:
            print(f"Warning: Pygame sound mixer failed to initialize: {e}")
            self.sound_enabled = False
        
        self.current_user_id = None
        self.current_username = "Guest"
        self.init_database()
        
        # FIX: Better style configuration
        self.style = ttk.Style()
        self.style.theme_use('clam')  # Use a more reliable theme
        self.style.configure("TButton", font=("Arial", 20, "bold"), padding=10)
        self.style.configure("TRadiobutton", font=("Arial", 24))
        self.style.configure("TEntry", font=("Arial", 24))
        self.style.configure("TLabel", font=("Arial", 30, "bold"))

        self.show_login()

    def create_default_sounds(self):
        """Create simple beep sounds if sound files don't exist"""
        if not os.path.exists("correct.wav"):
            # Create a simple correct sound (high frequency beep)
            self.create_beep_sound("correct.wav", 800, 0.2)
        if not os.path.exists("wrong.wav"):
            # Create a simple wrong sound (low frequency beep)
            self.create_beep_sound("wrong.wav", 400, 0.3)
        if not os.path.exists("result.wav"):
            # Create a result sound (melody)
            self.create_beep_sound("result.wav", 600, 0.4)

    def create_beep_sound(self, filename, frequency, duration):
        """Create a simple beep sound using pygame"""
        try:
            import numpy as np
            sample_rate = 22050
            frames = int(duration * sample_rate)
            arr = np.zeros((frames, 2))
            
            # Generate sine wave
            for i in range(frames):
                wave = np.sin(2 * np.pi * frequency * i / sample_rate)
                arr[i] = [wave, wave]
            
            # Convert to 16-bit integers
            arr = (arr * 32767).astype(np.int16)
            
            # Save as WAV file
            sound = pygame.sndarray.make_sound(arr)
            pygame.mixer.Sound.play(sound)
            
        except ImportError:
            # Fallback: create silent dummy files
            with open(filename, 'wb') as f:
                f.write(b'RIFF$\x00\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x01\x00D\xac\x00\x00\x88X\x01\x00\x02\x00\x10\x00data\x00\x00\x00\x00')

    def play_sound(self, sound_file):
        """FIX: Improved sound playing with better error handling"""
        if self.sound_enabled:
            try:
                def run_sound():
                    if os.path.exists(sound_file):
                        pygame.mixer.music.load(sound_file)
                        pygame.mixer.music.play()
                    else:
                        # Create a simple beep if file doesn't exist
                        frequency = 600 if 'correct' in sound_file else 400
                        self.create_beep_sound(sound_file, frequency, 0.2)
                        
                threading.Thread(target=run_sound, daemon=True).start()
            except (pygame.error, FileNotFoundError) as e:
                print(f"Sound error: {e}")

    def speak(self, text, block=False):
        """FIX: Improved speech with better threading and error handling"""
        if not self.speech_enabled:
            return
            
        def speak_text():
            try:
                self.engine.say(text)
                if block:
                    self.engine.runAndWait()
                else:
                    self.engine.runAndWait()
            except Exception as e:
                print(f"Speech error: {e}")
        
        # Always run speech in a separate thread to prevent UI blocking
        threading.Thread(target=speak_text, daemon=True).start()

    def speak_and_exit(self, text, sound_file=None):
        """FIX: Clean exit with speech"""
        if sound_file:
            self.play_sound(sound_file)
        
        if self.speech_enabled:
            try:
                self.engine.say(text)
                self.engine.runAndWait()
                self.engine.stop()
            except:
                pass
        
        self.after(1000, self.destroy)

    def init_database(self):
        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            level TEXT DEFAULT 'KG'
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS words (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            word TEXT NOT NULL,
            user_id INTEGER,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            exercise TEXT,
            score INTEGER,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )''')
        conn.commit()
        conn.close()

    def show_login(self):
        for widget in self.winfo_children():
            widget.destroy()
        LoginScreen(self)

    def start_session(self, username, user_id):
        self.current_username = username
        self.current_user_id = user_id
        for widget in self.winfo_children():
            widget.destroy()
        MainMenu(self, username, user_id)

    def exit_app(self):
        self.speak_and_exit("Goodbye for now!", "result.wav")

class LoginScreen(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.pack(fill=tk.BOTH, expand=True)
        self.create_widgets()

    def create_widgets(self):
        tk.Label(self, text="Welcome to Kids Typing Adventure!", 
                font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=20)
        tk.Label(self, text="Select or Enter Username", 
                font=("Arial", 24), bg="#e6f3ff").pack(pady=10)

        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        c.execute("SELECT id, username FROM users")
        users = c.fetchall()
        conn.close()
        
        usernames = ["Guest"] + [u[1] for u in users]
        self.user_var = tk.StringVar(value="Guest")
        
        combo = ttk.Combobox(self, textvariable=self.user_var, values=usernames, 
                           state="normal", font=("Arial", 20))
        combo.pack(pady=10)
        
        tk.Label(self, text="New Username (optional)", 
                font=("Arial", 20), bg="#e6f3ff").pack()
        self.new_user_entry = ttk.Entry(self, font=("Arial", 20))
        self.new_user_entry.pack(pady=5)
        self.new_user_entry.bind("<Return>", lambda e: self.login())

        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=20)
        ttk.Button(btn_frame, text="Login", command=self.login).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)
        
        tk.Label(self, text="Created by Augustine Anbananthan\nDeveloper Note: This is a fun learning tool for kids!", 
                font=("Arial", 12), bg="#e6f3ff").pack(side=tk.BOTTOM, pady=10)

    def login(self):
        username = self.user_var.get()
        new_username = self.new_user_entry.get().strip()
        user_id = None

        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        
        if new_username:
            try:
                c.execute("INSERT INTO users (username) VALUES (?)", (new_username,))
                conn.commit()
                user_id = c.lastrowid
                username = new_username
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "Username already exists!")
                conn.close()
                return
        elif username != "Guest":
            c.execute("SELECT id FROM users WHERE username = ?", (username,))
            row = c.fetchone()
            user_id = row[0] if row else None
            
        conn.close()
        self.parent.start_session(username, user_id)

class MainMenu(tk.Frame):
    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.pack(fill=tk.BOTH, expand=True)
        self.create_widgets()

    def create_widgets(self):
        tk.Label(self, text=f"Hello, {self.username}!", 
                font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=20)
        tk.Label(self, text="Choose an activity!", 
                font=("Arial", 24), bg="#e6f3ff", fg="#ff4081").pack(pady=10)
        
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=20)
        
        buttons = [
            ("Typing Exercise", self.open_typing),
            ("Spell Check Quiz", self.open_spellcheck),
            ("Math Practice", self.open_math),
            ("View Scores", self.view_scores),
            ("Read Words", self.read_words),
            ("Switch User", self.switch_user),
            ("Admin", self.open_admin),
            ("Quit", self.parent.exit_app)
        ]
        
        for i, (text, cmd) in enumerate(buttons):
            ttk.Button(btn_frame, text=text, command=cmd).grid(
                row=i//2, column=i%2, padx=15, pady=15, sticky="ew")
        
        # Configure grid weights for equal button sizes
        btn_frame.grid_columnconfigure(0, weight=1)
        btn_frame.grid_columnconfigure(1, weight=1)
        
        tk.Label(self, text="Created by Augustine Anbananthan\nDeveloper Note: Have fun learning!", 
                font=("Arial", 12), bg="#e6f3ff").pack(side=tk.BOTTOM, pady=10)

    def open_typing(self): 
        self.destroy()
        TypingExercise(self.parent, self.username, self.user_id)
        
    def open_spellcheck(self): 
        self.destroy()
        SpellCheckQuiz(self.parent, self.username, self.user_id)
        
    def open_math(self): 
        self.destroy()
        MathExercise(self.parent, self.username, self.user_id)
        
    def view_scores(self):
        scores_window = tk.Toplevel(self.parent, bg="#f0f8ff")
        scores_window.title(f"{self.username}'s Scores")
        scores_window.geometry("400x400")
        scores_window.resizable(False, False)
        
        tk.Label(scores_window, text="Your Learning Progress! 🎉", 
                font=("Arial", 28, "bold"), bg="#f0f8ff", fg="#3f51b5").pack(pady=15)

        conn = sqlite3.connect('learning.db')
        c = conn.cursor()
        c.execute("SELECT exercise, score FROM scores WHERE user_id = ? ORDER BY id DESC LIMIT 10", 
                 (self.user_id,))
        scores = c.fetchall()
        conn.close()
        
        if scores:
            for ex, sc in scores:
                color = "green" if sc >= 7 else "orange" if sc >= 4 else "red"
                tk.Label(scores_window, text=f"{ex}: {sc}/10", 
                        font=("Arial", 20), bg="#f0f8ff", fg=color).pack(pady=3)
        else:
            tk.Label(scores_window, text="No scores yet. Get started!", 
                    font=("Arial", 20), bg="#f0f8ff", fg="#ff4081").pack(pady=20)
        
        ttk.Button(scores_window, text="Close", command=scores_window.destroy).pack(pady=20)
        scores_window.transient(self.parent)
        scores_window.grab_set()
        
    def read_words(self): 
        self.destroy()
        ReadWords(self.parent, self.username, self.user_id)
        
    def switch_user(self): 
        self.destroy()
        self.parent.show_login()
        
    def open_admin(self): 
        self.destroy()
        AdminPanel(self.parent, self.username, self.user_id)

class TypingExercise(tk.Frame):
    DEFAULT_WORDS = ["cat", "dog", "mom", "dad", "ball", "apple", "book", "sun", 
                    "tree", "milk", "cup", "car", "house", "pen", "bird", "fish", 
                    "hat", "shoe", "door", "bed", "run", "jump", "play", "love", "happy"]

    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.words = random.sample(self.DEFAULT_WORDS, min(5, len(self.DEFAULT_WORDS)))
        self.current_word_index = 0
        self.pack(fill=tk.BOTH, expand=True)
        
        # Initialize all required attributes BEFORE create_widgets
        self.key_buttons = {}
        self.entry_var = None
        self.entry = None
        self.word_label = None
        self.instruction_label = None
        self.feedback = None
        self.enter_btn = None
        self.current_word = ""
        
        self.create_widgets()
        self.show_word()

    def create_widgets(self):
        tk.Label(self, text="Type the word shown below", 
                font=("Arial", 24), bg="#e6f3ff").pack(pady=10)
        
        # FIX: Single instruction label that updates
        self.instruction_label = tk.Label(self, text="Press the highlighted key!", 
                                        font=("Arial", 20), bg="#e6f3ff", fg="#ff4081")
        self.instruction_label.pack(pady=5)
        
        self.word_label = tk.Label(self, text="", font=("Arial", 36, "bold"), 
                                  bg="#e6f3ff", fg="#d81b60")
        self.word_label.pack(pady=10)
        
        self.entry_var = tk.StringVar()
        self.entry = ttk.Entry(self, textvariable=self.entry_var, 
                              font=("Arial", 28), width=20)
        self.entry.pack(pady=10)
        self.entry.bind("<Key>", self.on_key_press)
        self.entry.bind("<Return>", lambda e: self.check_word())
        self.entry.bind("<Escape>", lambda e: self.back())
        self.entry.focus_set()

        # Virtual keyboard
        kb_frame = ttk.Frame(self)
        kb_frame.pack(pady=10)
        
        rows = ["qwertyuiop", "asdfghjkl", "zxcvbnm"]
        for row in rows:
            row_frame = ttk.Frame(kb_frame)
            row_frame.pack()
            for ch in row:
                btn = tk.Button(row_frame, text=ch.upper(), width=5, height=2, 
                               bg="#bbdefb", font=("Arial", 20, "bold"))
                btn.pack(side=tk.LEFT, padx=3)
                self.key_buttons[ch] = btn

        self.enter_btn = tk.Button(self, text="Enter (Submit)", width=15, 
                                  bg="#a5d6a7", command=self.check_word, 
                                  font=("Arial", 20, "bold"))
        self.enter_btn.pack(pady=5)
        
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)
        
        self.feedback = tk.Label(self, text="", font=("Arial", 24), bg="#e6f3ff")
        self.feedback.pack(pady=5)

    def show_word(self):
        if self.current_word_index >= len(self.words):
            self.word_label.config(text="All done! Great job!", fg="#4caf50")
            self.entry.config(state="disabled")
            self.enter_btn.config(state="disabled")
            self.feedback.config(text="Exercise completed!", fg="green")
            self.instruction_label.config(text="Well done! 🎉")
            
            continue_btn = ttk.Button(self, text="Back to Menu", command=self.back)
            continue_btn.pack(pady=20)
            
            self.parent.play_sound("correct.wav")
            self.parent.speak("Great job! You completed all the words!")
            return
            
        self.current_word = self.words[self.current_word_index].lower()
        self.word_label.config(text=self.current_word.upper(), fg="#d81b60")
        self.entry_var.set("")
        self.update_keyboard()
        self.update_instruction_text()
        self.entry.focus_set()
        
        self.parent.speak(f"Type the word {self.current_word}")

    def update_keyboard(self):
        current_text = self.entry_var.get()
        current_letter_index = len(current_text)
        
        # Reset all keys
        for btn in self.key_buttons.values():
            btn.config(bg="#bbdefb")
        self.enter_btn.config(bg="#a5d6a7")
        
        # Highlight next key
        if current_letter_index < len(self.current_word):
            ch = self.current_word[current_letter_index]
            if ch in self.key_buttons:
                self.key_buttons[ch].config(bg="#ffd54f")
        else:
            self.enter_btn.config(bg="#4caf50")

    def update_instruction_text(self):
        current_text = self.entry_var.get()
        current_letter_index = len(current_text)
        
        if current_letter_index < len(self.current_word):
            next_char = self.current_word[current_letter_index].upper()
            instruction = f"Press the key: {next_char}!"
        else:
            instruction = "Press Enter to check!"
            
        # FIX: Update existing label instead of creating new ones
        self.instruction_label.config(text=instruction)

    def on_key_press(self, event):
        if event.keysym in ("Return", "Escape", "BackSpace", "Shift_L", "Shift_R", 
                           "Control_L", "Control_R", "Alt_L", "Alt_R"):
            if event.keysym == "BackSpace":
                self.after(10, self.update_after_input)
            return
            
        ch = event.char.lower()
        
        if ch.isalpha():
            current_text = self.entry_var.get()
            expected_index = len(current_text)
            
            if expected_index < len(self.current_word):
                expected_char = self.current_word[expected_index]
                
                if ch == expected_char:
                    self.feedback.config(text="Good!", fg="green")
                    self.parent.play_sound("correct.wav")
                    self.after(10, self.update_after_input)
                    return
                else:
                    self.feedback.config(text=f"Wrong key! Try {expected_char.upper()}", fg="red")
                    self.parent.speak(f"Wrong. Try {expected_char}")
                    self.parent.play_sound("wrong.wav")
                    return "break"
            else:
                return "break"
        
        return "break"

    def update_after_input(self):
        self.update_keyboard()
        self.update_instruction_text()
        
    def check_word(self, event=None):
        typed_word = self.entry_var.get().lower().strip()
        
        if typed_word == self.current_word:
            self.save_word()
            self.current_word_index += 1
            self.feedback.config(text="Correct! ✓", fg="green")
            self.parent.speak("Correct!")
            self.parent.play_sound("correct.wav")
            self.after(1500, self.show_word)
        else:
            if typed_word:
                self.feedback.config(text="Not quite right. Try again!", fg="red")
                self.parent.speak("Try again!")
                self.parent.play_sound("wrong.wav")
            else:
                self.feedback.config(text="Please type the complete word!", fg="orange")
                self.parent.speak("Please complete the word!")
            
            self.entry_var.set("")
            self.update_after_input()

    def save_word(self):
        if self.user_id:
            try:
                conn = sqlite3.connect('learning.db')
                c = conn.cursor()
                c.execute("INSERT INTO words (word, user_id) VALUES (?, ?)", 
                         (self.current_word, self.user_id))
                conn.commit()
                conn.close()
            except sqlite3.Error as e:
                print(f"Database error: {e}")

    def back(self):
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

class SpellCheckQuiz(tk.Frame):
    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.words = random.sample(TypingExercise.DEFAULT_WORDS, 10)
        self.current_question = 0
        self.attempts = 0
        self.score = 0
        self.pack(fill=tk.BOTH, expand=True)
        
        # Initialize attributes before create_widgets
        self.choice_var = tk.StringVar()
        self.radio_buttons = []
        self.word_label = None
        self.choices_frame = None
        self.feedback = None
        
        self.create_widgets()
        self.show_question()
        self.speak_instruction()
        
    def speak_instruction(self):
        instruction = "Choose the correct spelling using mouse or keyboard navigation. Press Enter to submit."
        self.parent.speak(instruction)

    def create_widgets(self):
        tk.Label(self, text="Spell Check Quiz", 
                font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=10)
        tk.Label(self, text="Choose the correct spelling!", 
                font=("Arial", 24), bg="#e6f3ff", fg="#ff4081").pack(pady=5)
        
        self.word_label = tk.Label(self, text="", font=("Arial", 32, "bold"), bg="#e6f3ff")
        self.word_label.pack(pady=10)
        
        self.choices_frame = ttk.Frame(self)
        self.choices_frame.pack(pady=10)
        
        self.feedback = tk.Label(self, text="", font=("Arial", 24), bg="#e6f3ff")
        self.feedback.pack(pady=5)
        
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Submit", command=self.check_answer).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)

    def show_question(self):
        if self.current_question >= len(self.words):
            self.save_score()
            self.word_label.config(text=f"Quiz Complete! Score: {self.score}/10", fg="#4caf50")
            
            for widget in self.choices_frame.winfo_children():
                widget.destroy()
                
            self.feedback.config(text="Well done! 🎉", fg="green")
            
            result_frame = ttk.Frame(self)
            result_frame.pack(pady=20)
            ttk.Button(result_frame, text="Try Again", command=self.restart_quiz).pack(side=tk.LEFT, padx=10)
            ttk.Button(result_frame, text="Back to Menu", command=self.back).pack(side=tk.LEFT, padx=10)
            
            self.parent.play_sound("result.wav")
            self.parent.speak(f"Quiz complete! Your score is {self.score} out of 10!")
            return
            
        self.attempts = 0
        self.choice_var.set("")
        current_word = self.words[self.current_question]
        
        self.parent.speak(f"Question {self.current_question + 1}. Choose the correct spelling of {current_word}.")
        
        self.word_label.config(text=f"Question {self.current_question + 1}: Choose the correct spelling", 
                              fg="#d81b60")
        
        # Create choices with one correct and three incorrect spellings
        choices = [current_word]
        for _ in range(3):
            wrong_word = self.create_wrong_spelling(current_word)
            while wrong_word in choices:
                wrong_word = self.create_wrong_spelling(current_word)
            choices.append(wrong_word)
        
        random.shuffle(choices)
        
        # Clear previous choices
        for widget in self.choices_frame.winfo_children():
            widget.destroy()
            
        self.radio_buttons = []
        for choice in choices:
            rb = ttk.Radiobutton(self.choices_frame, text=choice, value=choice, 
                               variable=self.choice_var, style="TRadiobutton")
            rb.pack(anchor="w", pady=5, padx=20)
            self.radio_buttons.append(rb)
            
        self.feedback.config(text=f"Attempts left: 3", fg="#3f51b5")
        self.setup_keyboard_navigation()
    
    def create_wrong_spelling(self, word):
        """FIX: Create more realistic wrong spellings"""
        if len(word) < 2:
            return word + 'x'
            
        methods = [
            lambda w: w[1:] + w[0],  # Move first letter to end
            lambda w: w[:-1] + ('x' if w[-1] != 'x' else 'z'),  # Change last letter
            lambda w: w[:len(w)//2] + ('x' if w[len(w)//2] != 'x' else 'z') + w[len(w)//2+1:] if len(w) > 2 else w + 'x',  # Change middle letter
            lambda w: w[0] + w[2:] + w[1] if len(w) > 2 else w + 'x',  # Swap 2nd and last letter
        ]
        
        method = random.choice(methods)
        try:
            result = method(word)
            return result if result != word else word + 'x'
        except:
            return word + 'x'
    
    def setup_keyboard_navigation(self):
        """FIX: Better keyboard navigation"""
        self.parent.bind("<Up>", self.navigate_up)
        self.parent.bind("<Down>", self.navigate_down)
        self.parent.bind("<space>", self.select_current)
        self.parent.bind("<Return>", self.check_answer)
        
        # Focus first radio button
        if self.radio_buttons:
            self.radio_buttons[0].focus_set()

    def navigate_up(self, event):
        current = self.parent.focus_get()
        if current in self.radio_buttons:
            index = self.radio_buttons.index(current)
            prev_index = (index - 1) % len(self.radio_buttons)
            self.radio_buttons[prev_index].focus_set()
        return "break"

    def navigate_down(self, event):
        current = self.parent.focus_get()
        if current in self.radio_buttons:
            index = self.radio_buttons.index(current)
            next_index = (index + 1) % len(self.radio_buttons)
            self.radio_buttons[next_index].focus_set()
        return "break"

    def select_current(self, event):
        current = self.parent.focus_get()
        if current in self.radio_buttons:
            self.choice_var.set(current.cget("value"))
        return "break"

    def check_answer(self, event=None):
        selected = self.choice_var.get()
        if not selected:
            self.feedback.config(text="Please select an option!", fg="red")
            self.parent.play_sound("wrong.wav")
            return
            
        correct = self.words[self.current_question]
        
        if selected == correct:
            self.score += 1
            self.feedback.config(text="Correct! ✓", fg="green")
            self.parent.speak("Correct!")
            self.current_question += 1
            self.parent.play_sound("correct.wav")
            self.after(1500, self.show_question)
        else:
            self.attempts += 1
            if self.attempts >= 3:
                self.feedback.config(text=f"Correct spelling: {correct}", 
                                   fg="red", font=("Arial", 28, "bold"))
                self.parent.speak(f"The correct spelling is {correct}.")
                self.current_question += 1
                self.parent.play_sound("wrong.wav")
                self.after(2000, self.show_question)
            else:
                self.feedback.config(text=f"Wrong! Attempts left: {3 - self.attempts}", fg="red")
                self.parent.speak("Wrong answer. Try again.")
                self.choice_var.set("")
                self.parent.play_sound("wrong.wav")

    def save_score(self):
        if self.user_id:
            try:
                conn = sqlite3.connect('learning.db')
                c = conn.cursor()
                c.execute("INSERT INTO scores (user_id, exercise, score) VALUES (?, ?, ?)", 
                         (self.user_id, "SpellCheck", self.score))
                conn.commit()
                conn.close()
            except sqlite3.Error as e:
                print(f"Database error: {e}")

    def restart_quiz(self):
        self.destroy()
        SpellCheckQuiz(self.parent, self.username, self.user_id)

    def back(self):
        # Clean up key bindings
        try:
            self.parent.unbind("<Up>")
            self.parent.unbind("<Down>")
            self.parent.unbind("<space>")
            self.parent.unbind("<Return>")
        except:
            pass
        
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

class MathExercise(tk.Frame):
    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.questions = [(random.randint(1, 10), random.randint(1, 10)) for _ in range(10)]
        self.current_question = 0
        self.score = 0
        self.pack(fill=tk.BOTH, expand=True)
        
        # Initialize attributes before create_widgets
        self.question_label = None
        self.answer_var = None
        self.answer_entry = None
        self.feedback = None
        
        self.create_widgets()
        self.show_question()
        self.speak_instruction()
        
    def speak_instruction(self):
        self.parent.speak("Enter the number answer and press submit or Enter key.")

    def create_widgets(self):
        tk.Label(self, text="Math Practice", 
                font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=10)
        tk.Label(self, text="Solve the addition problems!", 
                font=("Arial", 24), bg="#e6f3ff", fg="#ff4081").pack(pady=5)
        
        self.question_label = tk.Label(self, text="", font=("Arial", 36, "bold"), 
                                     bg="#e6f3ff", fg="#d81b60")
        self.question_label.pack(pady=10)
        
        self.answer_var = tk.StringVar()
        self.answer_entry = ttk.Entry(self, textvariable=self.answer_var, 
                                    font=("Arial", 28), width=10, justify='center')
        self.answer_entry.pack(pady=10)
        self.answer_entry.bind("<Return>", self.check_answer)
        self.answer_entry.bind("<KeyPress>", self.validate_number_input)
        
        self.feedback = tk.Label(self, text="", font=("Arial", 24), bg="#e6f3ff")
        self.feedback.pack(pady=5)
        
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Submit", command=self.check_answer).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)

    def validate_number_input(self, event):
        """FIX: Only allow numbers and basic editing keys"""
        if event.char.isdigit() or event.keysym in ('BackSpace', 'Delete', 'Left', 'Right', 'Return'):
            return
        else:
            return "break"

    def show_question(self):
        if self.current_question >= len(self.questions):
            self.save_score()
            self.question_label.config(text=f"Math Complete! Score: {self.score}/10", fg="#4caf50")
            self.answer_entry.config(state="disabled")
            self.feedback.config(text="Great work! 🎉", fg="green")
            
            result_frame = ttk.Frame(self)
            result_frame.pack(pady=20)
            ttk.Button(result_frame, text="Try Again", command=self.restart).pack(side=tk.LEFT, padx=10)
            ttk.Button(result_frame, text="Back to Menu", command=self.back).pack(side=tk.LEFT, padx=10)
            
            self.parent.play_sound("result.wav")
            self.parent.speak(f"Math exercise complete! Your score is {self.score} out of 10!")
            return
            
        a, b = self.questions[self.current_question]
        self.question_label.config(text=f"{a} + {b} = ?", fg="#d81b60")
        self.answer_var.set("")
        self.answer_entry.focus()
        self.feedback.config(text="")
        
        self.parent.speak(f"Question {self.current_question + 1}. What is {a} plus {b}?")

    def check_answer(self, event=None):
        try:
            answer = int(self.answer_var.get().strip())
            a, b = self.questions[self.current_question]
            correct_answer = a + b
            
            if answer == correct_answer:
                self.score += 1
                self.feedback.config(text="Correct! ✓", fg="green")
                self.parent.speak("Correct!")
                self.current_question += 1
                self.parent.play_sound("correct.wav")
                self.after(1500, self.show_question)
            else:
                self.feedback.config(text=f"Not quite. The answer is {correct_answer}", fg="red")
                self.parent.speak(f"The correct answer is {correct_answer}. Try the next one!")
                self.current_question += 1
                self.parent.play_sound("wrong.wav")
                self.after(2000, self.show_question)
                
        except ValueError:
            self.feedback.config(text="Please enter a valid number!", fg="red")
            self.parent.speak("Please enter a valid number.")
            self.parent.play_sound("wrong.wav")

    def save_score(self):
        if self.user_id:
            try:
                conn = sqlite3.connect('learning.db')
                c = conn.cursor()
                c.execute("INSERT INTO scores (user_id, exercise, score) VALUES (?, ?, ?)", 
                         (self.user_id, "Math", self.score))
                conn.commit()
                conn.close()
            except sqlite3.Error as e:
                print(f"Database error: {e}")

    def restart(self):
        self.destroy()
        MathExercise(self.parent, self.username, self.user_id)

    def back(self):
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

class ReadWords(tk.Frame):
    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.pack(fill=tk.BOTH, expand=True)
        
        # Initialize attributes before other method calls
        self.words = []
        self.current_word = 0
        self.instruction_label = None
        self.word_label = None
        
        self.words = self.get_words()
        self.create_widgets()
        if self.words:
            self.show_word()

    def create_widgets(self):
        tk.Label(self, text="Read Your Words", 
                font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=10)
        
        self.instruction_label = tk.Label(self, text="Listen and repeat the words!", 
                                        font=("Arial", 24), bg="#e6f3ff", fg="#ff4081")
        self.instruction_label.pack(pady=5)
        
        self.word_label = tk.Label(self, text="No words yet. Try the typing exercise first!", 
                                 font=("Arial", 36, "bold"), bg="#e6f3ff", fg="#d81b60")
        self.word_label.pack(pady=20)
        
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        
        if self.words:
            ttk.Button(btn_frame, text="Next Word", command=self.next_word).pack(side=tk.LEFT, padx=10)
            ttk.Button(btn_frame, text="Repeat", command=self.read_aloud).pack(side=tk.LEFT, padx=10)
            
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)
        
        if self.words:
            self.parent.speak("Here are your practiced words. Listen carefully and repeat them!")

    def get_words(self):
        if not self.user_id:
            return []
        try:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            c.execute("SELECT DISTINCT word FROM words WHERE user_id = ? ORDER BY id", (self.user_id,))
            words = [row[0] for row in c.fetchall()]
            conn.close()
            return words
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return []

    def show_word(self):
        if self.words and self.current_word < len(self.words):
            word = self.words[self.current_word]
            self.word_label.config(text=word.upper(), fg="#d81b60")
            self.read_aloud(initial_read=True)

    def next_word(self):
        if self.words:
            self.current_word = (self.current_word + 1) % len(self.words)
            self.show_word()

    def read_aloud(self, initial_read=False):
        if self.words and self.current_word < len(self.words):
            word = self.words[self.current_word]
            self.parent.speak(word)

    def back(self):
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

class AdminPanel(tk.Frame):
    def __init__(self, parent, username, user_id):
        super().__init__(parent, bg="#e6f3ff")
        self.parent = parent
        self.username = username
        self.user_id = user_id
        self.pack(fill=tk.BOTH, expand=True)
        
        # Initialize attributes before create_widgets
        self.word_map = {}  # Maps listbox index to database ID
        self.word_listbox = None
        self.word_entry = None
        
        self.create_widgets()

    def create_widgets(self):
        tk.Label(self, text="Admin Panel", 
                font=("Arial", 32, "bold"), bg="#e6f3ff", fg="#3f51b5").pack(pady=10)
        tk.Label(self, text="Manage your word list", 
                font=("Arial", 24), bg="#e6f3ff", fg="#ff4081").pack(pady=5)
        
        # Word list display
        list_frame = ttk.Frame(self)
        list_frame.pack(pady=10, padx=20, fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.word_listbox = tk.Listbox(list_frame, font=("Arial", 20), height=10,
                                      yscrollcommand=scrollbar.set)
        self.word_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.word_listbox.yview)
        
        # Word entry
        entry_frame = ttk.Frame(self)
        entry_frame.pack(pady=5)
        
        tk.Label(entry_frame, text="Add new word:", font=("Arial", 18), bg="#e6f3ff").pack()
        self.word_entry = ttk.Entry(entry_frame, font=("Arial", 20), width=20)
        self.word_entry.pack(pady=5)
        self.word_entry.bind("<Return>", lambda e: self.add_word())
        
        # Buttons
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        
        ttk.Button(btn_frame, text="Add Word", command=self.add_word).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Delete Selected", command=self.delete_word).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Clear All", command=self.clear_all_words).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Back", command=self.back).pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.parent.exit_app).pack(side=tk.LEFT, padx=10)
        
        self.load_words()

    def load_words(self):
        self.word_listbox.delete(0, tk.END)
        self.word_map = {}
        
        if not self.user_id:
            return
            
        try:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            c.execute("SELECT id, word FROM words WHERE user_id = ? ORDER BY word", (self.user_id,))
            
            for i, (word_id, word) in enumerate(c.fetchall()):
                self.word_listbox.insert(tk.END, word)
                self.word_map[i] = word_id
                
            conn.close()
        except sqlite3.Error as e:
            print(f"Database error: {e}")

    def add_word(self):
        word = self.word_entry.get().strip().lower()
        if not word:
            messagebox.showwarning("Warning", "Please enter a word!")
            return
            
        if not word.isalpha():
            messagebox.showwarning("Warning", "Please enter letters only!")
            return
            
        if not self.user_id:
            messagebox.showerror("Error", "Please login with a registered user account!")
            return
            
        try:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            c.execute("INSERT INTO words (word, user_id) VALUES (?, ?)", (word, self.user_id))
            conn.commit()
            conn.close()
            
            self.word_entry.delete(0, tk.END)
            self.load_words()
            messagebox.showinfo("Success", f"Word '{word}' added successfully!")
            
        except sqlite3.IntegrityError:
            messagebox.showwarning("Warning", "This word already exists!")
        except sqlite3.Error as e:
            messagebox.showerror("Error", f"Database error: {e}")

    def delete_word(self):
        try:
            selection = self.word_listbox.curselection()
            if not selection:
                messagebox.showwarning("Warning", "Please select a word to delete!")
                return
            
            listbox_index = selection[0]
            word_id_to_delete = self.word_map.get(listbox_index)
            
            if word_id_to_delete is None:
                messagebox.showerror("Error", "Invalid selection.")
                return

            # Confirm deletion
            word_to_delete = self.word_listbox.get(listbox_index)
            if not messagebox.askyesno("Confirm", f"Delete the word '{word_to_delete}'?"):
                return

            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            c.execute("DELETE FROM words WHERE id = ?", (word_id_to_delete,))
            conn.commit()
            conn.close()
            
            self.load_words()
            messagebox.showinfo("Success", "Word deleted successfully!")
            
        except sqlite3.Error as e:
            messagebox.showerror("Error", f"Database error: {e}")
        except tk.TclError:
            messagebox.showwarning("Warning", "Please select a word to delete!")

    def clear_all_words(self):
        if not self.user_id:
            messagebox.showerror("Error", "Please login with a registered user account!")
            return
            
        if not messagebox.askyesno("Confirm", "Delete ALL words? This cannot be undone!"):
            return
            
        try:
            conn = sqlite3.connect('learning.db')
            c = conn.cursor()
            c.execute("DELETE FROM words WHERE user_id = ?", (self.user_id,))
            conn.commit()
            conn.close()
            
            self.load_words()
            messagebox.showinfo("Success", "All words deleted successfully!")
            
        except sqlite3.Error as e:
            messagebox.showerror("Error", f"Database error: {e}")

    def back(self):
        self.destroy()
        MainMenu(self.parent, self.username, self.user_id)

if __name__ == "__main__":
    try:
        app = KidsLearningApp()
        app.mainloop()
    except KeyboardInterrupt:
        print("\nApplication closed by user.")
    except Exception as e:
        print(f"An error occurred: {e}")
        messagebox.showerror("Error", f"An unexpected error occurred: {e}")